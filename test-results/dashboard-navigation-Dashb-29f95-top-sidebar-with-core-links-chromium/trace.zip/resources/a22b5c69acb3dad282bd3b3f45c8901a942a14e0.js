(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_7d37e0._.js", {

"[project]/src/lib/auth.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "authOptions": (()=>authOptions),
    "clearSession": (()=>clearSession),
    "default": (()=>__TURBOPACK__default__export__),
    "getSession": (()=>getSession),
    "setSession": (()=>setSession)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next-auth/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$google$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next-auth/providers/google.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
;
;
const getSession = async ()=>{
    if ("TURBOPACK compile-time falsy", 0) {
        "TURBOPACK unreachable";
    }
    const token = localStorage.getItem('token');
    return token ? {
        token
    } : null;
};
const setSession = (token)=>{
    localStorage.setItem('token', token);
};
const clearSession = ()=>{
    localStorage.removeItem('token');
    localStorage.removeItem('rememberedCredentials'); // Also clear remembered credentials
};
const authOptions = {
    providers: [
        // Only add Google provider if credentials are available
        ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.GOOGLE_CLIENT_ID && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.GOOGLE_CLIENT_SECRET ? [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$google$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                clientId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.GOOGLE_CLIENT_ID,
                clientSecret: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.GOOGLE_CLIENT_SECRET
            })
        ] : []
    ],
    callbacks: {
        async jwt ({ token, account }) {
            if (account) {
                token.accessToken = account.access_token;
            }
            return token;
        },
        async session ({ session, token }) {
            if (token.accessToken) {
                session.accessToken = token.accessToken;
            }
            return session;
        }
    },
    pages: {
        signIn: '/signin',
        error: '/signin'
    },
    secret: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXTAUTH_SECRET
};
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(authOptions);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/errorParser.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "parseError": (()=>parseError)
});
function sanitizeMessage(msg) {
    if (!msg) return msg;
    if (msg.includes('SQLSTATE') || msg.includes('SQL:') || msg.includes('Connection: mysql')) {
        return "A database error occurred while processing your request. Please try again later.";
    }
    return msg;
}
function parseError(error) {
    if (error?.response) {
        const data = error.response.data;
        // Handle Laravel validation errors (422)
        if (error.response.status === 422 && data.errors) {
            const messages = Object.entries(data.errors).map(([field, errors])=>`${field}: ${errors.join(', ')}`).join('\n');
            return {
                message: messages || data.message || 'Validation failed',
                status: 422,
                errors: data.errors,
                raw: error
            };
        }
        const rawMessage = data?.message || mapStatus(error.response.status);
        return {
            message: sanitizeMessage(rawMessage),
            status: error.response.status,
            raw: error
        };
    }
    // Handle Axios Network Errors
    if (error?.message === 'Network Error') {
        return {
            message: "Cannot connect to server. Please check your internet connection.",
            raw: error
        };
    }
    if (error?.message) {
        const rawMsg = error.message === 'API Error' ? 'Something went wrong' : error.message;
        return {
            message: sanitizeMessage(rawMsg),
            raw: error
        };
    }
    return {
        message: "Something went wrong. Please try again.",
        raw: error
    };
}
function mapStatus(status) {
    switch(status){
        case 400:
            return "Invalid request";
        case 401:
            return "Session expired. Login again";
        case 403:
            return "Permission denied";
        case 404:
            return "Not found";
        case 500:
            return "Server error. Try later";
        default:
            return "Unexpected error";
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/logger.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "logger": (()=>logger)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/errorParser.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
;
;
;
const isDev = ("TURBOPACK compile-time value", "development") === "development";
const logger = {
    error: (message, error, options)=>{
        // Only log to console in dev if it's NOT a handled validation error or a network error
        const isHandled = error?.status === 422 || error?.status === 401;
        const isNetworkError = error?.message === 'Network Error' || error && !error.status && error.message?.includes('connect');
        if (isDev && !isHandled && !isNetworkError && !options?.hideConsole) {
            console.error(`[LEADBAJAAR ERR] ${message}`, error);
        }
        // Dispatch global error event for the UI to catch (if not handled and not silenced)
        if (!isHandled && !options?.silent && "object" !== 'undefined') {
            const parsed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseError"])(error);
            const errorDetail = parsed.message;
            // If it's a network error or a 500 server error, show the high-visibility Modal
            if (errorDetail.includes('connect to server') || parsed.status && parsed.status >= 500) {
                const event = new CustomEvent('app-global-error', {
                    detail: {
                        title: message,
                        message: errorDetail
                    }
                });
                window.dispatchEvent(event);
            } else {
                // For other unhandled errors, show a Toast
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(message, {
                    description: errorDetail
                });
            }
        }
        // Attempt to send to server ONLY if it's not a network error 
        // (no point trying to log to a server that is unreachable)
        if (!isNetworkError) {
            sendToServer(message, error);
        }
    },
    info: (message, data)=>{
        if ("TURBOPACK compile-time truthy", 1) {
            console.log(`[LEADBAJAAR INFO] ${message}`, data);
        }
    },
    warn: (message, data)=>{
        if ("TURBOPACK compile-time truthy", 1) {
            console.warn(`[LEADBAJAAR WARN] ${message}`, data);
        }
    }
};
async function sendToServer(message, error) {
    try {
        // Only attempt if we have an error to log
        const payload = {
            message,
            error: serialize(error),
            url: ("TURBOPACK compile-time truthy", 1) ? window.location.href : ("TURBOPACK unreachable", undefined),
            userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown',
            time: new Date().toISOString()
        };
        // Use our global API base URL for logging
        await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE_URL"]}/errors/log`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        });
    } catch (err) {
    // Fail silently in production
    }
}
function serialize(error) {
    if (!error) return null;
    return {
        message: error.message,
        stack: error.stack,
        status: error.response?.status || error.status,
        data: error.response?.data || error.data
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/lib/api.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "API_BASE_URL": (()=>API_BASE_URL),
    "WHATSAPP_BASE_URL": (()=>WHATSAPP_BASE_URL),
    "adminApi": (()=>adminApi),
    "agencyApi": (()=>agencyApi),
    "api": (()=>api),
    "authorize": (()=>authorize),
    "bulkDeleteLeads": (()=>bulkDeleteLeads),
    "bulkUpdateLeadStage": (()=>bulkUpdateLeadStage),
    "bulkUpdateLeadStatus": (()=>bulkUpdateLeadStatus),
    "companyApi": (()=>companyApi),
    "createLead": (()=>createLead),
    "createPayment": (()=>createPayment),
    "createStage": (()=>createStage),
    "default": (()=>__TURBOPACK__default__export__),
    "deleteBooking": (()=>deleteBooking),
    "deleteLead": (()=>deleteLead),
    "deleteStage": (()=>deleteStage),
    "evolutionApi": (()=>evolutionApi),
    "exportLeads": (()=>exportLeads),
    "financeApi": (()=>financeApi),
    "forgotPassword": (()=>forgotPassword),
    "getAnalyticsData": (()=>getAnalyticsData),
    "getBookings": (()=>getBookings),
    "getConversationMessages": (()=>getConversationMessages),
    "getDashboardStats": (()=>getDashboardStats),
    "getLead": (()=>getLead),
    "getLeads": (()=>getLeads),
    "getLeadsWithLatestMessages": (()=>getLeadsWithLatestMessages),
    "getMessages": (()=>getMessages),
    "getStages": (()=>getStages),
    "getUser": (()=>getUser),
    "googleIntegrationApi": (()=>googleIntegrationApi),
    "httpClient": (()=>httpClient),
    "importLeads": (()=>importLeads),
    "initializeChat": (()=>initializeChat),
    "integrationApi": (()=>integrationApi),
    "login": (()=>login),
    "loginWithGoogle": (()=>loginWithGoogle),
    "logout": (()=>logout),
    "me": (()=>me),
    "register": (()=>register),
    "reorderStages": (()=>reorderStages),
    "rescheduleBooking": (()=>rescheduleBooking),
    "resetPassword": (()=>resetPassword),
    "sendMessage": (()=>sendMessage),
    "submitTesterRequest": (()=>submitTesterRequest),
    "subscriptionApi": (()=>subscriptionApi),
    "syncDefaultStages": (()=>syncDefaultStages),
    "teamApi": (()=>teamApi),
    "updateBooking": (()=>updateBooking),
    "updateLead": (()=>updateLead),
    "updateLeadDetails": (()=>updateLeadDetails),
    "updateLeadStage": (()=>updateLeadStage),
    "updateStage": (()=>updateStage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/auth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/errorParser.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/logger.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
;
;
;
const API_BASE_URL = 'http://localhost:8000/api';
const WHATSAPP_BASE_URL = 'https://wp.leadbajaar.com/api';
const httpClient = {
    async get (url) {
        const response = await fetch(`${API_BASE_URL}${url}`);
        if (!response.ok) throw new Error('API Error');
        return response.json();
    },
    async post (url, data) {
        const response = await fetch(`${API_BASE_URL}${url}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        if (!response.ok) throw new Error('API Error');
        return response.json();
    },
    async put (url, data) {
        const response = await fetch(`${API_BASE_URL}${url}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        if (!response.ok) throw new Error('API Error');
        return response.json();
    },
    async delete (url) {
        const response = await fetch(`${API_BASE_URL}${url}`, {
            method: 'DELETE'
        });
        if (!response.ok) throw new Error('API Error');
        return response.json();
    }
};
const api = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
    withCredentials: true
});
// Add request interceptor to include token in headers
api.interceptors.request.use(async (config)=>{
    const token = localStorage.getItem('token') // or get from your auth system
    ;
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});
// Add response interceptor to handle errors globally
api.interceptors.response.use((response)=>response, (error)=>{
    const parsedError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseError"])(error);
    // Only log to console/logger if it's a server error or unexpected crash
    // 422 (Validation), 401 (Auth), and 402 (Payment) are handled by the UI
    if (!parsedError.status || parsedError.status >= 500) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error("API Error", error, {
            hideConsole: true
        });
    }
    // Global session handling (401)
    if (parsedError.status === 401) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSession"])();
        if ("TURBOPACK compile-time truthy", 1) {
            const currentPath = window.location.pathname;
            if (currentPath !== '/signin' && currentPath !== '/signup') {
                window.location.href = '/signin';
            }
        }
    }
    // Subscription Expired (402)
    if (parsedError.status === 402) {
        // The SubscriptionGuard will handle the UI overlay, 
        // but we can also trigger a toast or log here
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].warn("Subscription Expired", parsedError);
    }
    return Promise.reject(parsedError);
});
const login = async (email, password)=>{
    try {
        const response = await api.post('/login', {
            email,
            password
        });
        // Store the actual token from the response
        const token = response.data.token || response.data.access_token;
        if (!token) {
            throw new Error('No token received from server');
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setSession"])(token);
        return response.data;
    } catch (error) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isAxiosError(error)) {
            const axiosError = error;
            // Don't log the error to console for expected errors like invalid credentials
            if (axiosError.response?.status === 422) {
                throw new Error(axiosError.response.data.message || 'Invalid credentials');
            }
            if (axiosError.response?.data?.message) {
                throw new Error(axiosError.response.data.message);
            }
        }
        // Only log unexpected errors
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Login Failed', error);
        throw error;
    }
};
const register = async (name, email, password, password_confirmation, phone)=>{
    try {
        const response = await api.post('/register', {
            name,
            email,
            password,
            password_confirmation,
            phone
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setSession"])('your_auth_token');
        return response.data;
    } catch (error) {
        throw error;
    }
};
const forgotPassword = async (email)=>{
    try {
        const response = await api.post('/forgot-password', {
            email
        });
        return response.data;
    } catch (error) {
        const message = error.response?.data?.message || error.message || 'Failed to send reset link';
        throw new Error(message);
    }
};
const resetPassword = async (token, email, password, password_confirmation)=>{
    try {
        const response = await api.post('/reset-password', {
            token,
            email,
            password,
            password_confirmation
        });
        return response.data;
    } catch (error) {
        const message = error.response?.data?.message || error.message || 'Failed to reset password';
        throw new Error(message);
    }
};
const logout = async ()=>{
    try {
        const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSession"])();
        if (!session?.token) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSession"])();
            return true;
        }
        await api.post('/logout', {}, {
            headers: {
                Authorization: `Bearer ${session.token}`
            }
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSession"])();
        return true;
    } catch (error) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSession"])(); // Clear session even if logout fails
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isAxiosError(error)) {
            const axiosError = error;
            if (axiosError.response?.data?.message) {
                throw new Error(axiosError.response.data.message);
            }
        }
        throw new Error('Logout failed');
    }
};
const getUser = async ()=>{
    const response = await api.get('/user');
    return response.data;
};
const submitTesterRequest = async (data)=>{
    const response = await api.post('/tester-requests', data);
    return response.data;
};
const loginWithGoogle = async (token)=>{
    const response = await api.post('/login/google', {
        token
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setSession"])(token);
    return response.data;
};
const createLead = async (data)=>{
    const response = await api.post('/leads', {
        ...data,
        stage: data.stage || 'New'
    });
    return response.data;
};
const importLeads = async (data)=>{
    const response = await api.post('/leads/import', data);
    return response.data;
};
const getLeads = async (params)=>{
    try {
        const response = await api.get('/leads', {
            params
        });
        // If the response is already in the correct format, return it
        if (response.data?.data && Array.isArray(response.data.data)) {
            return response.data;
        }
        // If we get an array directly, wrap it in the expected format
        if (Array.isArray(response.data)) {
            return {
                data: response.data,
                meta: {
                    current_page: params.page || 1,
                    from: 1,
                    last_page: 1,
                    per_page: response.data.length,
                    to: response.data.length,
                    total: response.data.length
                }
            };
        }
        // Return the response data as is
        return response.data;
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Error fetching leads', error);
        throw error;
    }
};
const getLead = async (id)=>{
    const response = await api.get(`/leads/${id}`);
    return response.data;
};
const deleteLead = async (id)=>{
    await api.delete(`/leads/${id}`);
};
const bulkDeleteLeads = async (ids)=>{
    await api.post('/leads/bulk-destroy', {
        ids
    });
};
const bulkUpdateLeadStatus = async (ids, status)=>{
    await api.post('/leads/bulk-update-status', {
        ids,
        status
    });
};
const bulkUpdateLeadStage = async (ids, stage)=>{
    await api.post('/leads/bulk-update-stage', {
        ids,
        stage
    });
};
const updateLead = async (id, data)=>{
    const response = await api.put(`/leads/${id}`, data);
    return response.data;
};
const updateLeadStage = async (id, stage, deal_value)=>{
    const response = await api.patch(`/leads/${id}/stage`, {
        stage,
        deal_value
    });
    return response.data;
};
const getStages = async ()=>{
    const response = await api.get('/stages');
    return response.data;
};
const createStage = async (data)=>{
    const response = await api.post('/stages', data);
    return response.data;
};
const updateStage = async (id, data)=>{
    const response = await api.put(`/stages/${id}`, data);
    return response.data;
};
const deleteStage = async (id)=>{
    await api.delete(`/stages/${id}`);
};
const reorderStages = async (stages)=>{
    await api.post('/stages/reorder', {
        stages
    });
};
const syncDefaultStages = async ()=>{
    await api.post('/stages/initialize-default');
};
const createPayment = async (data)=>{
    const response = await api.post('/payments', data);
    return response.data;
};
const updateLeadDetails = async (id, data)=>{
    const response = await api.put(`/leads/${id}`, data);
    return response.data;
};
const formatMetaErrorMessage = (error, defaultMessage)=>{
    try {
        const errorData = error.response?.data?.error || error.response?.data;
        if (errorData) {
            if (typeof errorData === 'object') {
                // Meta errors usually have message, code, or error_subcode
                // We stringify the whole object so the frontend formatMetaError can parse it
                return JSON.stringify(errorData);
            }
            return String(errorData);
        }
        return error.message || defaultMessage;
    } catch (e) {
        return error?.message || defaultMessage;
    }
};
const integrationApi = {
    // Get all integrations
    getIntegrations: async ()=>{
        try {
            const response = await api.get('/integrations');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch integrations';
            throw new Error(message);
        }
    },
    // Save integration configuration
    saveIntegration: async (config)=>{
        try {
            const response = await api.post('/integrations', config);
            return response.data;
        } catch (error) {
            // Enhanced error handling for validation errors
            if (error.response?.status === 422) {
                const validationErrors = error.response.data.errors;
                if (validationErrors && typeof validationErrors === 'object') {
                    // Format validation errors into a readable message
                    const errorMessages = Object.entries(validationErrors).map(([field, messages])=>{
                        const messageArray = Array.isArray(messages) ? messages : [
                            messages
                        ];
                        return `${field}: ${messageArray.join(', ')}`;
                    }).join('; ');
                    throw new Error(`Validation failed: ${errorMessages}`);
                }
                // If errors object is not in expected format, try to get message
                const message = error.response.data.message || 'Validation failed';
                throw new Error(message);
            }
            throw error;
        }
    },
    // Update integration configuration
    updateIntegration: async (id, config)=>{
        try {
            const response = await api.put(`/integrations/${id}`, config);
            return response.data;
        } catch (error) {
            if (error.response?.status === 422) {
                const validationErrors = error.response.data.errors;
                const message = validationErrors && typeof validationErrors === 'object' ? Object.entries(validationErrors).map(([f, m])=>`${f}: ${Array.isArray(m) ? m.join(', ') : m}`).join('; ') : error.response.data.message || 'Validation failed';
                throw new Error(message);
            }
            throw error;
        }
    },
    // Update integration status
    updateIntegrationStatus: async (id, isActive)=>{
        try {
            const response = await api.patch(`/integrations/${id}/status`, {
                isActive
            });
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to update integration status';
            throw new Error(message);
        }
    },
    // Get integration logs
    getIntegrationLogs: async (id)=>{
        try {
            const response = await api.get(`/integrations/${id}/logs`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch integration logs';
            throw new Error(message);
        }
    },
    // Get the most recent log for an integration (used for testing webhooks)
    getLatestLog: async (id)=>{
        try {
            const response = await api.get(`/integrations/${id}/latest-log`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch latest log';
            throw new Error(message);
        }
    },
    // Delete integration
    deleteIntegration: async (id)=>{
        try {
            const response = await api.delete(`/integrations/${id}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to delete integration';
            throw new Error(message);
        }
    },
    getWhatsAppProfiles: async ()=>{
        try {
            const response = await api.get('/integrations/whatsapp/profiles');
            return response.data.profiles;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch WhatsApp profiles';
            throw new Error(message);
        }
    },
    getWhatsAppAccounts: async ()=>{
        try {
            const response = await api.get('/integrations/whatsapp/accounts');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch WhatsApp accounts';
            throw new Error(message);
        }
    },
    getWhatsAppTemplates: async (accountId)=>{
        try {
            const response = await api.get(`/integrations/whatsapp/${accountId}/templates`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch templates';
            throw new Error(message);
        }
    },
    syncWhatsAppTemplates: async (accountId)=>{
        try {
            const response = await api.post(`/integrations/whatsapp/${accountId}/templates/sync`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to sync templates';
            throw new Error(message);
        }
    },
    createWhatsAppTemplate: async (accountId, templateData)=>{
        try {
            const response = await api.post(`/integrations/whatsapp/${accountId}/templates`, templateData);
            return response.data;
        } catch (error) {
            // Enhanced error handling for validation errors
            if (error.response?.status === 422 && error.response?.data?.errors) {
                // Format validation errors
                const validationErrors = error.response.data.errors;
                const errorMessages = Object.entries(validationErrors).map(([field, messages])=>`${field}: ${Array.isArray(messages) ? messages.join(', ') : messages}`).join('; ');
                throw new Error(`Validation failed: ${errorMessages}`);
            } else if (error.response?.status === 401 && error.response?.data?.error_type === 'token_expired') {
                throw new Error('Your WhatsApp access token has expired. Please update your access token.');
            } else if (error.response?.data?.message) {
                throw new Error(error.response.data.message);
            } else {
                throw new Error('Failed to create template');
            }
        }
    },
    checkIntegrationStatus: async (accountId)=>{
        try {
            const response = await api.get(`/integrations/whatsapp/${accountId}/status`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to check integration status';
            throw new Error(message);
        }
    },
    markReauthenticated: async (accountId)=>{
        try {
            const response = await api.post(`/integrations/whatsapp/${accountId}/reauth`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to mark integration as re-authenticated';
            throw new Error(message);
        }
    },
    updateAccessToken: async (accountId, accessToken)=>{
        try {
            const response = await api.post(`/integrations/whatsapp/${accountId}/update-token`, {
                access_token: accessToken
            });
            return response.data;
        } catch (error) {
            if (error.response?.status === 400 && error.response?.data?.error_type === 'invalid_token') {
                throw new Error('Invalid access token. Please check your token and try again.');
            }
            const message = error.response?.data?.message || 'Failed to update access token';
            throw new Error(message);
        }
    },
    updateWhatsAppTemplate: async (accountId, templateId, templateData)=>{
        try {
            const response = await api.put(`/integrations/whatsapp/${accountId}/templates/${templateId}`, templateData);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to update template';
            throw new Error(message);
        }
    },
    deleteWhatsAppTemplate: async (accountId, templateId)=>{
        try {
            const response = await api.delete(`/integrations/whatsapp/${accountId}/templates/${templateId}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to delete template';
            throw new Error(message);
        }
    },
    getWhatsAppTemplateDetails: async (accountId, templateId)=>{
        try {
            const response = await api.get(`/integrations/whatsapp/${accountId}/templates/${templateId}/details`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to get template details';
            throw new Error(message);
        }
    },
    getConnectedIntegrations: async ()=>{
        try {
            const response = await api.get('/integrations/connected');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch connected integrations';
            throw new Error(message);
        }
    },
    // Add the sendBroadcast method
    sendBroadcast: async (data)=>{
        const response = await api.post('/leads/send-template', data);
        return response.data;
    },
    // Facebook Lead Retrieval Methods
    getFacebookLeadForms: async ()=>{
        try {
            const response = await api.get('/facebook-lead-forms');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch Facebook lead forms';
            throw new Error(message);
        }
    },
    debugIntegrations: async ()=>{
        try {
            const response = await api.get('/debug-integrations');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to debug integrations';
            throw new Error(message);
        }
    },
    // New Meta API Methods (v25.0)
    getMetaPages: async ()=>{
        try {
            const response = await api.get('/meta/pages');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta pages';
            throw new Error(message);
        }
    },
    getMetaPageForms: async (pageId)=>{
        try {
            const response = await api.get(`/meta/pages/${pageId}/forms`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta lead forms';
            throw new Error(message);
        }
    },
    // Meta Ads API Methods
    getMetaAdAccounts: async ()=>{
        try {
            const response = await api.get('/meta/ads/adaccounts');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta ad accounts';
            throw new Error(message);
        }
    },
    getMetaBusinessAdAccounts: async (businessId)=>{
        try {
            const response = await api.get(`/meta/ads/businesses/${businessId}/adaccounts`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch business ad accounts';
            throw new Error(message);
        }
    },
    getMetaCampaigns: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/campaigns`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta campaigns';
            throw new Error(message);
        }
    },
    getMetaAdSets: async (campaignId)=>{
        try {
            const response = await api.get(`/meta/ads/campaigns/${campaignId}/adsets`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta ad sets';
            throw new Error(message);
        }
    },
    getMetaAds: async (adSetId)=>{
        try {
            const response = await api.get(`/meta/ads/adsets/${adSetId}/ads`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta ads';
            throw new Error(message);
        }
    },
    getMetaAdAccountInsights: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/insights`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta ad insights';
            throw new Error(message);
        }
    },
    updateMetaStatus: async (objectId, status)=>{
        try {
            const response = await api.post(`/meta/ads/${objectId}/status`, {
                status
            });
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to update Meta status';
            throw new Error(message);
        }
    },
    retrieveFacebookLeads: async (data)=>{
        try {
            const response = await api.post('/facebook-lead-retrieval', data);
            return response.data;
        } catch (error) {
            // Enhanced error handling to preserve error details from backend
            if (error.response?.data) {
                // Create a new error with the backend's error details
                const backendError = new Error(error.response.data.error || 'Failed to retrieve Facebook leads');
                // Attach the response data to the error for the frontend to use
                backendError.response = error.response;
                throw backendError;
            }
            throw new Error('Failed to retrieve Facebook leads');
        }
    },
    connectMeta: async ()=>{
        try {
            const response = await api.get('/meta/connect');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to get Meta connection URL');
        }
    },
    getMetaStatus: async ()=>{
        try {
            const response = await api.get('/meta/status');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to fetch Meta status');
        }
    },
    disconnectMeta: async ()=>{
        try {
            const response = await api.post('/meta/deauthorize'); // Now hits the authenticated route
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to disconnect Meta');
        }
    },
    dataDeletionRequest: async ()=>{
        try {
            const response = await api.post('/meta/data-deletion'); // Now hits the authenticated route
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to request data deletion');
        }
    },
    getDeletionRequests: async ()=>{
        try {
            const response = await api.get('/meta/deletion-requests');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to fetch deletion requests');
        }
    },
    getMetaBusinessAssets: async (businessId)=>{
        try {
            const response = await api.get(`/meta/business/${businessId}/assets`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to fetch business assets');
        }
    },
    // Facebook Conversion API Methods
    sendConversionEvent: async (data)=>{
        try {
            const response = await api.post('/facebook/conversion-api/send-event', data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to send conversion event';
            throw new Error(message);
        }
    },
    sendBatchConversionEvents: async (data)=>{
        try {
            const response = await api.post('/facebook/conversion-api/send-batch-events', data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to send batch conversion events';
            throw new Error(message);
        }
    },
    sendTestConversionEvent: async (data)=>{
        try {
            const response = await api.post('/facebook/conversion-api/send-test-event', data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to send test conversion event';
            throw new Error(message);
        }
    },
    getConversionApiEventTypes: async ()=>{
        try {
            const response = await api.get('/facebook/conversion-api/event-types');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch event types';
            throw new Error(message);
        }
    },
    getConversionApiConfiguration: async ()=>{
        try {
            const response = await api.get('/facebook/conversion-api/configuration');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Conversion API configuration';
            throw new Error(message);
        }
    },
    getMetaWebhookChecklist: async (pageId)=>{
        try {
            const response = await api.get(`/meta/pages/${pageId}/webhook-checklist`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch webhook checklist';
            throw new Error(message);
        }
    },
    testMetaLeadRetrieval: async (leadId)=>{
        try {
            const response = await api.get(`/meta/debug/lead/${leadId}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch lead details';
            throw new Error(message);
        }
    },
    updateConversionApiConfiguration: async (data)=>{
        try {
            const response = await api.post('/facebook/conversion-api/configuration', data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to update Conversion API configuration';
            throw new Error(message);
        }
    },
    syncMetaLeads: async (formId, days = 7)=>{
        try {
            const response = await api.post(`/meta/forms/${formId}/sync-leads`, {
                days
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to sync leads'));
        }
    },
    createMetaCampaign: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/campaigns`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta campaign'));
        }
    },
    createMetaAdSet: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adsets`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta ad set'));
        }
    },
    updateMetaAdSet: async (adSetId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adsets/${adSetId}`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to update Meta ad set'));
        }
    },
    createMetaAd: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/ads`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta ad'));
        }
    },
    getMetaAdCreatives: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/adcreatives`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch Meta ad creatives'));
        }
    },
    createMetaAdCreativeStandalone: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adcreatives`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta ad creative'));
        }
    },
    createMetaPageForm: async (pageId, formData)=>{
        try {
            const response = await api.post(`/meta/pages/${pageId}/forms`, formData);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta Lead Form'));
        }
    },
    syncMetaAssets: async ()=>{
        try {
            const response = await api.post('/meta/ads/sync');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to sync Meta assets';
            throw new Error(message);
        }
    },
    syncMetaAdAccountDetails: async (adAccountId)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/sync`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to sync ad account details';
            throw new Error(message);
        }
    },
    subscribeMetaPage: async (pageId)=>{
        try {
            const response = await api.post(`/meta/pages/${pageId}/subscribe`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to subscribe page to webhook';
            throw new Error(message);
        }
    },
    getMetaTemplates: async ()=>{
        try {
            const response = await api.get('/meta/ads/templates');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta templates';
            throw new Error(message);
        }
    },
    launchMetaTemplate: async (adAccountId, templateId, customName)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/launch-template`, {
                template_id: templateId,
                custom_name: customName
            });
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to launch Meta template';
            throw new Error(message);
        }
    },
    deleteMetaObject: async (objectId)=>{
        try {
            const response = await api.delete(`/meta/ads/${objectId}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to delete Meta object';
            throw new Error(message);
        }
    },
    updateMetaCampaign: async (campaignId, data)=>{
        try {
            const response = await api.post(`/meta/ads/campaigns/${campaignId}`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to update Meta campaign'));
        }
    },
    createMetaCustomAudience: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/customaudiences`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta custom audience'));
        }
    },
    createMetaLookalikeAudience: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/lookalike-audiences`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta lookalike audience'));
        }
    },
    uploadMetaAdImage: async (adAccountId, image)=>{
        try {
            let response;
            if (typeof image === 'string') {
                response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adimages`, {
                    image_url: image
                });
            } else {
                const formData = new FormData();
                formData.append('image', image);
                response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adimages`, formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                });
            }
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to upload Meta ad image'));
        }
    },
    uploadMetaAdVideo: async (adAccountId, video, title)=>{
        try {
            let response;
            if (typeof video === 'string') {
                response = await api.post(`/meta/ads/adaccounts/${adAccountId}/advideos`, {
                    video_url: video,
                    title
                });
            } else {
                const formData = new FormData();
                formData.append('video', video);
                if (title) formData.append('title', title);
                response = await api.post(`/meta/ads/adaccounts/${adAccountId}/advideos`, formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                });
            }
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to upload Meta ad video'));
        }
    },
    getMetaAdPreview: async (objectId, adFormat = 'DESKTOP_FEED_STANDARD')=>{
        try {
            const response = await api.get(`/meta/ads/previews/${objectId}`, {
                params: {
                    ad_format: adFormat
                }
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch Meta ad preview'));
        }
    },
    duplicateMetaCampaign: async (campaignId, options)=>{
        try {
            const response = await api.post(`/meta/ads/campaigns/${campaignId}/duplicate`, options);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to duplicate Meta campaign'));
        }
    },
    duplicateMetaObject: async (objectId)=>{
        try {
            const response = await api.post(`/meta/ads/${objectId}/duplicate`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to duplicate Meta object'));
        }
    },
    getMetaOfflineEventSets: async (objectId)=>{
        try {
            const response = await api.get(`/meta/ads/offline-event-sets/${objectId}`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch offline event sets'));
        }
    },
    createMetaOfflineEventSet: async (businessId, data)=>{
        try {
            const response = await api.post(`/meta/ads/offline-event-sets/${businessId}`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create offline event set'));
        }
    },
    getMetaAutomatedRules: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/adrules`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch automated rules'));
        }
    },
    createMetaAutomatedRule: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adrules`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create automated rule'));
        }
    },
    deleteMetaAutomatedRule: async (ruleId)=>{
        try {
            const response = await api.delete(`/meta/ads/adrules/${ruleId}`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to delete automated rule'));
        }
    },
    getMetaFormDetails: async (formId)=>{
        try {
            const response = await api.get(`/meta/forms/${formId}`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch Meta form details'));
        }
    },
    updateMetaFormStatus: async (formId, status)=>{
        try {
            const response = await api.post(`/meta/forms/${formId}/status`, {
                status
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to update Meta form status'));
        }
    },
    // Fix 14: Track form endpoints
    trackMetaForm: async (pageId, formId, formName, pageName)=>{
        try {
            const response = await api.post(`/meta/pages/${pageId}/forms/track`, {
                form_id: formId,
                form_name: formName,
                page_name: pageName
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to track form'));
        }
    },
    getMetaTrackedForms: async (pageId)=>{
        try {
            const response = await api.get(`/meta/pages/${pageId}/forms/tracked`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to load tracked forms'));
        }
    },
    getMetaDeliveryEstimate: async (adAccountId, targetingSpec)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/delivery-estimate`, {
                params: {
                    targeting_spec: targetingSpec
                }
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch delivery estimate'));
        }
    },
    getMetaAccountAds: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/ads`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch account ads'));
        }
    },
    getMetaCampaignAds: async (campaignId)=>{
        try {
            const response = await api.get(`/meta/ads/campaigns/${campaignId}/ads`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch campaign ads'));
        }
    },
    updateMetaAd: async (adId, data)=>{
        try {
            const response = await api.post(`/meta/ads/ads/${adId}`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to update Meta ad'));
        }
    },
    // Meta Pixel Methods
    getMetaPixels: async ()=>{
        try {
            const response = await api.get('/meta/pixels');
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch Meta pixels'));
        }
    },
    sendMetaCapiEvent: async (data)=>{
        try {
            // Use the test endpoint if a code is provided, otherwise standard send
            const endpoint = data.test_event_code ? '/meta/pixels/test-event' : '/meta/pixels/send-event';
            const response = await api.post(endpoint, data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to send Meta CAPI event';
            throw new Error(message);
        }
    },
    getMetaPixelDiagnostics: async (pixelId)=>{
        try {
            const response = await api.get(`/meta/pixels/${pixelId}/diagnostics`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch pixel diagnostics'));
        }
    },
    syncMetaPixels: async ()=>{
        try {
            const response = await api.post('/meta/pixels/sync');
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to sync Meta pixels'));
        }
    },
    updateMetaPixel: async (id, data)=>{
        try {
            const response = await api.patch(`/meta/pixels/${id}`, data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to update Meta pixel';
            throw new Error(message);
        }
    },
    deleteMetaPixel: async (id)=>{
        try {
            const response = await api.delete(`/meta/pixels/${id}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to delete Meta pixel';
            throw new Error(message);
        }
    },
    getMetaPixelRoiSummary: async (days = 30)=>{
        try {
            const response = await api.get('/meta/pixels/roi-summary', {
                params: {
                    days
                }
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch ROI summary'));
        }
    },
    createMetaPixel: async (data)=>{
        try {
            const response = await api.post('/meta/pixels/create', data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create pixel'));
        }
    }
};
const companyApi = {
    getSettings: async ()=>{
        try {
            const response = await api.get('/company/settings');
            return response.data.settings;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch company settings';
            throw new Error(message);
        }
    },
    updateSettings: async (settings)=>{
        try {
            const response = await api.patch('/company/settings', settings);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to update company settings';
            throw new Error(message);
        }
    }
};
const exportLeads = async (ids)=>{
    try {
        const response = await api.post('/leads/export', {
            ids
        }, {
            responseType: 'blob',
            headers: {
                'Accept': 'text/csv',
                'Content-Type': 'application/json'
            }
        });
        // Get filename from response headers or use default
        const filename = response.headers['content-disposition']?.split('filename=')[1] || `leads-${new Date().toISOString().split('T')[0]}.csv`;
        // Create download link
        const blob = new Blob([
            response.data
        ], {
            type: 'text/csv'
        });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', filename);
        // Trigger download
        document.body.appendChild(link);
        link.click();
        // Cleanup
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
        return true;
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Export error:', error);
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isAxiosError(error)) {
            // Handle different error types
            if (error.response?.status === 404) {
                throw new Error('No leads found to export.');
            }
            throw new Error('Failed to export leads. Please try again.');
        }
        throw new Error('An unexpected error occurred during export.');
    }
};
const me = async ()=>{
    const response = await api.get('/user', {
        headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`
        }
    });
    return response.data;
};
const sendMessage = async (data)=>{
    const response = await api.post('/send-message', data);
    return response.data;
};
const authorize = async (data)=>{
    const response = await api.post('/broadcasting/auth', data);
    return response.data;
};
const getMessages = async (data)=>{
    const response = await api.post('/messages', data);
    return response.data;
};
const initializeChat = async (data)=>{
    const response = await api.post('/initialize-chat', data);
    return response.data;
};
const getLeadsWithLatestMessages = async ()=>{
    try {
        const response = await api.get('/conversations', {
            headers: {
                Authorization: `Bearer ${localStorage.getItem('token')}`
            }
        });
        return response.data;
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Error fetching conversations:', error);
        throw error;
    }
};
const getConversationMessages = async (conversationId, lastTimestamp)=>{
    try {
        const response = await api.get(`/conversations/${conversationId}/messages`, {
            headers: {
                Authorization: `Bearer ${localStorage.getItem('token')}`
            },
            params: {
                after: lastTimestamp
            }
        });
        return response.data;
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Error fetching messages:', error);
        throw error;
    }
};
const getBookings = async (params)=>{
    return api.get('/bookings', {
        params
    });
};
const deleteBooking = async (id)=>{
    return api.delete(`/bookings/${id}`);
};
const updateBooking = async (id, data)=>{
    return api.put(`/bookings/${id}`, data);
};
const rescheduleBooking = async (id, data)=>{
    return api.patch(`/bookings/${id}/reschedule`, data);
};
const teamApi = {
    getMembers: async ()=>{
        const response = await api.get('/team');
        return response.data.members;
    },
    inviteMember: async (data)=>{
        const response = await api.post('/team/invite', data);
        return response.data;
    },
    resendInvite: async (id)=>{
        const response = await api.post(`/team/${id}/resend-invite`);
        return response.data;
    },
    updateRole: async (id, role)=>{
        const response = await api.patch(`/team/${id}/role`, {
            role
        });
        return response.data;
    },
    removeMember: async (id)=>{
        const response = await api.delete(`/team/${id}`);
        return response.data;
    },
    setupAccount: async (data)=>{
        try {
            const response = await api.post('/setup-account', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to setup account');
        }
    }
};
const adminApi = {
    getStats: async ()=>{
        try {
            const response = await api.get('/admin/stats');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch admin stats');
        }
    },
    getCompanies: async (page = 1, limit = 10, search, plan, status, tag, expiration, started, expStart, expEnd, startStart, startEnd)=>{
        try {
            let url = `/admin/companies?page=${page}&limit=${limit}`;
            if (search) url += `&search=${search}`;
            if (plan && plan !== 'all') url += `&plan=${plan}`;
            if (status && status !== 'all') url += `&status=${status}`;
            if (tag && tag !== 'all') url += `&tag=${tag}`;
            if (expiration && expiration !== 'all') url += `&expiration=${expiration}`;
            if (started && started !== 'all') url += `&started=${started}`;
            if (expStart) url += `&exp_start=${expStart}`;
            if (expEnd) url += `&exp_end=${expEnd}`;
            if (startStart) url += `&start_start=${startStart}`;
            if (startEnd) url += `&start_end=${startEnd}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch companies');
        }
    },
    updateCompany: async (id, data)=>{
        try {
            const response = await api.patch(`/admin/companies/${id}`, data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update company');
        }
    },
    getUsers: async (page = 1, limit = 10, search, tag, role, status, userType)=>{
        try {
            let url = `/admin/users?page=${page}&limit=${limit}`;
            if (search) url += `&search=${search}`;
            if (tag && tag !== 'all') url += `&tag=${tag}`;
            if (role && role !== 'all') url += `&role=${role}`;
            if (status && status !== 'all') url += `&status=${status}`;
            if (userType && userType !== 'all') url += `&user_type=${userType}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch users');
        }
    },
    updateUser: async (id, data)=>{
        try {
            const response = await api.patch(`/admin/users/${id}`, data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update user');
        }
    },
    getTesterRequests: async (page = 1, limit = 10, search)=>{
        try {
            let url = `/admin/tester-requests?page=${page}&limit=${limit}`;
            if (search) url += `&search=${search}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch tester requests');
        }
    },
    updateTesterRequestStatus: async (id, status)=>{
        try {
            const response = await api.patch(`/admin/tester-requests/${id}/status`, {
                status
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update status');
        }
    },
    deleteUser: async (id)=>{
        try {
            const response = await api.delete(`/admin/users/${id}`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to delete user');
        }
    },
    getEmailStats: async (search, page = 1, limit = 10, filterStatus = 'all')=>{
        try {
            const response = await api.get('/admin/email-stats', {
                params: {
                    search,
                    page,
                    limit,
                    filterStatus
                }
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch email stats');
        }
    },
    toggleUserNotification: async (userId, type = 'new_lead')=>{
        try {
            const response = await api.post(`/admin/users/${userId}/toggle-notification`, {
                type
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to toggle notification');
        }
    },
    toggleCompanyEmail: async (id)=>{
        try {
            const response = await api.post(`/admin/companies/${id}/toggle-email`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to toggle company email');
        }
    },
    deleteCompany: async (id)=>{
        try {
            const response = await api.delete(`/admin/companies/${id}`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to delete company');
        }
    },
    renewCompany: async (id, days, notes)=>{
        try {
            const response = await api.post(`/admin/companies/${id}/renew`, {
                days,
                notes
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to renew company');
        }
    },
    getCompanyHistory: async (id)=>{
        try {
            const response = await api.get(`/admin/companies/${id}/history`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch subscription history');
        }
    },
    loginAsAnyUser: async (id)=>{
        try {
            const response = await api.post(`/admin/users/${id}/login`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to impersonate user');
        }
    },
    getBilling: async (page = 1, limit = 10, search)=>{
        try {
            const url = `/admin/billing?page=${page}&limit=${limit}${search ? `&search=${search}` : ''}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch billing data');
        }
    },
    getPendingPayments: async (page = 1, limit = 10)=>{
        try {
            const url = `/admin/payments/pending?page=${page}&limit=${limit}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch pending payments');
        }
    },
    approvePayment: async (id)=>{
        try {
            const response = await api.post(`/admin/payments/${id}/approve`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to approve payment');
        }
    },
    getPlans: async ()=>{
        try {
            const response = await api.get('/admin/plans');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch plans');
        }
    },
    createPlan: async (data)=>{
        try {
            const response = await api.post('/admin/plans', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to create plan');
        }
    },
    updatePlan: async (id, data)=>{
        try {
            const response = await api.patch(`/admin/plans/${id}`, data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update plan');
        }
    },
    getTags: async ()=>{
        try {
            const response = await api.get('/admin/tags');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch tags');
        }
    },
    sendBroadcast: async (data)=>{
        try {
            const response = await api.post('/admin/broadcast', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to send broadcast');
        }
    },
    getBroadcastHistory: async ()=>{
        try {
            const response = await api.get('/admin/broadcast/history');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch broadcast history');
        }
    },
    // Coupons
    getCoupons: async ()=>{
        try {
            const response = await api.get('/admin/payments/coupons');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch coupons');
        }
    },
    createCoupon: async (data)=>{
        try {
            const response = await api.post('/admin/payments/coupons', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to create coupon');
        }
    },
    updateCoupon: async (id, data)=>{
        try {
            const response = await api.patch(`/admin/payments/coupons/${id}`, data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update coupon');
        }
    },
    deleteCoupon: async (id)=>{
        try {
            const response = await api.delete(`/admin/payments/coupons/${id}`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to delete coupon');
        }
    },
    // Settings
    getSettings: async ()=>{
        try {
            const response = await api.get('/admin/payments/settings');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch settings');
        }
    },
    updateSettings: async (data)=>{
        try {
            const response = await api.post('/admin/payments/settings', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update settings');
        }
    }
};
const agencyApi = {
    getClients: async ()=>{
        try {
            const response = await api.get('/agency/clients');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch clients');
        }
    },
    onboardClient: async (data)=>{
        try {
            const response = await api.post('/agency/onboard', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to onboard client');
        }
    },
    getStats: async ()=>{
        try {
            const response = await api.get('/agency/stats');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch agency stats');
        }
    },
    loginAsClient: async (id)=>{
        try {
            const response = await api.post(`/agency/clients/${id}/login`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to impersonate client');
        }
    },
    deleteClient: async (id)=>{
        try {
            const response = await api.delete(`/agency/clients/${id}`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to delete client');
        }
    },
    renewClient: async (id)=>{
        try {
            const response = await api.post(`/agency/clients/${id}/renew`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to renew client');
        }
    },
    getClientHistory: async (id)=>{
        try {
            const response = await api.get(`/agency/clients/${id}/history`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch history');
        }
    }
};
const __TURBOPACK__default__export__ = api;
const getDashboardStats = async ()=>{
    const response = await api.get('/dashboard/stats');
    return response.data;
};
const getAnalyticsData = async ()=>{
    const response = await api.get('/analytics');
    return response.data;
};
const financeApi = {
    // ── Dashboard ─────────────────────────────────────────────────────────────
    getDashboard: (month, year)=>api.get('/super-admin/finance/dashboard', {
            params: {
                month,
                year
            }
        }).then((r)=>r.data),
    // ── Expense Categories ────────────────────────────────────────────────────
    getCategories: ()=>api.get('/super-admin/finance/categories').then((r)=>r.data),
    createCategory: (data)=>api.post('/super-admin/finance/categories', data).then((r)=>r.data),
    updateCategory: (id, data)=>api.put(`/super-admin/finance/categories/${id}`, data).then((r)=>r.data),
    deleteCategory: (id)=>api.delete(`/super-admin/finance/categories/${id}`).then((r)=>r.data),
    // ── Expenses ──────────────────────────────────────────────────────────────
    getExpenses: (params)=>api.get('/super-admin/finance/expenses', {
            params
        }).then((r)=>r.data),
    createExpense: (data)=>api.post('/super-admin/finance/expenses', data).then((r)=>r.data),
    updateExpense: (id, data)=>api.put(`/super-admin/finance/expenses/${id}`, data).then((r)=>r.data),
    deleteExpense: (id)=>api.delete(`/super-admin/finance/expenses/${id}`).then((r)=>r.data),
    uploadReceipt: (id, file)=>{
        const fd = new FormData();
        fd.append('receipt', file);
        return api.post(`/super-admin/finance/expenses/${id}/upload-receipt`, fd, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        }).then((r)=>r.data);
    },
    getDailyExpenses: (date)=>api.get(`/super-admin/finance/expenses/daily/${date}`).then((r)=>r.data),
    getMonthlyExpenses: (month, year)=>api.get(`/super-admin/finance/expenses/monthly/${month}/${year}`).then((r)=>r.data),
    getRecurringExpenses: ()=>api.get('/super-admin/finance/expenses/recurring').then((r)=>r.data),
    // ── Employees ─────────────────────────────────────────────────────────────
    getEmployees: (params)=>api.get('/super-admin/finance/employees', {
            params
        }).then((r)=>r.data),
    createEmployee: (data)=>api.post('/super-admin/finance/employees', data).then((r)=>r.data),
    updateEmployee: (id, data)=>api.put(`/super-admin/finance/employees/${id}`, data).then((r)=>r.data),
    deleteEmployee: (id)=>api.delete(`/super-admin/finance/employees/${id}`).then((r)=>r.data),
    getEmployeeSalaryHistory: (id)=>api.get(`/super-admin/finance/employees/${id}/salary-history`).then((r)=>r.data),
    toggleEmployeeActive: (id)=>api.post(`/super-admin/finance/employees/${id}/toggle-active`).then((r)=>r.data),
    getEmployeeRevisions: (id)=>api.get(`/super-admin/finance/employees/${id}/revisions`).then((r)=>r.data),
    addEmployeeRevision: (id, data)=>api.post(`/super-admin/finance/employees/${id}/revisions`, data).then((r)=>r.data),
    // ── Payroll ───────────────────────────────────────────────────────────────
    getPayrollCycle: (month, year)=>api.get(`/super-admin/finance/payroll/cycle/${month}/${year}`).then((r)=>r.data),
    generatePayroll: (month, year)=>api.post(`/super-admin/finance/payroll/generate/${month}/${year}`).then((r)=>r.data),
    markPayoutPaid: (payoutId, data)=>api.put(`/super-admin/finance/payroll/${payoutId}/mark-paid`, data).then((r)=>r.data),
    updatePayoutStatus: (payoutId, status)=>api.put(`/super-admin/finance/payroll/${payoutId}/status`, {
            status
        }).then((r)=>r.data),
    uploadPayoutProof: (payoutId, file)=>{
        const fd = new FormData();
        fd.append('proof', file);
        return api.post(`/super-admin/finance/payroll/${payoutId}/upload-proof`, fd, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        }).then((r)=>r.data);
    },
    getPayrollAnnualSummary: (year)=>api.get(`/super-admin/finance/payroll/summary/${year}`).then((r)=>r.data),
    // ── Revenue & MRR (Phase 2) ────────────────────────────────────────────────
    getRevenueCompanies: ()=>api.get('/super-admin/finance/revenue/companies').then((r)=>r.data),
    getMrrBreakdown: ()=>api.get('/super-admin/finance/revenue/mrr').then((r)=>r.data),
    getMrrHistory: ()=>api.get('/super-admin/finance/revenue/mrr/history').then((r)=>r.data),
    getSubscriptions: (params)=>api.get('/super-admin/finance/revenue/subscriptions', {
            params
        }).then((r)=>r.data),
    manualRenewal: (data)=>api.post('/super-admin/finance/revenue/renewals', data).then((r)=>r.data),
    getRevenueAdjustments: (params)=>api.get('/super-admin/finance/revenue/adjustments', {
            params
        }).then((r)=>r.data),
    createRevenueAdjustment: (data)=>api.post('/super-admin/finance/revenue/adjustments', data).then((r)=>r.data),
    getRevenueTarget: (month, year)=>api.get(`/super-admin/finance/revenue/targets/${month}/${year}`).then((r)=>r.data),
    setRevenueTarget: (data)=>api.post('/super-admin/finance/revenue/targets', data).then((r)=>r.data),
    getUpgradeLog: (month, year)=>api.get('/super-admin/finance/revenue/upgrade-log', {
            params: {
                month,
                year
            }
        }).then((r)=>r.data),
    // ── Churn Tracking (Phase 2) ──────────────────────────────────────────────
    getChurnLog: (params)=>api.get('/super-admin/finance/churn', {
            params
        }).then((r)=>r.data),
    tagChurnReason: (id, data)=>api.post(`/super-admin/finance/churn/${id}/reason`, data).then((r)=>r.data),
    detectChurn: ()=>api.post('/super-admin/finance/churn/detect').then((r)=>r.data),
    // ── Plans & Pricing (Phase 2) ─────────────────────────────────────────────
    getPlans: ()=>api.get('/super-admin/finance/plans').then((r)=>r.data),
    updatePlanPricing: (data)=>api.put('/super-admin/finance/plans/pricing', data).then((r)=>r.data),
    getPlanPricingHistory: (params)=>api.get('/super-admin/finance/plans/pricing/history', {
            params
        }).then((r)=>r.data),
    // ── Reports (Phase 2) ─────────────────────────────────────────────────────
    getMonthlyPlReport: (month, year)=>api.get(`/super-admin/finance/reports/pl/${month}/${year}`).then((r)=>r.data),
    getAnnualReport: (year)=>api.get(`/super-admin/finance/reports/annual/${year}`).then((r)=>r.data),
    getPayrollReport: (year)=>api.get(`/super-admin/finance/reports/payroll/${year}`).then((r)=>r.data),
    getGstReport: (month, year)=>api.get(`/super-admin/finance/reports/gst/${month}/${year}`).then((r)=>r.data)
};
const googleIntegrationApi = {
    getStatus: async ()=>{
        try {
            const response = await api.get('/google/status');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch Google status';
            throw new Error(message);
        }
    },
    disconnect: async ()=>{
        try {
            const response = await api.delete('/google/disconnect');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to disconnect Google account';
            throw new Error(message);
        }
    },
    getConnectUrl: async (scope)=>{
        try {
            const response = await api.get('/google/connect', {
                params: {
                    scope
                }
            });
            return response.data.url;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to get connection URL';
            throw new Error(message);
        }
    }
};
const subscriptionApi = {
    getSettings: async ()=>{
        try {
            const response = await api.get('/subscription/settings');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch subscription settings');
        }
    },
    validateCoupon: async (couponCode)=>{
        try {
            const response = await api.post('/subscription/validate-coupon', {
                coupon_code: couponCode
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to validate coupon');
        }
    }
};
const evolutionApi = {
    getAccounts: async ()=>{
        const response = await api.get('/evolution/accounts');
        return response.data;
    },
    createAccount: async (phoneNumber)=>{
        const response = await api.post('/evolution/accounts', {
            phone_number: phoneNumber
        });
        return response.data;
    },
    connectInstance: async (instanceName)=>{
        const response = await api.post(`/evolution/accounts/${instanceName}/connect`);
        return response.data;
    },
    getQrCode: async (instanceName)=>{
        const response = await api.get(`/evolution/accounts/${instanceName}/qrcode`);
        return response.data;
    },
    getStatus: async (instanceName)=>{
        const response = await api.get(`/evolution/accounts/${instanceName}/status`);
        return response.data;
    },
    disconnectInstance: async (instanceName)=>{
        const response = await api.post(`/evolution/accounts/${instanceName}/disconnect`);
        return response.data;
    },
    deleteAccount: async (instanceName)=>{
        const response = await api.delete(`/evolution/accounts/${instanceName}`);
        return response.data;
    },
    getConversations: async ()=>{
        const response = await api.get('/evolution/inbox/conversations');
        return response.data;
    },
    getMessages: async (conversationId)=>{
        const response = await api.get(`/evolution/inbox/conversations/${conversationId}/messages`);
        return response.data;
    },
    sendMessage: async (conversationId, message)=>{
        const response = await api.post('/evolution/inbox/messages/send', {
            conversation_id: conversationId,
            message
        });
        return response.data;
    },
    deleteConversation: async (conversationId)=>{
        const response = await api.delete(`/evolution/inbox/conversations/${conversationId}`);
        return response.data;
    },
    clearSession: async (conversationId)=>{
        const response = await api.post('/evolution/inbox/session/clear', {
            conversation_id: conversationId
        });
        return response.data;
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/contexts/UserContext.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "UserProvider": (()=>UserProvider),
    "useUser": (()=>useUser)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/logger.ts [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature(), _s1 = __turbopack_refresh__.signature();
"use client";
;
;
;
const UserContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function UserProvider({ children }) {
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "UserProvider.useEffect": ()=>{
            const fetchUser = {
                "UserProvider.useEffect.fetchUser": async ()=>{
                    try {
                        const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUser"])();
                        setUser(data);
                    } catch (error) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Failed to fetch user', error);
                    } finally{
                        setIsLoading(false);
                    }
                }
            }["UserProvider.useEffect.fetchUser"];
            fetchUser();
        }
    }["UserProvider.useEffect"], []);
    const hasRole = (roles)=>{
        if (!user) return false;
        // Normalize user role from backend
        const normalizedUserRole = user.role.toLowerCase().replace(/_/g, ' ');
        return roles.some((role)=>{
            const normalizedAllowedRole = role.toLowerCase().replace(/_/g, ' ');
            return normalizedUserRole === normalizedAllowedRole;
        });
    };
    const hasType = (types)=>{
        if (!user) return false;
        return types.includes(user.user_type);
    };
    const hasPlan = (plans)=>{
        if (!user || !user.company?.plan) return false;
        return plans.includes(user.company.plan.toLowerCase());
    };
    const hasFeature = (feature)=>{
        if (!user) return false;
        // Super Admin always has all features
        if (user.role === 'Super Admin') return true;
        // Check if feature exists in plan_details
        const planFeatures = user.company?.plan_details?.features;
        // Structured format: { display: [], permissions: { key: roles } }
        if (planFeatures && typeof planFeatures === 'object' && !Array.isArray(planFeatures)) {
            const permissions = planFeatures.permissions || {};
            const allowedRoles = permissions[feature];
            if (!allowedRoles) return false;
            if (allowedRoles.includes('*')) return true;
            // Normalize role for comparison
            const userRole = user.role.toLowerCase().replace(/_/g, ' ');
            return allowedRoles.some((r)=>r.toLowerCase().replace(/_/g, ' ') === userRole);
        }
        // Fallback for legacy simple array format
        if (Array.isArray(planFeatures)) {
            return planFeatures.includes(feature);
        }
        return false;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(UserContext.Provider, {
        value: {
            user,
            isLoading,
            hasRole,
            hasType,
            hasPlan,
            hasFeature
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/contexts/UserContext.tsx",
        lineNumber: 121,
        columnNumber: 5
    }, this);
}
_s(UserProvider, "YajQB7LURzRD+QP5gw0+K2TZIWA=");
_c = UserProvider;
function useUser() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(UserContext);
    if (context === undefined) {
        throw new Error('useUser must be used within a UserProvider');
    }
    return context;
}
_s1(useUser, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_refresh__.register(_c, "UserProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/sidebar.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Sidebar": (()=>Sidebar)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/auth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/contexts/UserContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
;
;
;
;
const mainNav = [
    {
        name: 'Dashboard',
        href: '/dashboard',
        iconClass: 'ti ti-layout-dashboard',
        roles: [
            'Super Admin',
            'Admin',
            'Manager',
            'Agent'
        ],
        feature: 'dashboard'
    },
    {
        name: 'Leads',
        href: '/leads',
        iconClass: 'ti ti-users',
        roles: [
            'Super Admin',
            'Admin',
            'Manager',
            'Agent'
        ],
        feature: 'leads'
    },
    {
        name: 'Live Chat',
        href: '/live-chat',
        iconClass: 'ti ti-brand-whatsapp',
        roles: [
            'Super Admin',
            'Admin',
            'Manager',
            'Agent'
        ],
        feature: 'live_chat'
    },
    {
        name: 'Evolution Inbox',
        href: '/evolution/inbox',
        iconClass: 'ti ti-message-circle',
        roles: [
            'Super Admin',
            'Admin',
            'Manager',
            'Agent'
        ],
        feature: 'live_chat'
    },
    {
        name: 'Chatbot',
        href: '/chatbot',
        iconClass: 'ti ti-robot',
        roles: [
            'Super Admin',
            'Admin',
            'Manager'
        ],
        types: [
            'agency',
            'super_admin',
            'individual'
        ],
        feature: 'chatbot'
    },
    {
        name: 'Evolution Chatbot',
        href: '/evolution/chatbot',
        iconClass: 'ti ti-robot-face',
        roles: [
            'Super Admin',
            'Admin',
            'Manager'
        ],
        types: [
            'agency',
            'super_admin',
            'individual'
        ],
        feature: 'chatbot'
    },
    {
        name: 'Meetings',
        href: '/meetings',
        iconClass: 'ti ti-calendar-event',
        roles: [
            'Super Admin',
            'Admin',
            'Manager',
            'Agent'
        ],
        feature: 'meetings'
    }
];
const sidebarSections = [
    {
        label: 'Clients & Growth',
        items: [
            {
                name: 'Clients',
                href: '/agency',
                iconClass: 'ti ti-briefcase',
                roles: [
                    'Super Admin',
                    'Admin'
                ],
                types: [
                    'agency',
                    'super_admin'
                ],
                feature: 'agency_management'
            },
            {
                name: 'Analytics',
                href: '/analytics',
                iconClass: 'ti ti-chart-arrows',
                roles: [
                    'Super Admin',
                    'Admin',
                    'Manager'
                ],
                types: [
                    'agency',
                    'super_admin',
                    'individual'
                ],
                feature: 'analytics'
            }
        ]
    },
    {
        label: 'Organization',
        items: [
            {
                name: 'Team',
                href: '/team',
                iconClass: 'ti ti-users-group',
                roles: [
                    'Super Admin',
                    'Admin'
                ],
                feature: 'team_management'
            }
        ]
    },
    {
        label: 'Automation',
        items: [
            {
                name: 'Automations',
                href: '/automations',
                iconClass: 'ti ti-bolt',
                roles: [
                    'Super Admin',
                    'Admin'
                ],
                types: [
                    'agency',
                    'super_admin',
                    'individual'
                ],
                feature: 'automations'
            }
        ]
    },
    {
        label: 'Platform Control',
        items: [
            {
                name: 'Admin',
                href: '/admin',
                iconClass: 'ti ti-shield',
                roles: [
                    'Super Admin'
                ],
                types: [
                    'super_admin'
                ],
                feature: 'system_admin',
                exact: true
            },
            {
                name: 'Emails',
                href: '/admin/emails',
                iconClass: 'ti ti-mail',
                roles: [
                    'Super Admin'
                ],
                types: [
                    'super_admin'
                ],
                feature: 'email_logs'
            },
            {
                name: 'Error Logs',
                href: '/admin/errors',
                iconClass: 'ti ti-activity',
                roles: [
                    'Super Admin'
                ],
                types: [
                    'super_admin'
                ],
                feature: 'error_logs'
            },
            {
                name: 'Finance',
                href: '/admin/finance/dashboard',
                iconClass: 'ti ti-currency-dollar',
                roles: [
                    'Super Admin'
                ],
                types: [
                    'super_admin'
                ],
                feature: 'finance_module'
            },
            {
                name: 'Payments',
                href: '/admin/payments',
                iconClass: 'ti ti-cash',
                roles: [
                    'Super Admin'
                ],
                types: [
                    'super_admin'
                ],
                feature: 'system_admin'
            },
            {
                name: 'Dev Hub',
                href: '/developer',
                iconClass: 'ti ti-code',
                roles: [
                    'Super Admin',
                    'Admin'
                ],
                feature: 'developer_tools'
            }
        ]
    },
    {
        label: 'Integrations',
        items: [
            {
                name: 'LB Forms',
                href: '/lb-forms',
                iconClass: 'ti ti-file-description',
                roles: [
                    'Super Admin',
                    'Admin',
                    'Manager'
                ],
                types: [
                    'agency',
                    'super_admin',
                    'individual'
                ],
                feature: 'integrations'
            },
            {
                name: 'WhatsApp Cloud API',
                href: '/integrations/whatsapp',
                iconClass: 'ti ti-brand-whatsapp',
                roles: [
                    'Super Admin',
                    'Admin',
                    'Manager'
                ],
                types: [
                    'agency',
                    'super_admin',
                    'individual'
                ],
                feature: 'integrations'
            },
            {
                name: 'WhatsApp (Evolution)',
                href: '/integrations/evolution',
                iconClass: 'ti ti-brand-whatsapp',
                roles: [
                    'Super Admin',
                    'Admin',
                    'Manager'
                ],
                types: [
                    'agency',
                    'super_admin',
                    'individual'
                ],
                feature: 'integrations'
            },
            {
                name: 'Facebook Lead Forms',
                href: '/integrations/facebook-lead-forms',
                iconClass: 'ti ti-brand-facebook',
                roles: [
                    'Super Admin',
                    'Admin',
                    'Manager'
                ],
                types: [
                    'agency',
                    'super_admin',
                    'individual'
                ],
                feature: 'integrations'
            },
            {
                name: 'Meta Conversion API',
                href: '/integrations/meta-capi',
                iconClass: 'ti ti-brand-meta',
                roles: [
                    'Super Admin',
                    'Admin',
                    'Manager'
                ],
                types: [
                    'agency',
                    'super_admin',
                    'individual'
                ],
                feature: 'integrations'
            },
            {
                name: 'Webhooks',
                href: '/integrations/webhooks',
                iconClass: 'ti ti-webhook',
                roles: [
                    'Super Admin',
                    'Admin',
                    'Manager'
                ],
                types: [
                    'agency',
                    'super_admin',
                    'individual'
                ],
                feature: 'integrations'
            },
            {
                name: 'Email Marketing',
                href: '/integrations/email-marketing',
                iconClass: 'ti ti-mail',
                roles: [
                    'Super Admin',
                    'Admin',
                    'Manager'
                ],
                types: [
                    'agency',
                    'super_admin',
                    'individual'
                ],
                feature: 'integrations'
            },
            {
                name: 'Facebook Auth',
                href: '/integrations/facebook-auth',
                iconClass: 'ti ti-brand-facebook',
                roles: [
                    'Super Admin',
                    'Admin',
                    'Manager'
                ],
                types: [
                    'agency',
                    'super_admin',
                    'individual'
                ],
                feature: 'integrations'
            },
            {
                name: 'Integrations',
                href: '/integrations',
                iconClass: 'ti ti-puzzle',
                roles: [
                    'Super Admin',
                    'Admin'
                ],
                types: [
                    'agency',
                    'super_admin',
                    'individual'
                ],
                feature: 'integrations',
                exact: true
            },
            {
                name: 'WhatsApp Bot',
                href: '/whatsapp-bot',
                iconClass: 'ti ti-brand-whatsapp',
                roles: [
                    'Super Admin',
                    'Admin'
                ],
                types: [
                    'agency',
                    'super_admin',
                    'individual'
                ],
                feature: 'whatsapp_bot'
            }
        ]
    },
    {
        label: 'Account',
        items: [
            {
                name: 'Settings',
                href: '/settings',
                iconClass: 'ti ti-settings',
                roles: [
                    'Super Admin',
                    'Admin',
                    'Manager',
                    'Agent'
                ],
                feature: 'account_settings'
            }
        ]
    }
];
function Sidebar({ mobileOpen, setMobileOpen, isCollapsed = false, setIsCollapsed }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const { user, hasRole, hasType, hasPlan, hasFeature } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUser"])();
    const [isAdminImpersonating, setIsAdminImpersonating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [lbFormsEnabled, setLbFormsEnabled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [whatsappEnabled, setWhatsappEnabled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [leadFormsEnabled, setLeadFormsEnabled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [metaCapiEnabled, setMetaCapiEnabled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [webhooksEnabled, setWebhooksEnabled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [emailEnabled, setEmailEnabled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [fbAuthEnabled, setFbAuthEnabled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [evolutionEnabled, setEvolutionEnabled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Sidebar.useEffect": ()=>{
            setIsAdminImpersonating(!!localStorage.getItem('admin_token'));
            const checkIntegrations = {
                "Sidebar.useEffect.checkIntegrations": async ()=>{
                    try {
                        const integrations = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["integrationApi"].getConnectedIntegrations();
                        setLbFormsEnabled(integrations.some({
                            "Sidebar.useEffect.checkIntegrations": (i)=>i.type === 'lb_forms' && i.is_active
                        }["Sidebar.useEffect.checkIntegrations"]));
                        setWhatsappEnabled(integrations.some({
                            "Sidebar.useEffect.checkIntegrations": (i)=>i.type === 'whatsapp' && i.is_active
                        }["Sidebar.useEffect.checkIntegrations"]));
                        setLeadFormsEnabled(integrations.some({
                            "Sidebar.useEffect.checkIntegrations": (i)=>i.type === 'leadform' && i.is_active
                        }["Sidebar.useEffect.checkIntegrations"]));
                        setMetaCapiEnabled(integrations.some({
                            "Sidebar.useEffect.checkIntegrations": (i)=>i.type === 'facebook_conversion_api' && i.is_active
                        }["Sidebar.useEffect.checkIntegrations"]));
                        setWebhooksEnabled(integrations.some({
                            "Sidebar.useEffect.checkIntegrations": (i)=>i.type === 'webhook' && i.is_active
                        }["Sidebar.useEffect.checkIntegrations"]));
                        setEmailEnabled(integrations.some({
                            "Sidebar.useEffect.checkIntegrations": (i)=>i.type === 'email' && i.is_active
                        }["Sidebar.useEffect.checkIntegrations"]));
                        // Note: facebook_auth might have a different type in DB, checking for 'facebook_auth'
                        setFbAuthEnabled(integrations.some({
                            "Sidebar.useEffect.checkIntegrations": (i)=>i.type === 'facebook_auth' && i.is_active
                        }["Sidebar.useEffect.checkIntegrations"]));
                        setEvolutionEnabled(integrations.some({
                            "Sidebar.useEffect.checkIntegrations": (i)=>i.type === 'evolution' && i.is_active
                        }["Sidebar.useEffect.checkIntegrations"]));
                    } catch (e) {
                    // ignore
                    }
                }
            }["Sidebar.useEffect.checkIntegrations"];
            checkIntegrations();
            window.addEventListener('integrationsUpdated', checkIntegrations);
            return ({
                "Sidebar.useEffect": ()=>window.removeEventListener('integrationsUpdated', checkIntegrations)
            })["Sidebar.useEffect"];
        }
    }["Sidebar.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Sidebar.useEffect": ()=>{
            setMobileOpen?.(false);
        }
    }["Sidebar.useEffect"], [
        pathname,
        setMobileOpen
    ]);
    const handleLogout = async ()=>{
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logout"])();
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSession"])();
            localStorage.removeItem('admin_token');
            router.push('/signin');
        } catch (err) {
            console.error('Logout failed:', err);
        }
    };
    const handleReturnToAdmin = ()=>{
        const adminToken = localStorage.getItem('admin_token');
        if (adminToken) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setSession"])(adminToken);
            localStorage.removeItem('admin_token');
            window.location.href = '/dashboard';
        }
    };
    const canSee = (item)=>{
        if (item.name === 'LB Forms' && !lbFormsEnabled) return false;
        if (item.name === 'WhatsApp Cloud API' && !whatsappEnabled) return false;
        if (item.name === 'Facebook Lead Forms' && !leadFormsEnabled) return false;
        if (item.name === 'Meta Conversion API' && !metaCapiEnabled) return false;
        if (item.name === 'Webhooks' && !webhooksEnabled) return false;
        if (item.name === 'Email Marketing' && !emailEnabled) return false;
        if (item.name === 'Facebook Auth' && !fbAuthEnabled) return false;
        // Filter evolution features based on enabled status
        if ((item.href.startsWith('/evolution/inbox') || item.href.startsWith('/evolution/chatbot')) && !evolutionEnabled) {
            return false;
        }
        if (item.name === 'WhatsApp (Evolution)' && !evolutionEnabled) return false;
        const roleMatch = hasRole(item.roles);
        const typeMatch = !item.types || hasType(item.types);
        const featureMatch = !item.feature || hasFeature(item.feature);
        const planMatch = !item.plans || hasPlan(item.plans) || hasType([
            'agency',
            'super_admin'
        ]);
        return roleMatch && typeMatch && featureMatch && planMatch;
    };
    const visibleMain = mainNav.filter(canSee);
    const visibleSections = sidebarSections.map((s)=>({
            ...s,
            items: s.items.filter(canSee)
        })).filter((s)=>s.items.length > 0);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
            style: {
                width: isCollapsed ? '64px' : '220px'
            },
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("sidebar fixed lg:relative z-[100] h-screen transition-all duration-300 flex flex-col", mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "sidebar-top relative flex h-[56px] items-center px-4 border-b border-[var(--crm-border)] shrink-0",
                    children: [
                        !isCollapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2 overflow-hidden whitespace-nowrap w-full",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: "/logo-sm.png",
                                    alt: "LeadBajaar",
                                    className: "h-7 w-auto object-contain shrink-0"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/sidebar.tsx",
                                    lineNumber: 203,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-[15px] font-extrabold tracking-tight text-[var(--crm-text-primary)] truncate",
                                    children: "LeadBajaar"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/sidebar.tsx",
                                    lineNumber: 204,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/sidebar.tsx",
                            lineNumber: 202,
                            columnNumber: 13
                        }, this),
                        isCollapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-center shrink-0 w-full",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: "/logo-sm.png",
                                alt: "LB",
                                className: "h-7 w-auto object-contain"
                            }, void 0, false, {
                                fileName: "[project]/src/components/sidebar.tsx",
                                lineNumber: 209,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/sidebar.tsx",
                            lineNumber: 208,
                            columnNumber: 13
                        }, this),
                        setIsCollapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setIsCollapsed(!isCollapsed),
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("hidden lg:flex items-center justify-center text-[var(--crm-text-secondary)] hover:bg-[var(--crm-surface-3)] hover:text-[var(--crm-text-primary)] transition-colors shrink-0", isCollapsed ? "absolute -right-3 top-1/2 -translate-y-1/2 bg-[var(--crm-surface-1)] border border-[var(--crm-border)] shadow-sm rounded-full w-6 h-6 z-50" : "ml-auto w-6 h-6 rounded-[var(--r-sm)]"),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("ti", isCollapsed ? "ti-chevron-right text-[12px]" : "ti-layout-sidebar-right-collapse text-lg")
                            }, void 0, false, {
                                fileName: "[project]/src/components/sidebar.tsx",
                                lineNumber: 222,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/sidebar.tsx",
                            lineNumber: 213,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setMobileOpen?.(false),
                            className: "lg:hidden ml-auto text-[var(--crm-text-secondary)] hover:text-[var(--crm-text-primary)]",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                className: "ti ti-x"
                            }, void 0, false, {
                                fileName: "[project]/src/components/sidebar.tsx",
                                lineNumber: 229,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/sidebar.tsx",
                            lineNumber: 225,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/sidebar.tsx",
                    lineNumber: 200,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 overflow-y-auto no-scrollbar py-2",
                    children: [
                        isAdminImpersonating && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-2 mb-2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleReturnToAdmin,
                                className: "w-full flex items-center gap-2.5 px-2 py-1.5 rounded-md text-[13px] font-medium text-amber-500 hover:bg-amber-50",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                        className: "ti ti-corner-up-left"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/sidebar.tsx",
                                        lineNumber: 240,
                                        columnNumber: 19
                                    }, this),
                                    " Return to Admin"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/sidebar.tsx",
                                lineNumber: 236,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/sidebar.tsx",
                            lineNumber: 235,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-2 space-y-0.5",
                            children: visibleMain.map((item)=>{
                                const isActive = item.exact ? pathname === item.href : pathname === item.href || pathname.startsWith(`${item.href}/`);
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: item.href,
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("group flex items-center gap-2.5 px-2 py-1.5 rounded-[var(--r-md)] text-[13px] font-medium transition-all duration-150", isCollapsed ? "justify-center" : "", isActive ? "bg-[var(--crm-sidebar-active)] text-[var(--crm-text-primary)] font-semibold shadow-sm ring-1 ring-[var(--crm-border)]" : "text-[var(--crm-text-primary)] hover:bg-[var(--crm-sidebar-active)] hover:text-[var(--crm-text-primary)]"),
                                    title: isCollapsed ? item.name : undefined,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(item.iconClass, "text-[16px] shrink-0", isActive ? "text-[var(--crm-text-primary)]" : "text-[var(--crm-text-secondary)] group-hover:text-[var(--crm-text-primary)]")
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/sidebar.tsx",
                                            lineNumber: 261,
                                            columnNumber: 19
                                        }, this),
                                        !isCollapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "truncate",
                                            children: item.name
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/sidebar.tsx",
                                            lineNumber: 262,
                                            columnNumber: 36
                                        }, this)
                                    ]
                                }, item.href, true, {
                                    fileName: "[project]/src/components/sidebar.tsx",
                                    lineNumber: 249,
                                    columnNumber: 17
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/components/sidebar.tsx",
                            lineNumber: 245,
                            columnNumber: 11
                        }, this),
                        visibleSections.map((section)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-4 px-2 space-y-0.5 border-t border-[var(--crm-border)] pt-2",
                                children: [
                                    !isCollapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "section-label px-1.5 pb-1 truncate",
                                        children: section.label
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/sidebar.tsx",
                                        lineNumber: 270,
                                        columnNumber: 32
                                    }, this),
                                    section.items.map((item)=>{
                                        const isActive = item.exact ? pathname === item.href : pathname === item.href || pathname.startsWith(`${item.href}/`);
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: item.href,
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("group flex items-center gap-2.5 px-2 py-1.5 rounded-md text-[13px] font-medium transition-all duration-150", isCollapsed ? "justify-center" : "", isActive ? "bg-[var(--crm-sidebar-active)] text-[var(--crm-text-primary)] font-semibold shadow-sm ring-1 ring-[var(--crm-border)]" : "text-[var(--crm-text-primary)] hover:bg-[var(--crm-sidebar-active)]"),
                                            title: isCollapsed ? item.name : undefined,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(item.iconClass, "text-[16px] shrink-0", isActive ? "text-[var(--crm-text-primary)]" : "text-[var(--crm-text-secondary)] group-hover:text-[var(--crm-text-primary)]")
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/sidebar.tsx",
                                                    lineNumber: 286,
                                                    columnNumber: 21
                                                }, this),
                                                !isCollapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "truncate",
                                                    children: item.name
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/sidebar.tsx",
                                                    lineNumber: 287,
                                                    columnNumber: 38
                                                }, this)
                                            ]
                                        }, item.href, true, {
                                            fileName: "[project]/src/components/sidebar.tsx",
                                            lineNumber: 274,
                                            columnNumber: 19
                                        }, this);
                                    })
                                ]
                            }, section.label, true, {
                                fileName: "[project]/src/components/sidebar.tsx",
                                lineNumber: 269,
                                columnNumber: 13
                            }, this))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/sidebar.tsx",
                    lineNumber: 233,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-3 border-t border-[var(--crm-border)] mt-auto",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleLogout,
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("w-full flex items-center gap-2.5 py-1.5 rounded-md text-[13px] font-medium text-[var(--crm-text-secondary)] hover:bg-[var(--crm-red-soft)] hover:text-[var(--crm-red)] transition-colors", isCollapsed ? "justify-center px-0" : "px-2"),
                            title: isCollapsed ? "Logout" : undefined,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                    className: "ti ti-logout text-[16px] text-red-500 opacity-70 shrink-0"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/sidebar.tsx",
                                    lineNumber: 304,
                                    columnNumber: 13
                                }, this),
                                !isCollapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "Logout"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/sidebar.tsx",
                                    lineNumber: 305,
                                    columnNumber: 30
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/sidebar.tsx",
                            lineNumber: 296,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("mt-2 flex items-center gap-2 py-1.5 cursor-pointer hover:bg-[var(--crm-sidebar-hover)] rounded-[var(--r-md)]", isCollapsed ? "justify-center px-0" : "px-2"),
                            onClick: ()=>router.push('/settings'),
                            title: isCollapsed ? user?.name || 'User' : undefined,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex h-6 w-6 shrink-0 items-center justify-center rounded-[var(--r-sm)] bg-[var(--crm-accent-soft)] text-[10px] font-bold text-[var(--crm-accent)]",
                                    children: user?.name?.[0]?.toUpperCase() || 'U'
                                }, void 0, false, {
                                    fileName: "[project]/src/components/sidebar.tsx",
                                    lineNumber: 315,
                                    columnNumber: 13
                                }, this),
                                !isCollapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col min-w-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-[11px] font-medium text-[var(--crm-text-primary)] truncate",
                                            children: user?.name || 'User'
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/sidebar.tsx",
                                            lineNumber: 320,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-[9px] text-[var(--crm-text-secondary)] truncate",
                                            children: user?.email || ''
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/sidebar.tsx",
                                            lineNumber: 321,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/sidebar.tsx",
                                    lineNumber: 319,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/sidebar.tsx",
                            lineNumber: 307,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/sidebar.tsx",
                    lineNumber: 295,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/sidebar.tsx",
            lineNumber: 193,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
_s(Sidebar, "55lFqwzxPgCtw4lXpK0jLDIv5MM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUser"]
    ];
});
_c = Sidebar;
var _c;
__turbopack_refresh__.register(_c, "Sidebar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/mode-toggle.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ModeToggle": (()=>ModeToggle)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next-themes/dist/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
function ModeToggle() {
    _s();
    const { theme, setTheme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: "flex items-center justify-center h-10 w-10 rounded-full text-[var(--crm-text-secondary)] hover:text-[var(--crm-text-primary)] transition-all bg-transparent hover:bg-transparent",
        onClick: ()=>setTheme(theme === "light" ? "dark" : "light"),
        "aria-label": "Toggle theme",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
            className: `ti ${theme === 'dark' ? 'ti-sun' : 'ti-moon'} text-[22px]`,
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/src/components/mode-toggle.tsx",
            lineNumber: 15,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/mode-toggle.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
_s(ModeToggle, "5ABGV54qnXKp6rHn7MS/8MjwRhQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c = ModeToggle;
var _c;
__turbopack_refresh__.register(_c, "ModeToggle");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/popover.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Popover": (()=>Popover),
    "PopoverAnchor": (()=>PopoverAnchor),
    "PopoverContent": (()=>PopoverContent),
    "PopoverTrigger": (()=>PopoverTrigger)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@radix-ui/react-popover/dist/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
;
const Popover = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root;
const PopoverTrigger = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Trigger;
const PopoverAnchor = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Anchor;
const PopoverContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, align = "center", sideOffset = 4, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Portal, {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Content, {
            ref: ref,
            align: align,
            sideOffset: sideOffset,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", className),
            ...props
        }, void 0, false, {
            fileName: "[project]/src/components/ui/popover.tsx",
            lineNumber: 19,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/popover.tsx",
        lineNumber: 18,
        columnNumber: 3
    }, this));
_c1 = PopoverContent;
PopoverContent.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$popover$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Content.displayName;
;
var _c, _c1;
__turbopack_refresh__.register(_c, "PopoverContent$React.forwardRef");
__turbopack_refresh__.register(_c1, "PopoverContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/badge.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Badge": (()=>Badge),
    "badgeVariants": (()=>badgeVariants)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const badgeVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center rounded-[var(--r-pill)] border px-2.5 py-0.5 text-[11px] font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500/50", {
    variants: {
        variant: {
            default: "border-transparent bg-primary text-white shadow-sm hover:bg-primary/90",
            secondary: "border-transparent bg-[var(--crm-surface-3)] text-[var(--crm-text-secondary)] shadow-sm",
            destructive: "border-transparent bg-[var(--crm-red-soft)] text-red-500",
            outline: "text-[var(--crm-text-primary)] border-[var(--crm-border)]"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
function Badge({ className, variant, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(badgeVariants({
            variant
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/badge.tsx",
        lineNumber: 32,
        columnNumber: 5
    }, this);
}
_c = Badge;
;
var _c;
__turbopack_refresh__.register(_c, "Badge");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/scroll-area.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ScrollArea": (()=>ScrollArea),
    "ScrollBar": (()=>ScrollBar)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@radix-ui/react-scroll-area/dist/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
;
const ScrollArea = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, children, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("relative overflow-hidden", className),
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Viewport, {
                className: "h-full w-full rounded-[inherit]",
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/ui/scroll-area.tsx",
                lineNumber: 17,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ScrollBar, {}, void 0, false, {
                fileName: "[project]/src/components/ui/scroll-area.tsx",
                lineNumber: 20,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Corner, {}, void 0, false, {
                fileName: "[project]/src/components/ui/scroll-area.tsx",
                lineNumber: 21,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/scroll-area.tsx",
        lineNumber: 12,
        columnNumber: 3
    }, this));
_c1 = ScrollArea;
ScrollArea.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root.displayName;
const ScrollBar = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(({ className, orientation = "vertical", ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.ScrollAreaScrollbar, {
        ref: ref,
        orientation: orientation,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex touch-none select-none transition-colors", orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent p-[1px]", orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent p-[1px]", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.ScrollAreaThumb, {
            className: "relative flex-1 rounded-full bg-border"
        }, void 0, false, {
            fileName: "[project]/src/components/ui/scroll-area.tsx",
            lineNumber: 43,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/scroll-area.tsx",
        lineNumber: 30,
        columnNumber: 3
    }, this));
_c2 = ScrollBar;
ScrollBar.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.ScrollAreaScrollbar.displayName;
;
var _c, _c1, _c2;
__turbopack_refresh__.register(_c, "ScrollArea$React.forwardRef");
__turbopack_refresh__.register(_c1, "ScrollArea");
__turbopack_refresh__.register(_c2, "ScrollBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/promotion-modal.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "PromotionModal": (()=>PromotionModal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$megaphone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Megaphone$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/megaphone.js [app-client] (ecmascript) <export default as Megaphone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/external-link.js [app-client] (ecmascript) <export default as ExternalLink>");
"use client";
;
;
;
;
;
;
function PromotionModal({ notification, onClose }) {
    if (!notification) return null;
    const data = notification.data || {};
    const type = data.alert_type || 'info';
    const getColors = ()=>{
        switch(type){
            case 'warning':
                return {
                    primary: 'bg-amber-600',
                    light: 'bg-amber-50',
                    text: 'text-amber-900',
                    icon: 'text-amber-600'
                };
            case 'success':
                return {
                    primary: 'bg-emerald-600',
                    light: 'bg-emerald-50',
                    text: 'text-emerald-900',
                    icon: 'text-emerald-600'
                };
            default:
                return {
                    primary: 'bg-primary',
                    light: 'bg-primary/10',
                    text: 'text-indigo-900',
                    icon: 'text-primary'
                };
        }
    };
    const colors = getColors();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
        open: true,
        onOpenChange: onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogContent"], {
            className: "sm:max-w-[550px] p-0 overflow-hidden border-none rounded-[32px] shadow-2xl bg-white dark:bg-slate-900",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTitle"], {
                    className: "sr-only",
                    children: notification.title
                }, void 0, false, {
                    fileName: "[project]/src/components/promotion-modal.tsx",
                    lineNumber: 34,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogDescription"], {
                    className: "sr-only",
                    children: notification.message
                }, void 0, false, {
                    fileName: "[project]/src/components/promotion-modal.tsx",
                    lineNumber: 35,
                    columnNumber: 9
                }, this),
                notification.image_url ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative h-[280px] w-full overflow-hidden",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: notification.image_url,
                            alt: "",
                            className: "w-full h-full object-cover"
                        }, void 0, false, {
                            fileName: "[project]/src/components/promotion-modal.tsx",
                            lineNumber: 39,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"
                        }, void 0, false, {
                            fileName: "[project]/src/components/promotion-modal.tsx",
                            lineNumber: 40,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "absolute bottom-6 left-8 right-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("px-2.5 py-1 text-white text-[10px] font-black uppercase rounded-lg w-fit mb-3 shadow-lg", colors.primary),
                                    children: "Announcement"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/promotion-modal.tsx",
                                    lineNumber: 42,
                                    columnNumber: 16
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-2xl font-black text-white leading-tight tracking-tight drop-shadow-md",
                                    children: notification.title
                                }, void 0, false, {
                                    fileName: "[project]/src/components/promotion-modal.tsx",
                                    lineNumber: 45,
                                    columnNumber: 16
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/promotion-modal.tsx",
                            lineNumber: 41,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/promotion-modal.tsx",
                    lineNumber: 38,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-8 pb-4 flex items-center gap-4", colors.light, "dark:bg-slate-800/50"),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-3 rounded-2xl bg-white dark:bg-slate-900 shadow-sm"),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$megaphone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Megaphone$3e$__["Megaphone"], {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("h-7 w-7", colors.icon)
                            }, void 0, false, {
                                fileName: "[project]/src/components/promotion-modal.tsx",
                                lineNumber: 53,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/promotion-modal.tsx",
                            lineNumber: 52,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-2xl font-black text-slate-900 dark:text-white tracking-tight",
                            children: notification.title
                        }, void 0, false, {
                            fileName: "[project]/src/components/promotion-modal.tsx",
                            lineNumber: 55,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/promotion-modal.tsx",
                    lineNumber: 51,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-8 pt-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-slate-600 dark:text-slate-400 font-medium leading-relaxed text-sm",
                                children: notification.message
                            }, void 0, false, {
                                fileName: "[project]/src/components/promotion-modal.tsx",
                                lineNumber: 63,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/promotion-modal.tsx",
                            lineNumber: 62,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-8 flex flex-col sm:flex-row gap-3",
                            children: [
                                data.cta_link && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>{
                                        window.open(data.cta_link, '_blank');
                                        onClose();
                                    },
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex-1 text-white font-black uppercase tracking-widest h-12 rounded-2xl shadow-lg transition-all active:scale-95", colors.primary),
                                    children: [
                                        data.cta_text || 'Learn More',
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__["ExternalLink"], {
                                            className: "ml-2 h-4 w-4"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/promotion-modal.tsx",
                                            lineNumber: 77,
                                            columnNumber: 49
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/promotion-modal.tsx",
                                    lineNumber: 70,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    variant: "outline",
                                    onClick: onClose,
                                    className: "flex-1 border-slate-200 dark:border-slate-800 text-slate-500 font-bold uppercase tracking-widest h-12 rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-all active:scale-95",
                                    children: "Dismiss"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/promotion-modal.tsx",
                                    lineNumber: 80,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/promotion-modal.tsx",
                            lineNumber: 68,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-6 text-[10px] text-center text-slate-400 font-bold uppercase tracking-widest opacity-50",
                            children: [
                                "Platform Announcement • ",
                                new Date(notification.created_at).toLocaleDateString()
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/promotion-modal.tsx",
                            lineNumber: 89,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/promotion-modal.tsx",
                    lineNumber: 61,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/promotion-modal.tsx",
            lineNumber: 33,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/promotion-modal.tsx",
        lineNumber: 32,
        columnNumber: 5
    }, this);
}
_c = PromotionModal;
var _c;
__turbopack_refresh__.register(_c, "PromotionModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/notification-bell.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "NotificationBell": (()=>NotificationBell)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/popover.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$scroll$2d$area$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/scroll-area.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/contexts/UserContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$promotion$2d$modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/promotion-modal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$facebook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Facebook$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/facebook.js [app-client] (ecmascript) <export default as Facebook>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UserPlus$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/user-plus.js [app-client] (ecmascript) <export default as UserPlus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$megaphone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Megaphone$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/megaphone.js [app-client] (ecmascript) <export default as Megaphone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/bell.js [app-client] (ecmascript) <export default as Bell>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2d$ring$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BellRing$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/bell-ring.js [app-client] (ecmascript) <export default as BellRing>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-client] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$formatDistanceToNow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/formatDistanceToNow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/circle-check.js [app-client] (ecmascript) <export default as CheckCircle2>");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
function NotificationBell() {
    _s();
    const { user, isLoading: isLoadingUser } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUser"])();
    const [notifications, setNotifications] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [unreadCount, setUnreadCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [lastFetchTime, setLastFetchTime] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isMounted, setIsMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const intervalRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [activePromotion, setActivePromotion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const hasShownModalThisMount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    // Check if subscription is expired or suspended
    const expiresAt = user?.company?.expires_at ? new Date(user.company.expires_at) : null;
    const isExpired = expiresAt ? expiresAt.getTime() < Date.now() : false;
    const isSuspended = user?.company?.status === 'Suspended';
    const isRestricted = isExpired || isSuspended;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NotificationBell.useEffect": ()=>{
            setIsMounted(true);
        }
    }["NotificationBell.useEffect"], []);
    const fetchNotifications = async (isInitial = false)=>{
        if (isLoadingUser || !user || isRestricted) return;
        try {
            if (isInitial) setLoading(true);
            const [notificationsResponse, unreadResponse] = await Promise.all([
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].get('/notifications'),
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].get('/notifications/unread-count')
            ]);
            const newNotifications = notificationsResponse.data.data || [];
            const newUnreadCount = unreadResponse.data.count || 0;
            if (isInitial) {
                setNotifications(newNotifications);
                setUnreadCount(newUnreadCount);
            } else {
                setNotifications((prev)=>{
                    const existingIds = new Set(prev.map((n)=>n.id));
                    const trulyNew = newNotifications.filter((n)=>!existingIds.has(n.id));
                    return trulyNew.length > 0 ? [
                        ...trulyNew,
                        ...prev
                    ] : prev;
                });
                setUnreadCount(newUnreadCount);
            }
            setLastFetchTime(new Date());
        } catch (error) {
            console.error('Error fetching notifications:', error);
        } finally{
            if (isInitial) setLoading(false);
        }
    };
    const markAsRead = async (notificationIds)=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].post('/notifications/mark-read', {
                notification_ids: notificationIds
            });
            setNotifications((prev)=>prev.map((n)=>notificationIds.includes(n.id) ? {
                        ...n,
                        is_read: true
                    } : n));
            setUnreadCount((prev)=>Math.max(0, prev - notificationIds.length));
        } catch (error) {
            console.error('Error marking notifications as read:', error);
        }
    };
    const markAllAsRead = async ()=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].post('/notifications/mark-all-read');
            setNotifications((prev)=>prev.map((n)=>({
                        ...n,
                        is_read: true
                    })));
            setUnreadCount(0);
        } catch (error) {
            console.error('Error marking all notifications as read:', error);
        }
    };
    const deleteNotification = async (notificationId)=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].delete(`/notifications/${notificationId}`);
            setNotifications((prev)=>{
                const notification = prev.find((n)=>n.id === notificationId);
                if (notification && !notification.is_read) setUnreadCount((p)=>Math.max(0, p - 1));
                return prev.filter((n)=>n.id !== notificationId);
            });
        } catch (error) {
            console.error('Error deleting notification:', error);
        }
    };
    const clearAllNotifications = async ()=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].delete('/notifications/clear-all');
            setNotifications([]);
            setUnreadCount(0);
        } catch (error) {
            console.error('Error clearing all notifications:', error);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NotificationBell.useEffect": ()=>{
            fetchNotifications(true);
            intervalRef.current = setInterval({
                "NotificationBell.useEffect": ()=>fetchNotifications(false)
            }["NotificationBell.useEffect"], 30000);
            return ({
                "NotificationBell.useEffect": ()=>{
                    if (intervalRef.current) clearInterval(intervalRef.current);
                }
            })["NotificationBell.useEffect"];
        }
    }["NotificationBell.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NotificationBell.useEffect": ()=>{
            if (loading || notifications.length === 0 || activePromotion) return;
            const modalNotifications = notifications.filter({
                "NotificationBell.useEffect.modalNotifications": (n)=>n.type === 'platform_modal' && !n.is_read
            }["NotificationBell.useEffect.modalNotifications"]);
            if (modalNotifications.length > 0) {
                const latestModal = modalNotifications[0];
                const data = latestModal.data || {};
                const frequency = data.frequency || 'once';
                const storageKey = `promo_shown_${latestModal.id}`;
                if (frequency === 'session') {
                    if (!sessionStorage.getItem(storageKey)) {
                        setActivePromotion(latestModal);
                        sessionStorage.setItem(storageKey, 'true');
                    }
                } else if (frequency === 'always') {
                    if (!hasShownModalThisMount.current) {
                        setActivePromotion(latestModal);
                        hasShownModalThisMount.current = true;
                    }
                } else {
                    // 'once'
                    setActivePromotion(latestModal);
                }
            }
        }
    }["NotificationBell.useEffect"], [
        notifications,
        loading
    ]);
    const handleClosePromotion = ()=>{
        if (activePromotion) {
            const data = activePromotion.data || {};
            const frequency = data.frequency || 'once';
            // If it's a 'once' promotion, mark as read in DB so it doesn't show again
            if (frequency === 'once') {
                markAsRead([
                    activePromotion.id
                ]);
            }
            setActivePromotion(null);
        }
    };
    const getNotificationConfig = (type)=>{
        switch(type){
            case 'meeting_booked':
            case 'old_lead_reactivation':
                return {
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"],
                    color: 'text-emerald-600',
                    bg: 'bg-emerald-50 dark:bg-emerald-900/20',
                    border: 'border-emerald-100 dark:border-emerald-800/30'
                };
            case 'facebook_lead_activity':
            case 'old_lead_facebook_reactivation':
                return {
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$facebook$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Facebook$3e$__["Facebook"],
                    color: 'text-primary',
                    bg: 'bg-blue-50 dark:bg-blue-900/20',
                    border: 'border-blue-100 dark:border-blue-800/30'
                };
            case 'new_lead_created':
                return {
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__UserPlus$3e$__["UserPlus"],
                    color: 'text-primary',
                    bg: 'bg-primary/10 dark:bg-indigo-900/20',
                    border: 'border-indigo-100 dark:border-indigo-800/30'
                };
            case 'platform_modal':
            case 'platform_broadcast':
                return {
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$megaphone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Megaphone$3e$__["Megaphone"],
                    color: 'text-primary',
                    bg: 'bg-primary/10 dark:bg-indigo-900/20',
                    border: 'border-indigo-100 dark:border-indigo-800/30'
                };
            default:
                return {
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"],
                    color: 'text-slate-600',
                    bg: 'bg-slate-50 dark:bg-slate-900/20',
                    border: 'border-slate-100 dark:border-slate-800/30'
                };
        }
    };
    if (!isMounted) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "flex items-center justify-center h-10 w-10 rounded-full text-[var(--crm-text-secondary)] transition-all bg-transparent hover:bg-transparent",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"], {
                className: "h-[22px] w-[22px]"
            }, void 0, false, {
                fileName: "[project]/src/components/notification-bell.tsx",
                lineNumber: 211,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/notification-bell.tsx",
            lineNumber: 210,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popover"], {
                open: isOpen,
                onOpenChange: setIsOpen,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopoverTrigger"], {
                        asChild: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "relative group flex items-center justify-center h-10 w-10 rounded-full text-[var(--crm-text-secondary)] transition-all bg-transparent hover:bg-transparent",
                            children: [
                                unreadCount > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2d$ring$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BellRing$3e$__["BellRing"], {
                                    className: "h-[22px] w-[22px] text-primary animate-pulse group-hover:scale-110 transition-transform"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/notification-bell.tsx",
                                    lineNumber: 222,
                                    columnNumber: 13
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"], {
                                    className: "h-[22px] w-[22px] transition-all"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/notification-bell.tsx",
                                    lineNumber: 224,
                                    columnNumber: 13
                                }, this),
                                unreadCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                    className: "absolute -top-0.5 -right-0.5 h-4 min-w-[16px] flex items-center justify-center p-0.5 text-[8px] font-black bg-primary hover:bg-primary text-white border-2 border-white dark:border-slate-900 shadow-sm",
                                    children: unreadCount > 99 ? '99+' : unreadCount
                                }, void 0, false, {
                                    fileName: "[project]/src/components/notification-bell.tsx",
                                    lineNumber: 227,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/notification-bell.tsx",
                            lineNumber: 220,
                            columnNumber: 9
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/notification-bell.tsx",
                        lineNumber: 219,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopoverContent"], {
                        className: "w-[380px] p-0 bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden",
                        align: "end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between p-4 bg-slate-50/50 dark:bg-slate-800/40 border-b border-slate-100 dark:border-slate-800",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                className: "text-sm font-black text-slate-900 dark:text-white uppercase tracking-tight",
                                                children: "Notifications"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/notification-bell.tsx",
                                                lineNumber: 239,
                                                columnNumber: 13
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-[10px] text-slate-500 font-medium",
                                                children: [
                                                    "You have ",
                                                    unreadCount,
                                                    " unread alerts"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/notification-bell.tsx",
                                                lineNumber: 240,
                                                columnNumber: 13
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/notification-bell.tsx",
                                        lineNumber: 238,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            unreadCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "ghost",
                                                size: "sm",
                                                onClick: markAllAsRead,
                                                className: "h-7 px-2 text-[10px] font-bold uppercase tracking-tight text-primary hover:text-primary hover:bg-primary/10 dark:hover:bg-indigo-900/20 rounded-lg",
                                                children: "Mark all read"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/notification-bell.tsx",
                                                lineNumber: 244,
                                                columnNumber: 15
                                            }, this),
                                            notifications.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "ghost",
                                                size: "icon",
                                                onClick: clearAllNotifications,
                                                className: "h-7 w-7 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                    className: "h-3.5 w-3.5"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/notification-bell.tsx",
                                                    lineNumber: 260,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/notification-bell.tsx",
                                                lineNumber: 254,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/notification-bell.tsx",
                                        lineNumber: 242,
                                        columnNumber: 11
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/notification-bell.tsx",
                                lineNumber: 237,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$scroll$2d$area$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollArea"], {
                                className: "h-[420px] no-scrollbar",
                                children: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col items-center justify-center h-40 text-center space-y-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-6 w-6 border-2 border-primary border-t-transparent rounded-full animate-spin"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/notification-bell.tsx",
                                            lineNumber: 270,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-slate-500 font-medium italic",
                                            children: "Scanning for updates..."
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/notification-bell.tsx",
                                            lineNumber: 271,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/notification-bell.tsx",
                                    lineNumber: 269,
                                    columnNumber: 13
                                }, this) : notifications.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col items-center justify-center h-60 text-center p-8",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-12 w-12 rounded-2xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center mb-4 text-slate-300",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__["CheckCircle2"], {
                                                className: "h-6 w-6"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/notification-bell.tsx",
                                                lineNumber: 276,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/notification-bell.tsx",
                                            lineNumber: 275,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm font-bold text-slate-900 dark:text-white",
                                            children: "All caught up!"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/notification-bell.tsx",
                                            lineNumber: 278,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-slate-500 mt-1 leading-relaxed",
                                            children: "No new notifications at the moment. We'll alert you when something happens."
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/notification-bell.tsx",
                                            lineNumber: 279,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/notification-bell.tsx",
                                    lineNumber: 274,
                                    columnNumber: 13
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "p-1.5 space-y-1",
                                    children: notifications.map((n)=>{
                                        const config = getNotificationConfig(n.type);
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("group relative p-3 rounded-xl transition-all duration-200 border border-transparent", n.is_read ? "hover:bg-slate-50 dark:hover:bg-slate-800/40 hover:border-slate-100 dark:hover:border-slate-800" : "bg-primary/5 dark:bg-indigo-900/10 border-indigo-100/50 dark:border-indigo-800/30 shadow-[0_2px_10px_-4px_rgba(99,102,241,0.1)]"),
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-start gap-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("shrink-0 h-9 w-9 rounded-xl flex items-center justify-center border transition-all duration-300", config.bg, config.border, config.color),
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(config.icon, {
                                                                className: "h-4 w-4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/notification-bell.tsx",
                                                                lineNumber: 297,
                                                                columnNumber: 25
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/notification-bell.tsx",
                                                            lineNumber: 296,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex-1 min-w-0",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center justify-between gap-2",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-xs font-bold truncate leading-none", n.is_read ? "text-slate-900 dark:text-slate-100" : "text-indigo-900 dark:text-indigo-400"),
                                                                            children: n.title
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/notification-bell.tsx",
                                                                            lineNumber: 302,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "shrink-0 text-[9px] font-medium text-slate-400",
                                                                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$formatDistanceToNow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDistanceToNow"])(new Date(n.created_at), {
                                                                                addSuffix: true
                                                                            })
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/notification-bell.tsx",
                                                                            lineNumber: 305,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/notification-bell.tsx",
                                                                    lineNumber: 301,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-[11px] text-slate-500 dark:text-slate-400 mt-1.5 leading-relaxed line-clamp-2 italic",
                                                                    children: n.message
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/notification-bell.tsx",
                                                                    lineNumber: 310,
                                                                    columnNumber: 25
                                                                }, this),
                                                                n.data?.days_since_creation !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "mt-2 flex items-center gap-1.5",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "h-1.5 w-1.5 rounded-full bg-slate-300"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/notification-bell.tsx",
                                                                            lineNumber: 317,
                                                                            columnNumber: 30
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                            className: "text-[9px] font-bold text-slate-500 uppercase tracking-tight",
                                                                            children: [
                                                                                "CREATED ",
                                                                                Math.round(n.data.days_since_creation),
                                                                                " DAYS AGO"
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/components/notification-bell.tsx",
                                                                            lineNumber: 318,
                                                                            columnNumber: 30
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/notification-bell.tsx",
                                                                    lineNumber: 316,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "mt-3 flex items-center gap-2",
                                                                    children: [
                                                                        n.lead && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                            href: `/leads?id=${n.lead.id}`,
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                                                variant: "outline",
                                                                                className: "h-7 px-2.5 text-[10px] font-bold bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 hover:text-primary transition-all rounded-lg gap-1.5",
                                                                                children: [
                                                                                    "View Lead ",
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                                                                        className: "h-3 w-3"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/components/notification-bell.tsx",
                                                                                        lineNumber: 329,
                                                                                        columnNumber: 43
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/components/notification-bell.tsx",
                                                                                lineNumber: 328,
                                                                                columnNumber: 31
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/notification-bell.tsx",
                                                                            lineNumber: 327,
                                                                            columnNumber: 29
                                                                        }, this),
                                                                        !n.is_read && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                                            variant: "ghost",
                                                                            onClick: ()=>markAsRead([
                                                                                    n.id
                                                                                ]),
                                                                            className: "h-7 px-2 text-[10px] font-bold text-primary hover:bg-primary/10 dark:hover:bg-indigo-900/20 rounded-lg gap-1.5",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                                                                    className: "h-3 w-3"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/components/notification-bell.tsx",
                                                                                    lineNumber: 339,
                                                                                    columnNumber: 31
                                                                                }, this),
                                                                                " Mark Read"
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/components/notification-bell.tsx",
                                                                            lineNumber: 334,
                                                                            columnNumber: 29
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex-1"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/notification-bell.tsx",
                                                                            lineNumber: 342,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                                            variant: "ghost",
                                                                            size: "icon",
                                                                            onClick: ()=>deleteNotification(n.id),
                                                                            className: "h-7 w-7 opacity-0 group-hover:opacity-100 transition-all text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                                                className: "h-3 w-3"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/components/notification-bell.tsx",
                                                                                lineNumber: 349,
                                                                                columnNumber: 29
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/notification-bell.tsx",
                                                                            lineNumber: 343,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/notification-bell.tsx",
                                                                    lineNumber: 325,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/notification-bell.tsx",
                                                            lineNumber: 300,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/notification-bell.tsx",
                                                    lineNumber: 295,
                                                    columnNumber: 21
                                                }, this),
                                                !n.is_read && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute top-3 right-3 h-1.5 w-1.5 bg-primary/100 rounded-full shadow-[0_0_8px_rgba(99,102,241,0.5)]"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/notification-bell.tsx",
                                                    lineNumber: 357,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, n.id, true, {
                                            fileName: "[project]/src/components/notification-bell.tsx",
                                            lineNumber: 286,
                                            columnNumber: 19
                                        }, this);
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/src/components/notification-bell.tsx",
                                    lineNumber: 282,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/notification-bell.tsx",
                                lineNumber: 267,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-3 bg-slate-50/50 dark:bg-slate-800/40 border-t border-slate-100 dark:border-slate-800",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    variant: "ghost",
                                    className: "w-full h-8 text-[11px] font-black uppercase tracking-widest text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-white dark:hover:bg-slate-700 rounded-xl",
                                    onClick: ()=>setIsOpen(false),
                                    children: "Close Notifications"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/notification-bell.tsx",
                                    lineNumber: 368,
                                    columnNumber: 12
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/notification-bell.tsx",
                                lineNumber: 367,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/notification-bell.tsx",
                        lineNumber: 235,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/notification-bell.tsx",
                lineNumber: 218,
                columnNumber: 5
            }, this),
            activePromotion && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$promotion$2d$modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PromotionModal"], {
                notification: activePromotion,
                onClose: handleClosePromotion
            }, void 0, false, {
                fileName: "[project]/src/components/notification-bell.tsx",
                lineNumber: 379,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(NotificationBell, "cTBY3yMmrWo7ZIofx/GrTCGU7E8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUser"]
    ];
});
_c = NotificationBell;
var _c;
__turbopack_refresh__.register(_c, "NotificationBell");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/contexts/WhatsAppContext.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "WhatsAppProvider": (()=>WhatsAppProvider),
    "useWhatsApp": (()=>useWhatsApp)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/contexts/UserContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature(), _s1 = __turbopack_refresh__.signature();
'use client';
;
;
;
;
;
const WhatsAppContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function WhatsAppProvider({ children }) {
    _s();
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUser"])();
    const [sessions, setSessions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [ghostSessions, setGhostSessions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [historicalSessions, setHistoricalSessions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [sessionDetails, setSessionDetails] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [selectedUser, setSelectedUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [flows, setFlows] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [isConnectModalOpen, setIsConnectModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [prefilledUserId, setPrefilledUserId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const fetchSessions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "WhatsAppProvider.useCallback[fetchSessions]": async ()=>{
            if (!user) return;
            try {
                setLoading(true);
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WHATSAPP_BASE_URL"]}/dashboard/status`, {
                    params: {
                        userId: user.id
                    }
                });
                const activeSessions = res.data.activeSessions || [];
                const ghosts = res.data.ghostSessions || [];
                const historicals = res.data.historicalSessions || [];
                const details = res.data.sessionDetails || {};
                setSessions(activeSessions);
                setGhostSessions(ghosts);
                setHistoricalSessions(historicals);
                setSessionDetails(details);
                if (activeSessions.length > 0 && !selectedUser) {
                    setSelectedUser(activeSessions[0]);
                }
            } catch (err) {
                console.warn('Failed to connect to WhatsApp Service', err);
            } finally{
                setLoading(false);
            }
        }
    }["WhatsAppProvider.useCallback[fetchSessions]"], [
        user,
        selectedUser
    ]);
    const fetchFlows = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "WhatsAppProvider.useCallback[fetchFlows]": async (userId)=>{
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WHATSAPP_BASE_URL"]}/chatbot/flows/${userId}`);
                setFlows(res.data.flows || []);
            } catch (err) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Failed to load chatbot flows');
            }
        }
    }["WhatsAppProvider.useCallback[fetchFlows]"], []);
    const shredSession = async (userId)=>{
        if (!confirm(`CAUTION: This will permanently DELETE all session credentials and history files for "${userId.split('_')[1] || userId}". Proceed?`)) return;
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].delete(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WHATSAPP_BASE_URL"]}/dashboard/session/${userId}`);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success('Session cleared successfully');
            fetchSessions();
        } catch (err) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Failed to shred session data');
        }
    };
    const toggleFlow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "WhatsAppProvider.useCallback[toggleFlow]": async (flowId, isActive)=>{
            if (!selectedUser) return;
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].patch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WHATSAPP_BASE_URL"]}/chatbot/flows/${flowId}/toggle`, {
                    user_id: selectedUser,
                    is_active: isActive
                });
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success(isActive ? 'Flow enabled' : 'Flow disabled');
                fetchFlows(selectedUser);
            } catch (err) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Failed to update flow status');
            }
        }
    }["WhatsAppProvider.useCallback[toggleFlow]"], [
        selectedUser,
        fetchFlows
    ]);
    const deleteFlow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "WhatsAppProvider.useCallback[deleteFlow]": async (flowId)=>{
            if (!selectedUser) return;
            if (!confirm('Are you sure you want to delete this flow?')) return;
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].delete(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WHATSAPP_BASE_URL"]}/chatbot/flows/${flowId}`, {
                    data: {
                        user_id: selectedUser
                    }
                });
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success('Flow deleted successfully');
                fetchFlows(selectedUser);
            } catch (err) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Failed to delete flow');
            }
        }
    }["WhatsAppProvider.useCallback[deleteFlow]"], [
        selectedUser,
        fetchFlows
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WhatsAppProvider.useEffect": ()=>{
            if (user) {
                fetchSessions();
            }
        }
    }["WhatsAppProvider.useEffect"], [
        user,
        fetchSessions
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WhatsAppProvider.useEffect": ()=>{
            if (selectedUser) {
                fetchFlows(selectedUser);
            }
        }
    }["WhatsAppProvider.useEffect"], [
        selectedUser,
        fetchFlows
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WhatsAppContext.Provider, {
        value: {
            sessions,
            ghostSessions,
            historicalSessions,
            sessionDetails,
            selectedUser,
            setSelectedUser,
            flows,
            loading,
            isConnectModalOpen,
            setIsConnectModalOpen,
            prefilledUserId,
            setPrefilledUserId,
            fetchSessions,
            fetchFlows,
            shredSession,
            toggleFlow,
            deleteFlow
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/contexts/WhatsAppContext.tsx",
        lineNumber: 150,
        columnNumber: 5
    }, this);
}
_s(WhatsAppProvider, "BSLxBfo5+lYSfxXMCuzwvmkon34=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUser"]
    ];
});
_c = WhatsAppProvider;
function useWhatsApp() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(WhatsAppContext);
    if (context === undefined) {
        throw new Error('useWhatsApp must be used within a WhatsAppProvider');
    }
    return context;
}
_s1(useWhatsApp, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_refresh__.register(_c, "WhatsAppProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/label.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Label": (()=>Label)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@radix-ui/react-label/dist/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const labelVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
const Label = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(labelVariants(), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/label.tsx",
        lineNumber: 18,
        columnNumber: 3
    }, this));
_c1 = Label;
Label.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root.displayName;
;
var _c, _c1;
__turbopack_refresh__.register(_c, "Label$React.forwardRef");
__turbopack_refresh__.register(_c1, "Label");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "WhatsAppConnectModal": (()=>WhatsAppConnectModal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/contexts/UserContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$WhatsAppContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/contexts/WhatsAppContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bot$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/bot.js [app-client] (ecmascript) <export default as Bot>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$refresh$2d$cw$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RefreshCw$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/refresh-cw.js [app-client] (ecmascript) <export default as RefreshCw>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$activity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Activity$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/activity.js [app-client] (ecmascript) <export default as Activity>");
;
var _s = __turbopack_refresh__.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
function WhatsAppConnectModal() {
    _s();
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUser"])();
    const { isConnectModalOpen, setIsConnectModalOpen, fetchSessions, prefilledUserId, setPrefilledUserId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$WhatsAppContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWhatsApp"])();
    const [newUserId, setNewUserId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [isConnecting, setIsConnecting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [qrCode, setQrCode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [connectionStatus, setConnectionStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('idle');
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect({
        "WhatsAppConnectModal.useEffect": ()=>{
            if (isConnectModalOpen) {
                setNewUserId(prefilledUserId || '');
                if (prefilledUserId) {
                    initiateConnection(prefilledUserId);
                }
            } else {
                setConnectionStatus('idle');
                setQrCode(null);
                setIsConnecting(false);
            }
        }
    }["WhatsAppConnectModal.useEffect"], [
        isConnectModalOpen,
        prefilledUserId
    ]);
    const initiateConnection = async (idToUse)=>{
        try {
            setIsConnecting(true);
            setConnectionStatus('idle');
            setQrCode(null);
            const scopedId = `${user.id}_${idToUse}`;
            await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WHATSAPP_BASE_URL"]}/messages/connect`, {
                userId: scopedId
            });
            setConnectionStatus('qr');
            startPolling(scopedId);
        } catch (err) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Failed to initiate connection');
            setIsConnecting(false);
            setConnectionStatus('idle');
        }
    };
    const handleConnectRequest = async ()=>{
        if (!newUserId) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Please enter a User ID');
            return;
        }
        await initiateConnection(newUserId);
    };
    const startPolling = (userId)=>{
        let pollCount = 0;
        const interval = setInterval(async ()=>{
            pollCount++;
            if (pollCount > 60) {
                clearInterval(interval);
                setIsConnecting(false);
                return;
            }
            try {
                const qrRes = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WHATSAPP_BASE_URL"]}/dashboard/qr/${userId}`);
                if (qrRes.data.qr) {
                    setQrCode(qrRes.data.qr);
                }
                const statusRes = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WHATSAPP_BASE_URL"]}/dashboard/status`);
                const activeSessions = statusRes.data.activeSessions || [];
                if (activeSessions.includes(userId)) {
                    setConnectionStatus('success');
                    clearInterval(interval);
                    setIsConnecting(false);
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success('WhatsApp Connected Successfully!');
                    fetchSessions();
                    setTimeout(()=>{
                        setIsConnectModalOpen(false);
                        setConnectionStatus('idle');
                        setQrCode(null);
                        setNewUserId('');
                        setPrefilledUserId('');
                    }, 2000);
                }
            } catch (err) {
                console.error('Polling error:', err);
            }
        }, 5000);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
        open: isConnectModalOpen,
        onOpenChange: setIsConnectModalOpen,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogContent"], {
            className: "sm:max-w-[425px] bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogHeader"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTitle"], {
                            className: "text-2xl font-black text-slate-900 dark:text-white",
                            children: "Connect WhatsApp"
                        }, void 0, false, {
                            fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                            lineNumber: 109,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogDescription"], {
                            className: "text-slate-500 dark:text-slate-400 font-medium",
                            children: "Enter a unique identifier for this account and scan the QR code."
                        }, void 0, false, {
                            fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                            lineNumber: 110,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                    lineNumber: 108,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid gap-6 py-4 text-center",
                    children: [
                        connectionStatus === 'idle' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid gap-3 text-left",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: "newId",
                                    className: "text-xs font-bold uppercase tracking-widest text-slate-500",
                                    children: "Account Identifier"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                    lineNumber: 118,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            id: "newId",
                                            value: newUserId,
                                            onChange: (e)=>setNewUserId(e.target.value),
                                            className: "flex-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-3 text-sm font-bold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all",
                                            placeholder: "e.g. support_desk or phone"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                            lineNumber: 120,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            onClick: handleConnectRequest,
                                            disabled: isConnecting,
                                            className: "h-12 rounded-xl bg-primary hover:bg-primary/90 text-white font-black shadow-lg shadow-primary/20 transition-all",
                                            children: isConnecting ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                                        className: "mr-2 h-4 w-4 animate-spin"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                                        lineNumber: 129,
                                                        columnNumber: 23
                                                    }, this),
                                                    " Starting Engine..."
                                                ]
                                            }, void 0, true) : 'Initialize Session'
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                            lineNumber: 127,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                    lineNumber: 119,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                            lineNumber: 117,
                            columnNumber: 13
                        }, this),
                        connectionStatus === 'qr' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col items-center justify-center p-8 bg-slate-50 dark:bg-slate-900 rounded-2xl mx-auto min-h-[280px] min-w-[280px] border border-slate-100 dark:border-slate-800 relative overflow-hidden group",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                    lineNumber: 138,
                                    columnNumber: 15
                                }, this),
                                qrCode ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col items-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "p-4 bg-white rounded-xl shadow-xl ring-1 ring-slate-200",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: qrCode,
                                                alt: "WhatsApp QR Code",
                                                className: "w-full h-full"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                                lineNumber: 142,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                            lineNumber: 141,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-4 bg-primary/10 dark:bg-indigo-900/30 px-4 py-1.5 rounded-full border border-indigo-100 dark:border-indigo-800/50 shadow-sm",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[10px] font-black text-primary dark:text-indigo-400 uppercase tracking-widest flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bot$3e$__["Bot"], {
                                                        className: "h-3 w-3"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                                        lineNumber: 146,
                                                        columnNumber: 23
                                                    }, this),
                                                    " ID: ",
                                                    newUserId
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                                lineNumber: 145,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                            lineNumber: 144,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                    lineNumber: 140,
                                    columnNumber: 17
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col items-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                                    className: "h-12 w-12 text-primary animate-spin mb-6"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                                    lineNumber: 153,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bot$3e$__["Bot"], {
                                                    className: "h-5 w-5 text-indigo-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                                    lineNumber: 154,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                            lineNumber: 152,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-slate-900 dark:text-white text-xs font-black uppercase tracking-widest animate-pulse",
                                            children: "Generating Secure QR..."
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                            lineNumber: 156,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                    lineNumber: 151,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-6 flex items-center text-slate-400 text-[10px] font-bold uppercase tracking-wider",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$refresh$2d$cw$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__RefreshCw$3e$__["RefreshCw"], {
                                            className: "h-3 w-3 mr-2 animate-spin"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                            lineNumber: 160,
                                            columnNumber: 17
                                        }, this),
                                        "Auto-refreshing every 5s"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                    lineNumber: 159,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                            lineNumber: 137,
                            columnNumber: 13
                        }, this),
                        connectionStatus === 'success' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col items-center justify-center p-8 text-emerald-500",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-20 w-20 bg-emerald-50 dark:bg-emerald-500/10 rounded-full flex items-center justify-center mb-6 border border-emerald-100 dark:border-emerald-500/20 shadow-inner",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$activity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Activity$3e$__["Activity"], {
                                        className: "h-10 w-10 animate-pulse"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                        lineNumber: 169,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                    lineNumber: 168,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-2xl font-black",
                                    children: "Authenticated!"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                    lineNumber: 171,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-slate-500 dark:text-slate-400 font-medium mt-2",
                                    children: "Redirecting to session view..."
                                }, void 0, false, {
                                    fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                                    lineNumber: 172,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                            lineNumber: 167,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
                    lineNumber: 115,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
            lineNumber: 107,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx",
        lineNumber: 106,
        columnNumber: 5
    }, this);
}
_s(WhatsAppConnectModal, "XcJbiDN878jFsR9kdvRra/81vf8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUser"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$WhatsAppContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWhatsApp"]
    ];
});
_c = WhatsAppConnectModal;
var _c;
__turbopack_refresh__.register(_c, "WhatsAppConnectModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/header.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Header": (()=>Header)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$mode$2d$toggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/mode-toggle.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$notification$2d$bell$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/notification-bell.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$WhatsAppContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/contexts/WhatsAppContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$whatsapp$2d$bot$2f$WhatsAppConnectModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/whatsapp-bot/WhatsAppConnectModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/menu.js [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
;
;
;
;
const pageMeta = {
    '/dashboard': {
        title: 'Dashboard',
        description: 'Overview of your performance'
    },
    '/leads': {
        title: 'Leads',
        description: 'Manage and track your leads'
    },
    '/live-chat': {
        title: 'Live Chat',
        description: 'Real-time conversations'
    },
    '/chatbot': {
        title: 'Chatbot',
        description: 'Automated messaging flows'
    },
    '/whatsapp-bot': {
        title: 'WhatsApp Pro Bot',
        description: 'Self-hosted automation engine v2.0'
    },
    '/meetings': {
        title: 'Meetings',
        description: 'Schedule and manage meetings'
    },
    '/meetings/event-types': {
        title: 'Meetings',
        description: 'Configure your scheduling cards'
    },
    '/integrations': {
        title: 'Integrations',
        description: 'Connect your tools'
    },
    '/analytics': {
        title: 'Analytics',
        description: 'Insights and reports'
    },
    '/settings': {
        title: 'Settings',
        description: 'Preferences and configuration'
    },
    '/team': {
        title: 'Team Management',
        description: 'Members, roles and permissions'
    },
    '/admin': {
        title: 'Super Admin Portal',
        description: 'Global platform control and user management'
    },
    '/agency': {
        title: 'Clients',
        description: 'Manage your client portfolio'
    },
    '/automations': {
        title: 'Automations',
        description: 'Build powerful workflows'
    },
    '/developer': {
        title: 'Dev Hub',
        description: 'API keys & developer tools'
    },
    '/evolution/inbox': {
        title: 'Evolution Inbox',
        description: 'Manage your centralized conversations'
    }
};
function Header({ setMobileOpen, mobileOpen }) {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const meta = pageMeta[pathname] ?? {
        title: 'Dashboard',
        description: ''
    };
    const { setIsConnectModalOpen } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$WhatsAppContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWhatsApp"])();
    const isWhatsAppPage = pathname === '/whatsapp-bot';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: " z-40 w-full shrink-0 flex h-[56px] items-center gap-3 px-5 bg-[var(--crm-sidebar-bg)] border-b border-[var(--crm-border)] ",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: "lg:hidden flex items-center justify-center h-10 w-10 rounded-full text-[var(--crm-text-secondary)] hover:text-[var(--crm-text-primary)] transition-all bg-transparent hover:bg-transparent",
                onClick: ()=>setMobileOpen(!mobileOpen),
                children: mobileOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                    className: "h-[22px] w-[22px]"
                }, void 0, false, {
                    fileName: "[project]/src/components/header.tsx",
                    lineNumber: 54,
                    columnNumber: 23
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                    className: "h-[22px] w-[22px]"
                }, void 0, false, {
                    fileName: "[project]/src/components/header.tsx",
                    lineNumber: 54,
                    columnNumber: 61
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/header.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 min-w-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-[15px] font-semibold text-[var(--crm-text-primary)] truncate leading-tight flex items-center gap-2",
                        children: [
                            meta.title,
                            isWhatsAppPage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                className: "h-4 text-[9px] bg-primary/10 dark:bg-indigo-900/30 text-primary dark:text-indigo-400 border-indigo-100 dark:border-indigo-800 font-bold px-1.5",
                                children: "v2.0"
                            }, void 0, false, {
                                fileName: "[project]/src/components/header.tsx",
                                lineNumber: 62,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/header.tsx",
                        lineNumber: 59,
                        columnNumber: 9
                    }, this),
                    meta.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "hidden sm:block text-[11px] text-[var(--crm-text-tertiary)] truncate leading-tight mt-0.5",
                        children: meta.description
                    }, void 0, false, {
                        fileName: "[project]/src/components/header.tsx",
                        lineNumber: 68,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/header.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2 shrink-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$notification$2d$bell$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NotificationBell"], {}, void 0, false, {
                        fileName: "[project]/src/components/header.tsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$mode$2d$toggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ModeToggle"], {}, void 0, false, {
                        fileName: "[project]/src/components/header.tsx",
                        lineNumber: 77,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/header.tsx",
                lineNumber: 75,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$whatsapp$2d$bot$2f$WhatsAppConnectModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WhatsAppConnectModal"], {}, void 0, false, {
                fileName: "[project]/src/components/header.tsx",
                lineNumber: 80,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/header.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_s(Header, "qHtDUJ4fWRcuCOFm0OXwwNr1mpc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$WhatsAppContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWhatsApp"]
    ];
});
_c = Header;
var _c;
__turbopack_refresh__.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/card.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Card": (()=>Card),
    "CardContent": (()=>CardContent),
    "CardDescription": (()=>CardDescription),
    "CardFooter": (()=>CardFooter),
    "CardHeader": (()=>CardHeader),
    "CardTitle": (()=>CardTitle)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Card = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded-[var(--r-lg)] border border-[var(--crm-border)] bg-[var(--crm-surface-1)] text-[var(--crm-text-primary)] overflow-hidden", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 9,
        columnNumber: 3
    }, this));
_c1 = Card;
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c2 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col space-y-1.5 p-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 24,
        columnNumber: 3
    }, this));
_c3 = CardHeader;
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c4 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-semibold leading-none tracking-tight", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 36,
        columnNumber: 3
    }, this));
_c5 = CardTitle;
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c6 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-sm text-[var(--crm-text-secondary)]", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 48,
        columnNumber: 3
    }, this));
_c7 = CardDescription;
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c8 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 60,
        columnNumber: 3
    }, this));
_c9 = CardContent;
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c10 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 68,
        columnNumber: 3
    }, this));
_c11 = CardFooter;
CardFooter.displayName = "CardFooter";
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_refresh__.register(_c, "Card$React.forwardRef");
__turbopack_refresh__.register(_c1, "Card");
__turbopack_refresh__.register(_c2, "CardHeader$React.forwardRef");
__turbopack_refresh__.register(_c3, "CardHeader");
__turbopack_refresh__.register(_c4, "CardTitle$React.forwardRef");
__turbopack_refresh__.register(_c5, "CardTitle");
__turbopack_refresh__.register(_c6, "CardDescription$React.forwardRef");
__turbopack_refresh__.register(_c7, "CardDescription");
__turbopack_refresh__.register(_c8, "CardContent$React.forwardRef");
__turbopack_refresh__.register(_c9, "CardContent");
__turbopack_refresh__.register(_c10, "CardFooter$React.forwardRef");
__turbopack_refresh__.register(_c11, "CardFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/loading.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>Loading)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Loading() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                dangerouslySetInnerHTML: {
                    __html: `
            #lb-loader { background: var(--crm-bg, #f0f2f8); }
            @media (prefers-color-scheme: dark) { #lb-loader { background: #0A0A0B; } }
            html.dark #lb-loader { background: #0A0A0B; }
            html.light #lb-loader { background: var(--crm-bg, #f0f2f8); }

            @keyframes lb-shimmer {
              0% { background-position: 200% center; }
              100% { background-position: -200% center; }
            }
            @keyframes lb-breathe {
              0%, 100% { transform: translateY(0) scale(1); }
              50% { transform: translateY(-4px) scale(1.02); }
            }
            @keyframes lb-halo {
              0%, 100% { opacity: 0.3; transform: scale(1); }
              50% { opacity: 0.55; transform: scale(1.1); }
            }
          `
                }
            }, void 0, false, {
                fileName: "[project]/src/app/loading.tsx",
                lineNumber: 5,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: "lb-loader",
                className: "fixed inset-0 z-[9999] flex flex-col items-center justify-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative flex flex-col items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative mb-5",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "absolute -inset-3 rounded-[28px] bg-[#1e2d6b]/15 dark:bg-indigo-400/15 blur-xl",
                                        style: {
                                            animation: 'lb-halo 2.6s ease-in-out infinite'
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/loading.tsx",
                                        lineNumber: 37,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: "/logo-sm.png",
                                        alt: "LeadBajaar",
                                        width: 72,
                                        height: 72,
                                        className: "relative h-[72px] w-[72px] rounded-[20px] shadow-[0_20px_45px_-14px_rgba(30,45,107,0.5)]",
                                        style: {
                                            animation: 'lb-breathe 2.6s ease-in-out infinite'
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/loading.tsx",
                                        lineNumber: 42,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/loading.tsx",
                                lineNumber: 36,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-slate-900 dark:text-white font-bold text-[22px] tracking-tight leading-none",
                                children: [
                                    "Lead",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[#1e2d6b] dark:text-indigo-300",
                                        children: "Bajaar"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/loading.tsx",
                                        lineNumber: 54,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/loading.tsx",
                                lineNumber: 53,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-2 text-[10px] text-slate-400 dark:text-slate-500 font-semibold tracking-[0.28em] uppercase",
                                children: "CRM Platform"
                            }, void 0, false, {
                                fileName: "[project]/src/app/loading.tsx",
                                lineNumber: 56,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-8 w-44 h-[3px] bg-slate-900/[0.06] dark:bg-white/[0.08] rounded-full overflow-hidden",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-full rounded-full",
                                    style: {
                                        background: 'linear-gradient(90deg, #1e2d6b, #e8503a, #1e2d6b)',
                                        backgroundSize: '200% 100%',
                                        animation: 'lb-shimmer 1.6s ease-in-out infinite'
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/loading.tsx",
                                    lineNumber: 62,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/loading.tsx",
                                lineNumber: 61,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/loading.tsx",
                        lineNumber: 33,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[560px] h-[560px] bg-[#1e2d6b]/[0.04] dark:bg-indigo-500/[0.06] rounded-full blur-[130px] pointer-events-none"
                    }, void 0, false, {
                        fileName: "[project]/src/app/loading.tsx",
                        lineNumber: 74,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/loading.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_c = Loading;
var _c;
__turbopack_refresh__.register(_c, "Loading");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/SubscriptionGuard.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "SubscriptionGuard": (()=>SubscriptionGuard)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/contexts/UserContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$loading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/loading.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$credit$2d$card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CreditCard$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/credit-card.js [app-client] (ecmascript) <export default as CreditCard>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertTriangle$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/triangle-alert.js [app-client] (ecmascript) <export default as AlertTriangle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$briefcase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Briefcase$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/briefcase.js [app-client] (ecmascript) <export default as Briefcase>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarCheck$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/calendar-check.js [app-client] (ecmascript) <export default as CalendarCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Info$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/info.js [app-client] (ecmascript) <export default as Info>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/mail.js [app-client] (ecmascript) <export default as Mail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/phone.js [app-client] (ecmascript) <export default as Phone>");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
;
;
;
;
;
;
function SubscriptionGuard({ children }) {
    _s();
    const { user, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUser"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const [isAdminBypass, setIsAdminBypass] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SubscriptionGuard.useEffect": ()=>{
            setIsAdminBypass(!!localStorage.getItem('admin_token'));
        }
    }["SubscriptionGuard.useEffect"], []);
    // Show the brand loader (same one streamed by app/loading.tsx) instead of a
    // blank screen while the user/subscription status is being fetched.
    if (isLoading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$loading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/src/components/SubscriptionGuard.tsx",
        lineNumber: 28,
        columnNumber: 25
    }, this);
    // Super Admins bypass all restrictions
    if (user?.role === 'Super Admin' || user?.user_type === 'super_admin' || isAdminBypass) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: children
        }, void 0, false);
    }
    // Allow access to settings page so user can renew/billing info
    if (pathname === '/settings') {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: children
        }, void 0, false);
    }
    // Debug: Log the company status and expiry
    // console.log('Sub Check:', user?.company?.status, user?.company?.expires_at);
    const expiresAtStr = user?.company?.expires_at;
    const expiresAt = expiresAtStr ? new Date(expiresAtStr) : null;
    // An account is expired if:
    // 1. It has an expiration date AND that date is in the past
    // 2. We can also add a check for status === 'Expired' if the backend sets it
    const isExpired = expiresAt ? expiresAt.getTime() < Date.now() : false;
    const isSuspended = user?.company?.status === 'Suspended';
    if (isExpired || isSuspended) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-6 overflow-y-auto",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 bg-slate-100/40 dark:bg-slate-950/60 backdrop-blur-xl"
                }, void 0, false, {
                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                    lineNumber: 56,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute top-1/4 left-1/4 w-48 sm:w-96 h-48 sm:h-96 bg-primary/10 rounded-full blur-[60px] sm:blur-[120px] animate-pulse"
                }, void 0, false, {
                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                    lineNumber: 57,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute bottom-1/4 right-1/4 w-48 sm:w-96 h-48 sm:h-96 bg-red-500/10 rounded-full blur-[60px] sm:blur-[120px] animate-pulse delay-700"
                }, void 0, false, {
                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                    lineNumber: 58,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                    className: "relative w-full max-w-[480px] border-none shadow-[0_32px_64px_-16px_rgba(0,0,0,0.2)] dark:shadow-[0_32px_64px_-16px_rgba(0,0,0,0.6)] rounded-[24px] sm:rounded-[32px] overflow-hidden bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl animate-in zoom-in-95 duration-500 my-auto",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                            className: "text-center pt-6 sm:pt-8 pb-3 sm:pb-4 px-4 sm:px-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("mx-auto w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center mb-3 sm:mb-4", isSuspended ? "bg-amber-50" : "bg-red-50 dark:bg-red-950/30"),
                                    children: isSuspended ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertTriangle$3e$__["AlertTriangle"], {
                                        className: "h-7 w-7 sm:h-8 sm:h-8 text-amber-500"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                        lineNumber: 67,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$credit$2d$card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CreditCard$3e$__["CreditCard"], {
                                                className: "h-7 w-7 sm:h-8 sm:h-8 text-red-500"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                lineNumber: 70,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "absolute -top-1 -right-1 w-3 sm:w-3.5 h-3 sm:h-3.5 bg-white dark:bg-slate-900 rounded-full flex items-center justify-center",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                    className: "h-2 sm:h-2.5 w-2 sm:w-2.5 text-red-600"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                    lineNumber: 72,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                lineNumber: 71,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                        lineNumber: 69,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                    lineNumber: 62,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                    className: "text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white mb-1",
                                    children: isSuspended ? 'Access Suspended' : 'Stay Ahead, Renew Now'
                                }, void 0, false, {
                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                    lineNumber: 78,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                    className: "text-slate-500 dark:text-slate-400 font-medium text-xs sm:text-sm px-1 sm:px-2 leading-relaxed",
                                    children: isSuspended ? 'Your account has been restricted. Please contact our team to resolve this.' : 'Premium features are on pause. Renew now to resume your growth.'
                                }, void 0, false, {
                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                    lineNumber: 82,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                            lineNumber: 61,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                            className: "px-5 sm:px-8 space-y-3 sm:space-y-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-slate-100/50 dark:bg-slate-800/40 rounded-[16px] sm:rounded-[20px] p-3.5 sm:p-4 border border-slate-200/50 dark:border-slate-700/50 space-y-2.5 sm:space-y-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center justify-between",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2 sm:gap-2.5",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "h-6 w-6 sm:h-7 sm:w-7 rounded-lg bg-white dark:bg-slate-700 flex items-center justify-center shadow-sm",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$briefcase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Briefcase$3e$__["Briefcase"], {
                                                                className: "h-3 w-3 sm:h-3.5 sm:w-3.5 text-slate-400"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                                lineNumber: 95,
                                                                columnNumber: 21
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                            lineNumber: 94,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-slate-500 font-bold uppercase tracking-widest text-[8px] sm:text-[9px]",
                                                            children: "Status"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                            lineNumber: 97,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                    lineNumber: 93,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                    variant: "outline",
                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-black text-[8px] sm:text-[9px] uppercase px-1.5 sm:px-2 h-4.5 sm:h-5 border-0 shadow-sm", isSuspended ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"),
                                                    children: isSuspended ? 'Suspended' : 'Expired'
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                    lineNumber: 99,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                            lineNumber: 92,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center justify-between",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2 sm:gap-2.5",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "h-6 w-6 sm:h-7 sm:w-7 rounded-lg bg-white dark:bg-slate-700 flex items-center justify-center shadow-sm",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$credit$2d$card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CreditCard$3e$__["CreditCard"], {
                                                                className: "h-3 w-3 sm:h-3.5 sm:w-3.5 text-slate-400"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                                lineNumber: 110,
                                                                columnNumber: 21
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                            lineNumber: 109,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-slate-500 font-bold uppercase tracking-widest text-[8px] sm:text-[9px]",
                                                            children: "Plan"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                            lineNumber: 112,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                    lineNumber: 108,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-slate-900 dark:text-white font-black text-[11px] sm:text-xs capitalize",
                                                    children: [
                                                        user?.company?.plan || 'Free',
                                                        " Plan"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                    lineNumber: 114,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                            lineNumber: 107,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center justify-between",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2 sm:gap-2.5",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "h-6 w-6 sm:h-7 sm:w-7 rounded-lg bg-white dark:bg-slate-700 flex items-center justify-center shadow-sm",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarCheck$3e$__["CalendarCheck"], {
                                                                className: "h-3 w-3 sm:h-3.5 sm:w-3.5 text-slate-400"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                                lineNumber: 120,
                                                                columnNumber: 21
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                            lineNumber: 119,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-slate-500 font-bold uppercase tracking-widest text-[8px] sm:text-[9px]",
                                                            children: "Expiry"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                            lineNumber: 122,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                    lineNumber: 118,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-black text-[11px] sm:text-xs", isExpired ? "text-red-500" : "text-slate-900 dark:text-white"),
                                                    children: expiresAt ? expiresAt.toLocaleDateString('en-GB') : 'N/A'
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                    lineNumber: 124,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                            lineNumber: 117,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                    lineNumber: 91,
                                    columnNumber: 13
                                }, this),
                                !isSuspended && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-start gap-3 p-3 rounded-xl bg-primary/5 dark:bg-primary/5 border border-indigo-100 dark:border-primary/10",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-0.5 text-primary shrink-0",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Info$3e$__["Info"], {
                                                className: "h-4 w-4 sm:h-5 sm:w-5"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                lineNumber: 137,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                            lineNumber: 136,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-[10px] sm:text-xs text-primary dark:text-indigo-400 font-medium leading-relaxed",
                                            children: "Your data is safe, but active lead sync and automations are currently paused."
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                            lineNumber: 139,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                    lineNumber: 135,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                            lineNumber: 89,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardFooter"], {
                            className: "flex flex-col gap-2.5 sm:gap-3 p-5 sm:p-8 pt-2 sm:pt-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>window.location.href = '/settings?tab=billing',
                                    className: "w-full bg-primary hover:bg-primary/90 text-white font-black rounded-xl sm:rounded-2xl h-11 sm:h-12 text-xs sm:text-sm shadow-xl shadow-primary/30 transition-all hover:scale-[1.02] active:scale-[0.98] group",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$credit$2d$card$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CreditCard$3e$__["CreditCard"], {
                                            className: "h-3.5 w-3.5 sm:h-4 sm:w-4 mr-2.5 sm:mr-3 transition-transform group-hover:rotate-12"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                            lineNumber: 151,
                                            columnNumber: 15
                                        }, this),
                                        "Renew Subscription"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                    lineNumber: 147,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2 w-full pt-0.5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            variant: "ghost",
                                            className: "flex-1 h-9 sm:h-10 text-slate-500 dark:text-slate-400 font-black rounded-lg sm:rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-[8px] sm:text-[10px] uppercase tracking-widest px-1",
                                            onClick: ()=>window.location.href = 'mailto:support@leadbajaar.com',
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                                    className: "h-3.5 w-3.5 mr-1.5 sm:mr-2"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                    lineNumber: 161,
                                                    columnNumber: 17
                                                }, this),
                                                " Support"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                            lineNumber: 156,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-4 w-px bg-slate-200 dark:bg-slate-800 shrink-0"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                            lineNumber: 163,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            variant: "ghost",
                                            className: "flex-1 h-9 sm:h-10 text-slate-500 dark:text-slate-400 font-black rounded-lg sm:rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-[8px] sm:text-[10px] uppercase tracking-widest px-1",
                                            onClick: ()=>window.location.href = 'https://wa.me/916376148776',
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                                    className: "h-3.5 w-3.5 mr-1.5 sm:mr-2"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                                    lineNumber: 169,
                                                    columnNumber: 17
                                                }, this),
                                                " WhatsApp"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                            lineNumber: 164,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                    lineNumber: 155,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-center text-[9px] sm:text-[10px] text-slate-400 font-medium mt-3 sm:mt-4 tracking-tighter",
                                    children: [
                                        "© ",
                                        new Date().getFullYear(),
                                        " LeadBajaar. All rights reserved."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                                    lineNumber: 173,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/SubscriptionGuard.tsx",
                            lineNumber: 146,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/SubscriptionGuard.tsx",
                    lineNumber: 60,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/SubscriptionGuard.tsx",
            lineNumber: 54,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: children
    }, void 0, false);
}
_s(SubscriptionGuard, "FcwvSEqVZmVQAh2/9ULe6eqzBAI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUser"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = SubscriptionGuard;
var _c;
__turbopack_refresh__.register(_c, "SubscriptionGuard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/(dashboard)/layout.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>DashboardLayout)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$sidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/sidebar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/header.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/contexts/UserContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SubscriptionGuard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/SubscriptionGuard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$WhatsAppContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/contexts/WhatsAppContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
;
;
;
;
function DashboardLayout({ children }) {
    _s();
    const [mobileOpen, setMobileOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isCollapsed, setIsCollapsed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$UserContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UserProvider"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$WhatsAppContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WhatsAppProvider"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SubscriptionGuard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SubscriptionGuard"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex h-screen overflow-hidden bg-[var(--crm-bg)] text-[var(--crm-text-primary)]",
                    children: [
                        mobileOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "fixed inset-0 z-[90] bg-[#00000080] lg:hidden transition-opacity",
                            onClick: ()=>setMobileOpen(false)
                        }, void 0, false, {
                            fileName: "[project]/src/app/(dashboard)/layout.tsx",
                            lineNumber: 26,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$sidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sidebar"], {
                            mobileOpen: mobileOpen,
                            setMobileOpen: setMobileOpen,
                            isCollapsed: isCollapsed,
                            setIsCollapsed: setIsCollapsed
                        }, void 0, false, {
                            fileName: "[project]/src/app/(dashboard)/layout.tsx",
                            lineNumber: 32,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1 flex flex-col min-w-0 overflow-hidden relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Header"], {
                                    mobileOpen: mobileOpen,
                                    setMobileOpen: setMobileOpen
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(dashboard)/layout.tsx",
                                    lineNumber: 35,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                                    className: "flex-1 flex flex-col overflow-y-auto relative lg:p-4 custom-scrollbar",
                                    children: pathname === '/dashboard' || pathname.includes('/live-chat') || pathname.includes('/evolution/inbox') || pathname.includes('/builder') ? children : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col flex-1 min-h-0 bg-[var(--crm-surface-1)] lg:rounded-[var(--r-sm)] lg:border border-[var(--crm-border)] lg:shadow-sm",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-col flex-1 overflow-y-auto p-2 sm:p-3 lg:p-4 custom-scrollbar",
                                            children: children
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/(dashboard)/layout.tsx",
                                            lineNumber: 41,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/(dashboard)/layout.tsx",
                                        lineNumber: 40,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(dashboard)/layout.tsx",
                                    lineNumber: 36,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/(dashboard)/layout.tsx",
                            lineNumber: 34,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/(dashboard)/layout.tsx",
                    lineNumber: 23,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/(dashboard)/layout.tsx",
                lineNumber: 22,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/(dashboard)/layout.tsx",
            lineNumber: 21,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/(dashboard)/layout.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
_s(DashboardLayout, "vUUuXR/uLQYa6nzKkevAmaD6CoM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = DashboardLayout;
var _c;
__turbopack_refresh__.register(_c, "DashboardLayout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/(dashboard)/layout.tsx [app-rsc] (ecmascript, Next.js server component, client modules)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),
}]);

//# sourceMappingURL=src_7d37e0._.js.map