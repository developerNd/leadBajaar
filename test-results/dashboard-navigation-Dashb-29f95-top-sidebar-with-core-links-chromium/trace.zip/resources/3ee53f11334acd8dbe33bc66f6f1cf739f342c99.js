(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(dashboard)_dashboard_page_tsx_d5cfd0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(dashboard)_dashboard_page_tsx_d5cfd0._.js",
  "chunks": [
    "static/chunks/src_f53f92._.js",
    "static/chunks/node_modules_lucide-react_dist_esm_icons_index_208f44.js",
    "static/chunks/node_modules_lucide-react_dist_esm_icons_index_d4b743.js",
    "static/chunks/node_modules_lucide-react_dist_esm_icons_7cfcda._.js",
    "static/chunks/node_modules_lucide-react_dist_esm_lucide-react_a644e2.js",
    "static/chunks/node_modules_lucide-react_dist_esm_lucide-react_e8a320.js",
    "static/chunks/node_modules_lucide-react_dist_esm_lucide-react_f0b2f7.js",
    "static/chunks/node_modules_f7b607._.js"
  ],
  "source": "dynamic"
});
