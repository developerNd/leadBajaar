(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(dashboard)_layout_tsx_f10ca9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(dashboard)_layout_tsx_f10ca9._.js",
  "chunks": [
    "static/chunks/src_7d37e0._.js",
    "static/chunks/node_modules_next_dist_compiled_stream-http_index_4b0f5e.js",
    "static/chunks/node_modules_next_dist_compiled_crypto-browserify_index_07270e.js",
    "static/chunks/node_modules_next_dist_compiled_assert_assert_eb3021.js",
    "static/chunks/node_modules_next_dist_compiled_dc6e2f._.js",
    "static/chunks/node_modules_next_dist_0c4c53._.js",
    "static/chunks/node_modules_next_41e6da._.js",
    "static/chunks/node_modules_next-auth_a6b8e2._.js",
    "static/chunks/node_modules_openid-client_f122e9._.js",
    "static/chunks/node_modules_jose_dist_browser_a0f535._.js",
    "static/chunks/node_modules_axios_lib_c4c49c._.js",
    "static/chunks/node_modules_789454._.js"
  ],
  "source": "dynamic"
});
