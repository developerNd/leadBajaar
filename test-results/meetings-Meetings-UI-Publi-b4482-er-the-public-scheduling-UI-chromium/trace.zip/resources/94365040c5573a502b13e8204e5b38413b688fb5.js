(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_44431c._.js", {

"[project]/src/components/ui/card.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Card": (()=>Card),
    "CardContent": (()=>CardContent),
    "CardDescription": (()=>CardDescription),
    "CardFooter": (()=>CardFooter),
    "CardHeader": (()=>CardHeader),
    "CardTitle": (()=>CardTitle)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Card = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded-[var(--r-lg)] border border-[var(--crm-border)] bg-[var(--crm-surface-1)] text-[var(--crm-text-primary)] overflow-hidden", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 9,
        columnNumber: 3
    }, this));
_c1 = Card;
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c2 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col space-y-1.5 p-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 24,
        columnNumber: 3
    }, this));
_c3 = CardHeader;
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c4 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-semibold leading-none tracking-tight", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 36,
        columnNumber: 3
    }, this));
_c5 = CardTitle;
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c6 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-sm text-[var(--crm-text-secondary)]", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 48,
        columnNumber: 3
    }, this));
_c7 = CardDescription;
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c8 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 60,
        columnNumber: 3
    }, this));
_c9 = CardContent;
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c10 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 68,
        columnNumber: 3
    }, this));
_c11 = CardFooter;
CardFooter.displayName = "CardFooter";
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_refresh__.register(_c, "Card$React.forwardRef");
__turbopack_refresh__.register(_c1, "Card");
__turbopack_refresh__.register(_c2, "CardHeader$React.forwardRef");
__turbopack_refresh__.register(_c3, "CardHeader");
__turbopack_refresh__.register(_c4, "CardTitle$React.forwardRef");
__turbopack_refresh__.register(_c5, "CardTitle");
__turbopack_refresh__.register(_c6, "CardDescription$React.forwardRef");
__turbopack_refresh__.register(_c7, "CardDescription");
__turbopack_refresh__.register(_c8, "CardContent$React.forwardRef");
__turbopack_refresh__.register(_c9, "CardContent");
__turbopack_refresh__.register(_c10, "CardFooter$React.forwardRef");
__turbopack_refresh__.register(_c11, "CardFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/custom-calendar.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "CustomCalendar": (()=>CustomCalendar)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
function CustomCalendar({ selectedDate, onDateSelect, availableDates = [], disabledDates = [], minDate, maxDate, className, isDateAvailable }) {
    _s();
    const [currentMonth, setCurrentMonth] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.useState({
        "CustomCalendar.useState": ()=>{
            return selectedDate ? new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1) : new Date();
        }
    }["CustomCalendar.useState"]);
    const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0).getDate();
    const firstDayOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1).getDay();
    const weekDays = [
        'Sun',
        'Mon',
        'Tue',
        'Wed',
        'Thu',
        'Fri',
        'Sat'
    ];
    const months = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'
    ];
    const checkDateAvailable = (date)=>{
        // Use custom function if provided
        if (isDateAvailable) {
            return isDateAvailable(date);
        }
        // Fallback to availableDates array
        if (availableDates.length === 0) return true;
        return availableDates.some((availableDate)=>availableDate.getDate() === date.getDate() && availableDate.getMonth() === date.getMonth() && availableDate.getFullYear() === date.getFullYear());
    };
    const isDateDisabled = (date)=>{
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        // Check if date is in the past
        if (date < today) return true;
        // Check if date is in disabled dates
        if (disabledDates.some((disabledDate)=>disabledDate.getDate() === date.getDate() && disabledDate.getMonth() === date.getMonth() && disabledDate.getFullYear() === date.getFullYear())) return true;
        // Check min/max date constraints
        if (minDate && date < minDate) return true;
        if (maxDate && date > maxDate) return true;
        return false;
    };
    const isDateSelected = (date)=>{
        if (!selectedDate) return false;
        return date.getDate() === selectedDate.getDate() && date.getMonth() === selectedDate.getMonth() && date.getFullYear() === selectedDate.getFullYear();
    };
    const isToday = (date)=>{
        const today = new Date();
        return date.getDate() === today.getDate() && date.getMonth() === today.getMonth() && date.getFullYear() === today.getFullYear();
    };
    const handleDateClick = (date)=>{
        if (!isDateDisabled(date) && onDateSelect) {
            onDateSelect(date);
        }
    };
    const goToPreviousMonth = ()=>{
        setCurrentMonth((prev)=>new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
    };
    const goToNextMonth = ()=>{
        setCurrentMonth((prev)=>new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
    };
    const generateCalendarDays = ()=>{
        const days = [];
        // Add empty cells for days before the first day of the month
        for(let i = 0; i < firstDayOfMonth; i++){
            days.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "aspect-square w-full max-w-[45px] sm:w-10 sm:h-10 mx-auto"
            }, `empty-${i}`, false, {
                fileName: "[project]/src/components/ui/custom-calendar.tsx",
                lineNumber: 111,
                columnNumber: 17
            }, this));
        }
        // Add days of the month
        for(let day = 1; day <= daysInMonth; day++){
            const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
            const isAvailable = checkDateAvailable(date);
            const isDisabled = isDateDisabled(date);
            const isSelected = isDateSelected(date);
            const isTodayDate = isToday(date);
            days.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("aspect-square w-full max-w-[45px] sm:w-10 sm:h-10 flex items-center justify-center text-[14px] sm:text-[13px] rounded-full transition-all duration-200", "mx-auto", isSelected && "bg-[var(--lb-navy)] text-white font-medium shadow-sm", isTodayDate && !isSelected && "border-[0.5px] border-[var(--lb-navy)] text-[var(--lb-navy)] font-medium", isAvailable && !isDisabled && !isSelected && !isTodayDate && "text-[var(--lb-navy)] font-medium bg-[var(--lb-navy-soft)] border-[0.5px] border-[var(--lb-navy-border)] hover:bg-[var(--lb-navy)] hover:text-white cursor-pointer shadow-sm", isDisabled && "text-[var(--lb-t3)] cursor-default", !isAvailable && !isDisabled && !isSelected && !isTodayDate && "text-[var(--lb-t3)] cursor-default"),
                onClick: ()=>handleDateClick(date),
                role: "button",
                tabIndex: 0,
                onKeyDown: (e)=>{
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        handleDateClick(date);
                    }
                },
                children: day
            }, day, false, {
                fileName: "[project]/src/components/ui/custom-calendar.tsx",
                lineNumber: 123,
                columnNumber: 9
            }, this));
        }
        return days;
    };
    return(// Constrained width keeps the 7-column grid compact and evenly spaced —
    // full-width columns leave the 34-40px day circles scattered far apart.
    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-0 mx-auto w-full sm:max-w-[360px]", className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: goToPreviousMonth,
                        className: "w-9 h-9 sm:w-7 sm:h-7 rounded-full border-[0.5px] border-[var(--lb-border)] bg-[var(--lb-bg)] flex items-center justify-center cursor-pointer text-[var(--lb-t2)] hover:bg-[var(--lb-s3)] transition-colors",
                        "aria-label": "Previous month",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                            className: "h-4 w-4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/custom-calendar.tsx",
                            lineNumber: 163,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/custom-calendar.tsx",
                        lineNumber: 158,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-[15px] sm:text-[14px] font-medium text-[var(--lb-t1)]",
                        children: [
                            months[currentMonth.getMonth()],
                            " ",
                            currentMonth.getFullYear()
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/custom-calendar.tsx",
                        lineNumber: 166,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: goToNextMonth,
                        className: "w-9 h-9 sm:w-7 sm:h-7 rounded-full border-[0.5px] border-[var(--lb-border)] bg-[var(--lb-bg)] flex items-center justify-center cursor-pointer text-[var(--lb-t2)] hover:bg-[var(--lb-s3)] transition-colors",
                        "aria-label": "Next month",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                            className: "h-4 w-4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ui/custom-calendar.tsx",
                            lineNumber: 175,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/custom-calendar.tsx",
                        lineNumber: 170,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/custom-calendar.tsx",
                lineNumber: 157,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-7 gap-x-1 mb-1",
                children: weekDays.map((day)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-[10px] font-semibold uppercase tracking-[0.06em] text-[var(--lb-t3)] text-center py-1.5",
                        children: day.substring(0, 3)
                    }, day, false, {
                        fileName: "[project]/src/components/ui/custom-calendar.tsx",
                        lineNumber: 182,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/ui/custom-calendar.tsx",
                lineNumber: 180,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-7 gap-x-1 gap-y-2 sm:gap-y-1.5",
                children: generateCalendarDays()
            }, void 0, false, {
                fileName: "[project]/src/components/ui/custom-calendar.tsx",
                lineNumber: 192,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-center gap-4 pt-3 mt-2 border-t-[0.5px] border-[var(--lb-border)] text-[11px] text-[var(--lb-t2)]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-1.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-2 w-2 rounded-full bg-[var(--lb-navy-soft)] border-[0.5px] border-[var(--lb-navy-border)]"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/custom-calendar.tsx",
                                lineNumber: 199,
                                columnNumber: 11
                            }, this),
                            "Available"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/custom-calendar.tsx",
                        lineNumber: 198,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-1.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-2 w-2 rounded-full bg-[var(--lb-navy)]"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/custom-calendar.tsx",
                                lineNumber: 203,
                                columnNumber: 11
                            }, this),
                            "Selected"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/custom-calendar.tsx",
                        lineNumber: 202,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-1.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-2 w-2 rounded-full border-[0.5px] border-[var(--lb-navy)] bg-transparent"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/custom-calendar.tsx",
                                lineNumber: 207,
                                columnNumber: 11
                            }, this),
                            "Today"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/custom-calendar.tsx",
                        lineNumber: 206,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/custom-calendar.tsx",
                lineNumber: 197,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/custom-calendar.tsx",
        lineNumber: 155,
        columnNumber: 5
    }, this));
}
_s(CustomCalendar, "1ak+eIZlOGx/C/5KB6C71v16Jjk=");
_c = CustomCalendar;
var _c;
__turbopack_refresh__.register(_c, "CustomCalendar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/avatar.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Avatar": (()=>Avatar),
    "AvatarFallback": (()=>AvatarFallback),
    "AvatarImage": (()=>AvatarImage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@radix-ui/react-avatar/dist/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
;
const Avatar = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/avatar.tsx",
        lineNumber: 12,
        columnNumber: 3
    }, this));
_c1 = Avatar;
Avatar.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root.displayName;
const AvatarImage = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c2 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Image, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("aspect-square h-full w-full", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/avatar.tsx",
        lineNumber: 27,
        columnNumber: 3
    }, this));
_c3 = AvatarImage;
AvatarImage.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Image.displayName;
const AvatarFallback = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c4 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Fallback, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex h-full w-full items-center justify-center rounded-full bg-muted", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/avatar.tsx",
        lineNumber: 39,
        columnNumber: 3
    }, this));
_c5 = AvatarFallback;
AvatarFallback.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$avatar$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Fallback.displayName;
;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_refresh__.register(_c, "Avatar$React.forwardRef");
__turbopack_refresh__.register(_c1, "Avatar");
__turbopack_refresh__.register(_c2, "AvatarImage$React.forwardRef");
__turbopack_refresh__.register(_c3, "AvatarImage");
__turbopack_refresh__.register(_c4, "AvatarFallback$React.forwardRef");
__turbopack_refresh__.register(_c5, "AvatarFallback");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/input.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Input": (()=>Input)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Input = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, type, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        type: type,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex h-10 w-full rounded-[var(--r-md)] border border-[var(--crm-border)] bg-[var(--crm-surface-2)] px-3 py-2 text-[13px] text-[var(--crm-text-primary)] shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-[var(--crm-text-primary)] placeholder:text-[var(--crm-text-tertiary)] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-indigo-500/50 focus-visible:border-primary/50 disabled:cursor-not-allowed disabled:opacity-50", className),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/input.tsx",
        lineNumber: 8,
        columnNumber: 7
    }, this);
});
_c1 = Input;
Input.displayName = "Input";
;
var _c, _c1;
__turbopack_refresh__.register(_c, "Input$React.forwardRef");
__turbopack_refresh__.register(_c1, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/label.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Label": (()=>Label)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@radix-ui/react-label/dist/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const labelVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
const Label = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(labelVariants(), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/label.tsx",
        lineNumber: 18,
        columnNumber: 3
    }, this));
_c1 = Label;
Label.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root.displayName;
;
var _c, _c1;
__turbopack_refresh__.register(_c, "Label$React.forwardRef");
__turbopack_refresh__.register(_c1, "Label");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/textarea.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Textarea": (()=>Textarea)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Textarea = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/textarea.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
});
_c1 = Textarea;
Textarea.displayName = "Textarea";
;
var _c, _c1;
__turbopack_refresh__.register(_c, "Textarea$React.forwardRef");
__turbopack_refresh__.register(_c1, "Textarea");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/radio-group.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "RadioGroup": (()=>RadioGroup),
    "RadioGroupItem": (()=>RadioGroupItem)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$radio$2d$group$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@radix-ui/react-radio-group/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Circle$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/circle.js [app-client] (ecmascript) <export default as Circle>");
"use client";
;
;
;
;
;
const RadioGroup = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$radio$2d$group$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("grid gap-2", className),
        ...props,
        ref: ref
    }, void 0, false, {
        fileName: "[project]/src/components/ui/radio-group.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
});
_c1 = RadioGroup;
RadioGroup.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$radio$2d$group$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root.displayName;
const RadioGroupItem = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c2 = ({ className, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$radio$2d$group$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Item, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("aspect-square h-4 w-4 rounded-full border border-primary text-primary shadow focus:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$radio$2d$group$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Indicator, {
            className: "flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Circle$3e$__["Circle"], {
                className: "h-3.5 w-3.5 fill-primary"
            }, void 0, false, {
                fileName: "[project]/src/components/ui/radio-group.tsx",
                lineNumber: 37,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ui/radio-group.tsx",
            lineNumber: 36,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/radio-group.tsx",
        lineNumber: 28,
        columnNumber: 5
    }, this);
});
_c3 = RadioGroupItem;
RadioGroupItem.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$radio$2d$group$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Item.displayName;
;
var _c, _c1, _c2, _c3;
__turbopack_refresh__.register(_c, "RadioGroup$React.forwardRef");
__turbopack_refresh__.register(_c1, "RadioGroup");
__turbopack_refresh__.register(_c2, "RadioGroupItem$React.forwardRef");
__turbopack_refresh__.register(_c3, "RadioGroupItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/checkbox.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Checkbox": (()=>Checkbox)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@radix-ui/react-checkbox/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
"use client";
;
;
;
;
;
const Checkbox = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Indicator, {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center justify-center text-current"),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                className: "h-4 w-4"
            }, void 0, false, {
                fileName: "[project]/src/components/ui/checkbox.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ui/checkbox.tsx",
            lineNumber: 21,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/checkbox.tsx",
        lineNumber: 13,
        columnNumber: 3
    }, this));
_c1 = Checkbox;
Checkbox.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root.displayName;
;
var _c, _c1;
__turbopack_refresh__.register(_c, "Checkbox$React.forwardRef");
__turbopack_refresh__.register(_c1, "Checkbox");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/select.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Select": (()=>Select),
    "SelectContent": (()=>SelectContent),
    "SelectGroup": (()=>SelectGroup),
    "SelectItem": (()=>SelectItem),
    "SelectLabel": (()=>SelectLabel),
    "SelectScrollDownButton": (()=>SelectScrollDownButton),
    "SelectScrollUpButton": (()=>SelectScrollUpButton),
    "SelectSeparator": (()=>SelectSeparator),
    "SelectTrigger": (()=>SelectTrigger),
    "SelectValue": (()=>SelectValue)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@radix-ui/react-select/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-client] (ecmascript) <export default as ChevronUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
"use client";
;
;
;
;
;
const Select = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root;
const SelectGroup = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Group;
const SelectValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Value;
const SelectTrigger = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, children, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Trigger, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Icon, {
                asChild: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                    className: "h-4 w-4 opacity-50"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 29,
                    columnNumber: 7
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ui/select.tsx",
                lineNumber: 28,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 19,
        columnNumber: 3
    }, this));
_c1 = SelectTrigger;
SelectTrigger.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Trigger.displayName;
const SelectScrollUpButton = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.ScrollUpButton, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
            className: "h-4 w-4"
        }, void 0, false, {
            fileName: "[project]/src/components/ui/select.tsx",
            lineNumber: 47,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 39,
        columnNumber: 3
    }, this));
_c2 = SelectScrollUpButton;
SelectScrollUpButton.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.ScrollUpButton.displayName;
const SelectScrollDownButton = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.ScrollDownButton, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
            className: "h-4 w-4"
        }, void 0, false, {
            fileName: "[project]/src/components/ui/select.tsx",
            lineNumber: 64,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 56,
        columnNumber: 3
    }, this));
_c3 = SelectScrollDownButton;
SelectScrollDownButton.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.ScrollDownButton.displayName;
const SelectContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c4 = ({ className, children, position = "popper", ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Portal, {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Content, {
            ref: ref,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("relative z-[200] max-h-96 min-w-[8rem] overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
            position: position,
            ...props,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SelectScrollUpButton, {}, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 86,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Viewport, {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
                    children: children
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 87,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SelectScrollDownButton, {}, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 96,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ui/select.tsx",
            lineNumber: 75,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 74,
        columnNumber: 3
    }, this));
_c5 = SelectContent;
SelectContent.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Content.displayName;
const SelectLabel = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c6 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Label, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("px-2 py-1.5 text-sm font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 106,
        columnNumber: 3
    }, this));
_c7 = SelectLabel;
SelectLabel.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Label.displayName;
const SelectItem = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c8 = ({ className, children, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Item, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-2 pr-8 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "absolute right-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.ItemIndicator, {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                        className: "h-4 w-4"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/select.tsx",
                        lineNumber: 128,
                        columnNumber: 9
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 127,
                    columnNumber: 7
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ui/select.tsx",
                lineNumber: 126,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.ItemText, {
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/ui/select.tsx",
                lineNumber: 131,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 118,
        columnNumber: 3
    }, this));
_c9 = SelectItem;
SelectItem.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Item.displayName;
const SelectSeparator = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c10 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Separator, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("-mx-1 my-1 h-px bg-muted", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 140,
        columnNumber: 3
    }, this));
_c11 = SelectSeparator;
SelectSeparator.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Separator.displayName;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_refresh__.register(_c, "SelectTrigger$React.forwardRef");
__turbopack_refresh__.register(_c1, "SelectTrigger");
__turbopack_refresh__.register(_c2, "SelectScrollUpButton");
__turbopack_refresh__.register(_c3, "SelectScrollDownButton");
__turbopack_refresh__.register(_c4, "SelectContent$React.forwardRef");
__turbopack_refresh__.register(_c5, "SelectContent");
__turbopack_refresh__.register(_c6, "SelectLabel$React.forwardRef");
__turbopack_refresh__.register(_c7, "SelectLabel");
__turbopack_refresh__.register(_c8, "SelectItem$React.forwardRef");
__turbopack_refresh__.register(_c9, "SelectItem");
__turbopack_refresh__.register(_c10, "SelectSeparator$React.forwardRef");
__turbopack_refresh__.register(_c11, "SelectSeparator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/lib/validations/questions.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "validateQuestionResponse": (()=>validateQuestionResponse)
});
const validateQuestionResponse = (type, value, label)=>{
    // If type is text but label suggests it's a phone, treat as phone
    let effectiveType = type;
    if (type === 'text' && label) {
        const lowerLabel = label.toLowerCase();
        if (lowerLabel.includes('phone') || lowerLabel.includes('mobile') || lowerLabel.includes('whatsapp')) {
            effectiveType = 'phone';
        }
    }
    switch(effectiveType){
        case 'email':
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return {
                isValid: emailRegex.test(value),
                error: emailRegex.test(value) ? undefined : 'Please enter a valid email address'
            };
        case 'phone':
            // Requires at least 10 digits, can have +, spaces, or dashes
            const phoneRegex = /^\+?[\d\s-]{10,}$/;
            const hasDigits = /\d/.test(value);
            const isTest = /^[a-zA-Z]+$/.test(value);
            const isValid = phoneRegex.test(value) && hasDigits && !isTest;
            return {
                isValid: isValid,
                error: isValid ? undefined : 'Please enter a valid 10-digit phone number'
            };
        case 'date':
            const date = new Date(value);
            return {
                isValid: !isNaN(date.getTime()),
                error: !isNaN(date.getTime()) ? undefined : 'Please enter a valid date'
            };
        case 'time':
            const timeRegex = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/;
            return {
                isValid: timeRegex.test(value),
                error: timeRegex.test(value) ? undefined : 'Please enter a valid time (HH:MM)'
            };
        default:
            return {
                isValid: true
            };
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/lib/auth.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "authOptions": (()=>authOptions),
    "clearSession": (()=>clearSession),
    "default": (()=>__TURBOPACK__default__export__),
    "getSession": (()=>getSession),
    "setSession": (()=>setSession)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next-auth/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$google$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next-auth/providers/google.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
;
;
const getSession = async ()=>{
    if ("TURBOPACK compile-time falsy", 0) {
        "TURBOPACK unreachable";
    }
    const token = localStorage.getItem('token');
    return token ? {
        token
    } : null;
};
const setSession = (token)=>{
    localStorage.setItem('token', token);
};
const clearSession = ()=>{
    localStorage.removeItem('token');
    localStorage.removeItem('rememberedCredentials'); // Also clear remembered credentials
};
const authOptions = {
    providers: [
        // Only add Google provider if credentials are available
        ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.GOOGLE_CLIENT_ID && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.GOOGLE_CLIENT_SECRET ? [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$google$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                clientId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.GOOGLE_CLIENT_ID,
                clientSecret: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.GOOGLE_CLIENT_SECRET
            })
        ] : []
    ],
    callbacks: {
        async jwt ({ token, account }) {
            if (account) {
                token.accessToken = account.access_token;
            }
            return token;
        },
        async session ({ session, token }) {
            if (token.accessToken) {
                session.accessToken = token.accessToken;
            }
            return session;
        }
    },
    pages: {
        signIn: '/signin',
        error: '/signin'
    },
    secret: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXTAUTH_SECRET
};
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(authOptions);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/errorParser.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "parseError": (()=>parseError)
});
function sanitizeMessage(msg) {
    if (!msg) return msg;
    if (msg.includes('SQLSTATE') || msg.includes('SQL:') || msg.includes('Connection: mysql')) {
        return "A database error occurred while processing your request. Please try again later.";
    }
    return msg;
}
function parseError(error) {
    if (error?.response) {
        const data = error.response.data;
        // Handle Laravel validation errors (422)
        if (error.response.status === 422 && data.errors) {
            const messages = Object.entries(data.errors).map(([field, errors])=>`${field}: ${errors.join(', ')}`).join('\n');
            return {
                message: messages || data.message || 'Validation failed',
                status: 422,
                errors: data.errors,
                raw: error
            };
        }
        const rawMessage = data?.message || mapStatus(error.response.status);
        return {
            message: sanitizeMessage(rawMessage),
            status: error.response.status,
            raw: error
        };
    }
    // Handle Axios Network Errors
    if (error?.message === 'Network Error') {
        return {
            message: "Cannot connect to server. Please check your internet connection.",
            raw: error
        };
    }
    if (error?.message) {
        const rawMsg = error.message === 'API Error' ? 'Something went wrong' : error.message;
        return {
            message: sanitizeMessage(rawMsg),
            raw: error
        };
    }
    return {
        message: "Something went wrong. Please try again.",
        raw: error
    };
}
function mapStatus(status) {
    switch(status){
        case 400:
            return "Invalid request";
        case 401:
            return "Session expired. Login again";
        case 403:
            return "Permission denied";
        case 404:
            return "Not found";
        case 500:
            return "Server error. Try later";
        default:
            return "Unexpected error";
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/logger.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "logger": (()=>logger)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/errorParser.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
;
;
;
const isDev = ("TURBOPACK compile-time value", "development") === "development";
const logger = {
    error: (message, error, options)=>{
        // Only log to console in dev if it's NOT a handled validation error or a network error
        const isHandled = error?.status === 422 || error?.status === 401;
        const isNetworkError = error?.message === 'Network Error' || error && !error.status && error.message?.includes('connect');
        if (isDev && !isHandled && !isNetworkError && !options?.hideConsole) {
            console.error(`[LEADBAJAAR ERR] ${message}`, error);
        }
        // Dispatch global error event for the UI to catch (if not handled and not silenced)
        if (!isHandled && !options?.silent && "object" !== 'undefined') {
            const parsed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseError"])(error);
            const errorDetail = parsed.message;
            // If it's a network error or a 500 server error, show the high-visibility Modal
            if (errorDetail.includes('connect to server') || parsed.status && parsed.status >= 500) {
                const event = new CustomEvent('app-global-error', {
                    detail: {
                        title: message,
                        message: errorDetail
                    }
                });
                window.dispatchEvent(event);
            } else {
                // For other unhandled errors, show a Toast
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(message, {
                    description: errorDetail
                });
            }
        }
        // Attempt to send to server ONLY if it's not a network error 
        // (no point trying to log to a server that is unreachable)
        if (!isNetworkError) {
            sendToServer(message, error);
        }
    },
    info: (message, data)=>{
        if ("TURBOPACK compile-time truthy", 1) {
            console.log(`[LEADBAJAAR INFO] ${message}`, data);
        }
    },
    warn: (message, data)=>{
        if ("TURBOPACK compile-time truthy", 1) {
            console.warn(`[LEADBAJAAR WARN] ${message}`, data);
        }
    }
};
async function sendToServer(message, error) {
    try {
        // Only attempt if we have an error to log
        const payload = {
            message,
            error: serialize(error),
            url: ("TURBOPACK compile-time truthy", 1) ? window.location.href : ("TURBOPACK unreachable", undefined),
            userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown',
            time: new Date().toISOString()
        };
        // Use our global API base URL for logging
        await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE_URL"]}/errors/log`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        });
    } catch (err) {
    // Fail silently in production
    }
}
function serialize(error) {
    if (!error) return null;
    return {
        message: error.message,
        stack: error.stack,
        status: error.response?.status || error.status,
        data: error.response?.data || error.data
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/lib/api.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "API_BASE_URL": (()=>API_BASE_URL),
    "WHATSAPP_BASE_URL": (()=>WHATSAPP_BASE_URL),
    "adminApi": (()=>adminApi),
    "agencyApi": (()=>agencyApi),
    "api": (()=>api),
    "authorize": (()=>authorize),
    "bulkDeleteLeads": (()=>bulkDeleteLeads),
    "bulkUpdateLeadStage": (()=>bulkUpdateLeadStage),
    "bulkUpdateLeadStatus": (()=>bulkUpdateLeadStatus),
    "companyApi": (()=>companyApi),
    "createLead": (()=>createLead),
    "createPayment": (()=>createPayment),
    "createStage": (()=>createStage),
    "default": (()=>__TURBOPACK__default__export__),
    "deleteBooking": (()=>deleteBooking),
    "deleteLead": (()=>deleteLead),
    "deleteStage": (()=>deleteStage),
    "evolutionApi": (()=>evolutionApi),
    "exportLeads": (()=>exportLeads),
    "financeApi": (()=>financeApi),
    "forgotPassword": (()=>forgotPassword),
    "getAnalyticsData": (()=>getAnalyticsData),
    "getBookings": (()=>getBookings),
    "getConversationMessages": (()=>getConversationMessages),
    "getDashboardStats": (()=>getDashboardStats),
    "getLead": (()=>getLead),
    "getLeads": (()=>getLeads),
    "getLeadsWithLatestMessages": (()=>getLeadsWithLatestMessages),
    "getMessages": (()=>getMessages),
    "getStages": (()=>getStages),
    "getUser": (()=>getUser),
    "googleIntegrationApi": (()=>googleIntegrationApi),
    "httpClient": (()=>httpClient),
    "importLeads": (()=>importLeads),
    "initializeChat": (()=>initializeChat),
    "integrationApi": (()=>integrationApi),
    "login": (()=>login),
    "loginWithGoogle": (()=>loginWithGoogle),
    "logout": (()=>logout),
    "me": (()=>me),
    "register": (()=>register),
    "reorderStages": (()=>reorderStages),
    "rescheduleBooking": (()=>rescheduleBooking),
    "resetPassword": (()=>resetPassword),
    "sendMessage": (()=>sendMessage),
    "submitTesterRequest": (()=>submitTesterRequest),
    "subscriptionApi": (()=>subscriptionApi),
    "syncDefaultStages": (()=>syncDefaultStages),
    "teamApi": (()=>teamApi),
    "updateBooking": (()=>updateBooking),
    "updateLead": (()=>updateLead),
    "updateLeadDetails": (()=>updateLeadDetails),
    "updateLeadStage": (()=>updateLeadStage),
    "updateStage": (()=>updateStage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/auth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/errorParser.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/logger.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
;
;
;
const API_BASE_URL = 'http://localhost:8000/api';
const WHATSAPP_BASE_URL = 'https://wp.leadbajaar.com/api';
const httpClient = {
    async get (url) {
        const response = await fetch(`${API_BASE_URL}${url}`);
        if (!response.ok) throw new Error('API Error');
        return response.json();
    },
    async post (url, data) {
        const response = await fetch(`${API_BASE_URL}${url}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        if (!response.ok) throw new Error('API Error');
        return response.json();
    },
    async put (url, data) {
        const response = await fetch(`${API_BASE_URL}${url}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        if (!response.ok) throw new Error('API Error');
        return response.json();
    },
    async delete (url) {
        const response = await fetch(`${API_BASE_URL}${url}`, {
            method: 'DELETE'
        });
        if (!response.ok) throw new Error('API Error');
        return response.json();
    }
};
const api = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
    withCredentials: true
});
// Add request interceptor to include token in headers
api.interceptors.request.use(async (config)=>{
    const token = localStorage.getItem('token') // or get from your auth system
    ;
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});
// Add response interceptor to handle errors globally
api.interceptors.response.use((response)=>response, (error)=>{
    const parsedError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseError"])(error);
    // Only log to console/logger if it's a server error or unexpected crash
    // 422 (Validation), 401 (Auth), and 402 (Payment) are handled by the UI
    if (!parsedError.status || parsedError.status >= 500) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error("API Error", error, {
            hideConsole: true
        });
    }
    // Global session handling (401)
    if (parsedError.status === 401) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSession"])();
        if ("TURBOPACK compile-time truthy", 1) {
            const currentPath = window.location.pathname;
            if (currentPath !== '/signin' && currentPath !== '/signup') {
                window.location.href = '/signin';
            }
        }
    }
    // Subscription Expired (402)
    if (parsedError.status === 402) {
        // The SubscriptionGuard will handle the UI overlay, 
        // but we can also trigger a toast or log here
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].warn("Subscription Expired", parsedError);
    }
    return Promise.reject(parsedError);
});
const login = async (email, password)=>{
    try {
        const response = await api.post('/login', {
            email,
            password
        });
        // Store the actual token from the response
        const token = response.data.token || response.data.access_token;
        if (!token) {
            throw new Error('No token received from server');
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setSession"])(token);
        return response.data;
    } catch (error) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isAxiosError(error)) {
            const axiosError = error;
            // Don't log the error to console for expected errors like invalid credentials
            if (axiosError.response?.status === 422) {
                throw new Error(axiosError.response.data.message || 'Invalid credentials');
            }
            if (axiosError.response?.data?.message) {
                throw new Error(axiosError.response.data.message);
            }
        }
        // Only log unexpected errors
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Login Failed', error);
        throw error;
    }
};
const register = async (name, email, password, password_confirmation, phone)=>{
    try {
        const response = await api.post('/register', {
            name,
            email,
            password,
            password_confirmation,
            phone
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setSession"])('your_auth_token');
        return response.data;
    } catch (error) {
        throw error;
    }
};
const forgotPassword = async (email)=>{
    try {
        const response = await api.post('/forgot-password', {
            email
        });
        return response.data;
    } catch (error) {
        const message = error.response?.data?.message || error.message || 'Failed to send reset link';
        throw new Error(message);
    }
};
const resetPassword = async (token, email, password, password_confirmation)=>{
    try {
        const response = await api.post('/reset-password', {
            token,
            email,
            password,
            password_confirmation
        });
        return response.data;
    } catch (error) {
        const message = error.response?.data?.message || error.message || 'Failed to reset password';
        throw new Error(message);
    }
};
const logout = async ()=>{
    try {
        const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSession"])();
        if (!session?.token) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSession"])();
            return true;
        }
        await api.post('/logout', {}, {
            headers: {
                Authorization: `Bearer ${session.token}`
            }
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSession"])();
        return true;
    } catch (error) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSession"])(); // Clear session even if logout fails
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isAxiosError(error)) {
            const axiosError = error;
            if (axiosError.response?.data?.message) {
                throw new Error(axiosError.response.data.message);
            }
        }
        throw new Error('Logout failed');
    }
};
const getUser = async ()=>{
    const response = await api.get('/user');
    return response.data;
};
const submitTesterRequest = async (data)=>{
    const response = await api.post('/tester-requests', data);
    return response.data;
};
const loginWithGoogle = async (token)=>{
    const response = await api.post('/login/google', {
        token
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setSession"])(token);
    return response.data;
};
const createLead = async (data)=>{
    const response = await api.post('/leads', {
        ...data,
        stage: data.stage || 'New'
    });
    return response.data;
};
const importLeads = async (data)=>{
    const response = await api.post('/leads/import', data);
    return response.data;
};
const getLeads = async (params)=>{
    try {
        const response = await api.get('/leads', {
            params
        });
        // If the response is already in the correct format, return it
        if (response.data?.data && Array.isArray(response.data.data)) {
            return response.data;
        }
        // If we get an array directly, wrap it in the expected format
        if (Array.isArray(response.data)) {
            return {
                data: response.data,
                meta: {
                    current_page: params.page || 1,
                    from: 1,
                    last_page: 1,
                    per_page: response.data.length,
                    to: response.data.length,
                    total: response.data.length
                }
            };
        }
        // Return the response data as is
        return response.data;
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Error fetching leads', error);
        throw error;
    }
};
const getLead = async (id)=>{
    const response = await api.get(`/leads/${id}`);
    return response.data;
};
const deleteLead = async (id)=>{
    await api.delete(`/leads/${id}`);
};
const bulkDeleteLeads = async (ids)=>{
    await api.post('/leads/bulk-destroy', {
        ids
    });
};
const bulkUpdateLeadStatus = async (ids, status)=>{
    await api.post('/leads/bulk-update-status', {
        ids,
        status
    });
};
const bulkUpdateLeadStage = async (ids, stage)=>{
    await api.post('/leads/bulk-update-stage', {
        ids,
        stage
    });
};
const updateLead = async (id, data)=>{
    const response = await api.put(`/leads/${id}`, data);
    return response.data;
};
const updateLeadStage = async (id, stage, deal_value)=>{
    const response = await api.patch(`/leads/${id}/stage`, {
        stage,
        deal_value
    });
    return response.data;
};
const getStages = async ()=>{
    const response = await api.get('/stages');
    return response.data;
};
const createStage = async (data)=>{
    const response = await api.post('/stages', data);
    return response.data;
};
const updateStage = async (id, data)=>{
    const response = await api.put(`/stages/${id}`, data);
    return response.data;
};
const deleteStage = async (id)=>{
    await api.delete(`/stages/${id}`);
};
const reorderStages = async (stages)=>{
    await api.post('/stages/reorder', {
        stages
    });
};
const syncDefaultStages = async ()=>{
    await api.post('/stages/initialize-default');
};
const createPayment = async (data)=>{
    const response = await api.post('/payments', data);
    return response.data;
};
const updateLeadDetails = async (id, data)=>{
    const response = await api.put(`/leads/${id}`, data);
    return response.data;
};
const formatMetaErrorMessage = (error, defaultMessage)=>{
    try {
        const errorData = error.response?.data?.error || error.response?.data;
        if (errorData) {
            if (typeof errorData === 'object') {
                // Meta errors usually have message, code, or error_subcode
                // We stringify the whole object so the frontend formatMetaError can parse it
                return JSON.stringify(errorData);
            }
            return String(errorData);
        }
        return error.message || defaultMessage;
    } catch (e) {
        return error?.message || defaultMessage;
    }
};
const integrationApi = {
    // Get all integrations
    getIntegrations: async ()=>{
        try {
            const response = await api.get('/integrations');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch integrations';
            throw new Error(message);
        }
    },
    // Save integration configuration
    saveIntegration: async (config)=>{
        try {
            const response = await api.post('/integrations', config);
            return response.data;
        } catch (error) {
            // Enhanced error handling for validation errors
            if (error.response?.status === 422) {
                const validationErrors = error.response.data.errors;
                if (validationErrors && typeof validationErrors === 'object') {
                    // Format validation errors into a readable message
                    const errorMessages = Object.entries(validationErrors).map(([field, messages])=>{
                        const messageArray = Array.isArray(messages) ? messages : [
                            messages
                        ];
                        return `${field}: ${messageArray.join(', ')}`;
                    }).join('; ');
                    throw new Error(`Validation failed: ${errorMessages}`);
                }
                // If errors object is not in expected format, try to get message
                const message = error.response.data.message || 'Validation failed';
                throw new Error(message);
            }
            throw error;
        }
    },
    // Update integration configuration
    updateIntegration: async (id, config)=>{
        try {
            const response = await api.put(`/integrations/${id}`, config);
            return response.data;
        } catch (error) {
            if (error.response?.status === 422) {
                const validationErrors = error.response.data.errors;
                const message = validationErrors && typeof validationErrors === 'object' ? Object.entries(validationErrors).map(([f, m])=>`${f}: ${Array.isArray(m) ? m.join(', ') : m}`).join('; ') : error.response.data.message || 'Validation failed';
                throw new Error(message);
            }
            throw error;
        }
    },
    // Update integration status
    updateIntegrationStatus: async (id, isActive)=>{
        try {
            const response = await api.patch(`/integrations/${id}/status`, {
                isActive
            });
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to update integration status';
            throw new Error(message);
        }
    },
    // Get integration logs
    getIntegrationLogs: async (id)=>{
        try {
            const response = await api.get(`/integrations/${id}/logs`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch integration logs';
            throw new Error(message);
        }
    },
    // Get the most recent log for an integration (used for testing webhooks)
    getLatestLog: async (id)=>{
        try {
            const response = await api.get(`/integrations/${id}/latest-log`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch latest log';
            throw new Error(message);
        }
    },
    // Delete integration
    deleteIntegration: async (id)=>{
        try {
            const response = await api.delete(`/integrations/${id}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to delete integration';
            throw new Error(message);
        }
    },
    getWhatsAppProfiles: async ()=>{
        try {
            const response = await api.get('/integrations/whatsapp/profiles');
            return response.data.profiles;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch WhatsApp profiles';
            throw new Error(message);
        }
    },
    getWhatsAppAccounts: async ()=>{
        try {
            const response = await api.get('/integrations/whatsapp/accounts');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch WhatsApp accounts';
            throw new Error(message);
        }
    },
    getWhatsAppTemplates: async (accountId)=>{
        try {
            const response = await api.get(`/integrations/whatsapp/${accountId}/templates`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch templates';
            throw new Error(message);
        }
    },
    syncWhatsAppTemplates: async (accountId)=>{
        try {
            const response = await api.post(`/integrations/whatsapp/${accountId}/templates/sync`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to sync templates';
            throw new Error(message);
        }
    },
    createWhatsAppTemplate: async (accountId, templateData)=>{
        try {
            const response = await api.post(`/integrations/whatsapp/${accountId}/templates`, templateData);
            return response.data;
        } catch (error) {
            // Enhanced error handling for validation errors
            if (error.response?.status === 422 && error.response?.data?.errors) {
                // Format validation errors
                const validationErrors = error.response.data.errors;
                const errorMessages = Object.entries(validationErrors).map(([field, messages])=>`${field}: ${Array.isArray(messages) ? messages.join(', ') : messages}`).join('; ');
                throw new Error(`Validation failed: ${errorMessages}`);
            } else if (error.response?.status === 401 && error.response?.data?.error_type === 'token_expired') {
                throw new Error('Your WhatsApp access token has expired. Please update your access token.');
            } else if (error.response?.data?.message) {
                throw new Error(error.response.data.message);
            } else {
                throw new Error('Failed to create template');
            }
        }
    },
    checkIntegrationStatus: async (accountId)=>{
        try {
            const response = await api.get(`/integrations/whatsapp/${accountId}/status`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to check integration status';
            throw new Error(message);
        }
    },
    markReauthenticated: async (accountId)=>{
        try {
            const response = await api.post(`/integrations/whatsapp/${accountId}/reauth`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to mark integration as re-authenticated';
            throw new Error(message);
        }
    },
    updateAccessToken: async (accountId, accessToken)=>{
        try {
            const response = await api.post(`/integrations/whatsapp/${accountId}/update-token`, {
                access_token: accessToken
            });
            return response.data;
        } catch (error) {
            if (error.response?.status === 400 && error.response?.data?.error_type === 'invalid_token') {
                throw new Error('Invalid access token. Please check your token and try again.');
            }
            const message = error.response?.data?.message || 'Failed to update access token';
            throw new Error(message);
        }
    },
    updateWhatsAppTemplate: async (accountId, templateId, templateData)=>{
        try {
            const response = await api.put(`/integrations/whatsapp/${accountId}/templates/${templateId}`, templateData);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to update template';
            throw new Error(message);
        }
    },
    deleteWhatsAppTemplate: async (accountId, templateId)=>{
        try {
            const response = await api.delete(`/integrations/whatsapp/${accountId}/templates/${templateId}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to delete template';
            throw new Error(message);
        }
    },
    getWhatsAppTemplateDetails: async (accountId, templateId)=>{
        try {
            const response = await api.get(`/integrations/whatsapp/${accountId}/templates/${templateId}/details`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to get template details';
            throw new Error(message);
        }
    },
    getConnectedIntegrations: async ()=>{
        try {
            const response = await api.get('/integrations/connected');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch connected integrations';
            throw new Error(message);
        }
    },
    // Add the sendBroadcast method
    sendBroadcast: async (data)=>{
        const response = await api.post('/leads/send-template', data);
        return response.data;
    },
    // Facebook Lead Retrieval Methods
    getFacebookLeadForms: async ()=>{
        try {
            const response = await api.get('/facebook-lead-forms');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch Facebook lead forms';
            throw new Error(message);
        }
    },
    debugIntegrations: async ()=>{
        try {
            const response = await api.get('/debug-integrations');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to debug integrations';
            throw new Error(message);
        }
    },
    // New Meta API Methods (v25.0)
    getMetaPages: async ()=>{
        try {
            const response = await api.get('/meta/pages');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta pages';
            throw new Error(message);
        }
    },
    getMetaPageForms: async (pageId)=>{
        try {
            const response = await api.get(`/meta/pages/${pageId}/forms`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta lead forms';
            throw new Error(message);
        }
    },
    // Meta Ads API Methods
    getMetaAdAccounts: async ()=>{
        try {
            const response = await api.get('/meta/ads/adaccounts');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta ad accounts';
            throw new Error(message);
        }
    },
    getMetaBusinessAdAccounts: async (businessId)=>{
        try {
            const response = await api.get(`/meta/ads/businesses/${businessId}/adaccounts`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch business ad accounts';
            throw new Error(message);
        }
    },
    getMetaCampaigns: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/campaigns`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta campaigns';
            throw new Error(message);
        }
    },
    getMetaAdSets: async (campaignId)=>{
        try {
            const response = await api.get(`/meta/ads/campaigns/${campaignId}/adsets`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta ad sets';
            throw new Error(message);
        }
    },
    getMetaAds: async (adSetId)=>{
        try {
            const response = await api.get(`/meta/ads/adsets/${adSetId}/ads`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta ads';
            throw new Error(message);
        }
    },
    getMetaAdAccountInsights: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/insights`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta ad insights';
            throw new Error(message);
        }
    },
    updateMetaStatus: async (objectId, status)=>{
        try {
            const response = await api.post(`/meta/ads/${objectId}/status`, {
                status
            });
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to update Meta status';
            throw new Error(message);
        }
    },
    retrieveFacebookLeads: async (data)=>{
        try {
            const response = await api.post('/facebook-lead-retrieval', data);
            return response.data;
        } catch (error) {
            // Enhanced error handling to preserve error details from backend
            if (error.response?.data) {
                // Create a new error with the backend's error details
                const backendError = new Error(error.response.data.error || 'Failed to retrieve Facebook leads');
                // Attach the response data to the error for the frontend to use
                backendError.response = error.response;
                throw backendError;
            }
            throw new Error('Failed to retrieve Facebook leads');
        }
    },
    connectMeta: async ()=>{
        try {
            const response = await api.get('/meta/connect');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to get Meta connection URL');
        }
    },
    getMetaStatus: async ()=>{
        try {
            const response = await api.get('/meta/status');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to fetch Meta status');
        }
    },
    disconnectMeta: async ()=>{
        try {
            const response = await api.post('/meta/deauthorize'); // Now hits the authenticated route
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to disconnect Meta');
        }
    },
    dataDeletionRequest: async ()=>{
        try {
            const response = await api.post('/meta/data-deletion'); // Now hits the authenticated route
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to request data deletion');
        }
    },
    getDeletionRequests: async ()=>{
        try {
            const response = await api.get('/meta/deletion-requests');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to fetch deletion requests');
        }
    },
    getMetaBusinessAssets: async (businessId)=>{
        try {
            const response = await api.get(`/meta/business/${businessId}/assets`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to fetch business assets');
        }
    },
    // Facebook Conversion API Methods
    sendConversionEvent: async (data)=>{
        try {
            const response = await api.post('/facebook/conversion-api/send-event', data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to send conversion event';
            throw new Error(message);
        }
    },
    sendBatchConversionEvents: async (data)=>{
        try {
            const response = await api.post('/facebook/conversion-api/send-batch-events', data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to send batch conversion events';
            throw new Error(message);
        }
    },
    sendTestConversionEvent: async (data)=>{
        try {
            const response = await api.post('/facebook/conversion-api/send-test-event', data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to send test conversion event';
            throw new Error(message);
        }
    },
    getConversionApiEventTypes: async ()=>{
        try {
            const response = await api.get('/facebook/conversion-api/event-types');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch event types';
            throw new Error(message);
        }
    },
    getConversionApiConfiguration: async ()=>{
        try {
            const response = await api.get('/facebook/conversion-api/configuration');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Conversion API configuration';
            throw new Error(message);
        }
    },
    getMetaWebhookChecklist: async (pageId)=>{
        try {
            const response = await api.get(`/meta/pages/${pageId}/webhook-checklist`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch webhook checklist';
            throw new Error(message);
        }
    },
    testMetaLeadRetrieval: async (leadId)=>{
        try {
            const response = await api.get(`/meta/debug/lead/${leadId}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch lead details';
            throw new Error(message);
        }
    },
    updateConversionApiConfiguration: async (data)=>{
        try {
            const response = await api.post('/facebook/conversion-api/configuration', data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to update Conversion API configuration';
            throw new Error(message);
        }
    },
    syncMetaLeads: async (formId, days = 7)=>{
        try {
            const response = await api.post(`/meta/forms/${formId}/sync-leads`, {
                days
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to sync leads'));
        }
    },
    createMetaCampaign: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/campaigns`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta campaign'));
        }
    },
    createMetaAdSet: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adsets`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta ad set'));
        }
    },
    updateMetaAdSet: async (adSetId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adsets/${adSetId}`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to update Meta ad set'));
        }
    },
    createMetaAd: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/ads`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta ad'));
        }
    },
    getMetaAdCreatives: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/adcreatives`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch Meta ad creatives'));
        }
    },
    createMetaAdCreativeStandalone: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adcreatives`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta ad creative'));
        }
    },
    createMetaPageForm: async (pageId, formData)=>{
        try {
            const response = await api.post(`/meta/pages/${pageId}/forms`, formData);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta Lead Form'));
        }
    },
    syncMetaAssets: async ()=>{
        try {
            const response = await api.post('/meta/ads/sync');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to sync Meta assets';
            throw new Error(message);
        }
    },
    syncMetaAdAccountDetails: async (adAccountId)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/sync`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to sync ad account details';
            throw new Error(message);
        }
    },
    subscribeMetaPage: async (pageId)=>{
        try {
            const response = await api.post(`/meta/pages/${pageId}/subscribe`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to subscribe page to webhook';
            throw new Error(message);
        }
    },
    getMetaTemplates: async ()=>{
        try {
            const response = await api.get('/meta/ads/templates');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta templates';
            throw new Error(message);
        }
    },
    launchMetaTemplate: async (adAccountId, templateId, customName)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/launch-template`, {
                template_id: templateId,
                custom_name: customName
            });
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to launch Meta template';
            throw new Error(message);
        }
    },
    deleteMetaObject: async (objectId)=>{
        try {
            const response = await api.delete(`/meta/ads/${objectId}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to delete Meta object';
            throw new Error(message);
        }
    },
    updateMetaCampaign: async (campaignId, data)=>{
        try {
            const response = await api.post(`/meta/ads/campaigns/${campaignId}`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to update Meta campaign'));
        }
    },
    createMetaCustomAudience: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/customaudiences`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta custom audience'));
        }
    },
    createMetaLookalikeAudience: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/lookalike-audiences`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta lookalike audience'));
        }
    },
    uploadMetaAdImage: async (adAccountId, image)=>{
        try {
            let response;
            if (typeof image === 'string') {
                response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adimages`, {
                    image_url: image
                });
            } else {
                const formData = new FormData();
                formData.append('image', image);
                response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adimages`, formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                });
            }
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to upload Meta ad image'));
        }
    },
    uploadMetaAdVideo: async (adAccountId, video, title)=>{
        try {
            let response;
            if (typeof video === 'string') {
                response = await api.post(`/meta/ads/adaccounts/${adAccountId}/advideos`, {
                    video_url: video,
                    title
                });
            } else {
                const formData = new FormData();
                formData.append('video', video);
                if (title) formData.append('title', title);
                response = await api.post(`/meta/ads/adaccounts/${adAccountId}/advideos`, formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                });
            }
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to upload Meta ad video'));
        }
    },
    getMetaAdPreview: async (objectId, adFormat = 'DESKTOP_FEED_STANDARD')=>{
        try {
            const response = await api.get(`/meta/ads/previews/${objectId}`, {
                params: {
                    ad_format: adFormat
                }
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch Meta ad preview'));
        }
    },
    duplicateMetaCampaign: async (campaignId, options)=>{
        try {
            const response = await api.post(`/meta/ads/campaigns/${campaignId}/duplicate`, options);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to duplicate Meta campaign'));
        }
    },
    duplicateMetaObject: async (objectId)=>{
        try {
            const response = await api.post(`/meta/ads/${objectId}/duplicate`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to duplicate Meta object'));
        }
    },
    getMetaOfflineEventSets: async (objectId)=>{
        try {
            const response = await api.get(`/meta/ads/offline-event-sets/${objectId}`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch offline event sets'));
        }
    },
    createMetaOfflineEventSet: async (businessId, data)=>{
        try {
            const response = await api.post(`/meta/ads/offline-event-sets/${businessId}`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create offline event set'));
        }
    },
    getMetaAutomatedRules: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/adrules`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch automated rules'));
        }
    },
    createMetaAutomatedRule: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adrules`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create automated rule'));
        }
    },
    deleteMetaAutomatedRule: async (ruleId)=>{
        try {
            const response = await api.delete(`/meta/ads/adrules/${ruleId}`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to delete automated rule'));
        }
    },
    getMetaFormDetails: async (formId)=>{
        try {
            const response = await api.get(`/meta/forms/${formId}`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch Meta form details'));
        }
    },
    updateMetaFormStatus: async (formId, status)=>{
        try {
            const response = await api.post(`/meta/forms/${formId}/status`, {
                status
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to update Meta form status'));
        }
    },
    // Fix 14: Track form endpoints
    trackMetaForm: async (pageId, formId, formName, pageName)=>{
        try {
            const response = await api.post(`/meta/pages/${pageId}/forms/track`, {
                form_id: formId,
                form_name: formName,
                page_name: pageName
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to track form'));
        }
    },
    getMetaTrackedForms: async (pageId)=>{
        try {
            const response = await api.get(`/meta/pages/${pageId}/forms/tracked`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to load tracked forms'));
        }
    },
    getMetaDeliveryEstimate: async (adAccountId, targetingSpec)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/delivery-estimate`, {
                params: {
                    targeting_spec: targetingSpec
                }
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch delivery estimate'));
        }
    },
    getMetaAccountAds: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/ads`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch account ads'));
        }
    },
    getMetaCampaignAds: async (campaignId)=>{
        try {
            const response = await api.get(`/meta/ads/campaigns/${campaignId}/ads`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch campaign ads'));
        }
    },
    updateMetaAd: async (adId, data)=>{
        try {
            const response = await api.post(`/meta/ads/ads/${adId}`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to update Meta ad'));
        }
    },
    // Meta Pixel Methods
    getMetaPixels: async ()=>{
        try {
            const response = await api.get('/meta/pixels');
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch Meta pixels'));
        }
    },
    sendMetaCapiEvent: async (data)=>{
        try {
            // Use the test endpoint if a code is provided, otherwise standard send
            const endpoint = data.test_event_code ? '/meta/pixels/test-event' : '/meta/pixels/send-event';
            const response = await api.post(endpoint, data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to send Meta CAPI event';
            throw new Error(message);
        }
    },
    getMetaPixelDiagnostics: async (pixelId)=>{
        try {
            const response = await api.get(`/meta/pixels/${pixelId}/diagnostics`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch pixel diagnostics'));
        }
    },
    syncMetaPixels: async ()=>{
        try {
            const response = await api.post('/meta/pixels/sync');
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to sync Meta pixels'));
        }
    },
    updateMetaPixel: async (id, data)=>{
        try {
            const response = await api.patch(`/meta/pixels/${id}`, data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to update Meta pixel';
            throw new Error(message);
        }
    },
    deleteMetaPixel: async (id)=>{
        try {
            const response = await api.delete(`/meta/pixels/${id}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to delete Meta pixel';
            throw new Error(message);
        }
    },
    getMetaPixelRoiSummary: async (days = 30)=>{
        try {
            const response = await api.get('/meta/pixels/roi-summary', {
                params: {
                    days
                }
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch ROI summary'));
        }
    },
    createMetaPixel: async (data)=>{
        try {
            const response = await api.post('/meta/pixels/create', data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create pixel'));
        }
    }
};
const companyApi = {
    getSettings: async ()=>{
        try {
            const response = await api.get('/company/settings');
            return response.data.settings;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch company settings';
            throw new Error(message);
        }
    },
    updateSettings: async (settings)=>{
        try {
            const response = await api.patch('/company/settings', settings);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to update company settings';
            throw new Error(message);
        }
    }
};
const exportLeads = async (ids)=>{
    try {
        const response = await api.post('/leads/export', {
            ids
        }, {
            responseType: 'blob',
            headers: {
                'Accept': 'text/csv',
                'Content-Type': 'application/json'
            }
        });
        // Get filename from response headers or use default
        const filename = response.headers['content-disposition']?.split('filename=')[1] || `leads-${new Date().toISOString().split('T')[0]}.csv`;
        // Create download link
        const blob = new Blob([
            response.data
        ], {
            type: 'text/csv'
        });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', filename);
        // Trigger download
        document.body.appendChild(link);
        link.click();
        // Cleanup
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
        return true;
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Export error:', error);
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isAxiosError(error)) {
            // Handle different error types
            if (error.response?.status === 404) {
                throw new Error('No leads found to export.');
            }
            throw new Error('Failed to export leads. Please try again.');
        }
        throw new Error('An unexpected error occurred during export.');
    }
};
const me = async ()=>{
    const response = await api.get('/user', {
        headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`
        }
    });
    return response.data;
};
const sendMessage = async (data)=>{
    const response = await api.post('/send-message', data);
    return response.data;
};
const authorize = async (data)=>{
    const response = await api.post('/broadcasting/auth', data);
    return response.data;
};
const getMessages = async (data)=>{
    const response = await api.post('/messages', data);
    return response.data;
};
const initializeChat = async (data)=>{
    const response = await api.post('/initialize-chat', data);
    return response.data;
};
const getLeadsWithLatestMessages = async ()=>{
    try {
        const response = await api.get('/conversations', {
            headers: {
                Authorization: `Bearer ${localStorage.getItem('token')}`
            }
        });
        return response.data;
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Error fetching conversations:', error);
        throw error;
    }
};
const getConversationMessages = async (conversationId, lastTimestamp)=>{
    try {
        const response = await api.get(`/conversations/${conversationId}/messages`, {
            headers: {
                Authorization: `Bearer ${localStorage.getItem('token')}`
            },
            params: {
                after: lastTimestamp
            }
        });
        return response.data;
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Error fetching messages:', error);
        throw error;
    }
};
const getBookings = async (params)=>{
    return api.get('/bookings', {
        params
    });
};
const deleteBooking = async (id)=>{
    return api.delete(`/bookings/${id}`);
};
const updateBooking = async (id, data)=>{
    return api.put(`/bookings/${id}`, data);
};
const rescheduleBooking = async (id, data)=>{
    return api.patch(`/bookings/${id}/reschedule`, data);
};
const teamApi = {
    getMembers: async ()=>{
        const response = await api.get('/team');
        return response.data.members;
    },
    inviteMember: async (data)=>{
        const response = await api.post('/team/invite', data);
        return response.data;
    },
    resendInvite: async (id)=>{
        const response = await api.post(`/team/${id}/resend-invite`);
        return response.data;
    },
    updateRole: async (id, role)=>{
        const response = await api.patch(`/team/${id}/role`, {
            role
        });
        return response.data;
    },
    removeMember: async (id)=>{
        const response = await api.delete(`/team/${id}`);
        return response.data;
    },
    setupAccount: async (data)=>{
        try {
            const response = await api.post('/setup-account', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to setup account');
        }
    }
};
const adminApi = {
    getStats: async ()=>{
        try {
            const response = await api.get('/admin/stats');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch admin stats');
        }
    },
    getCompanies: async (page = 1, limit = 10, search, plan, status, tag, expiration, started, expStart, expEnd, startStart, startEnd)=>{
        try {
            let url = `/admin/companies?page=${page}&limit=${limit}`;
            if (search) url += `&search=${search}`;
            if (plan && plan !== 'all') url += `&plan=${plan}`;
            if (status && status !== 'all') url += `&status=${status}`;
            if (tag && tag !== 'all') url += `&tag=${tag}`;
            if (expiration && expiration !== 'all') url += `&expiration=${expiration}`;
            if (started && started !== 'all') url += `&started=${started}`;
            if (expStart) url += `&exp_start=${expStart}`;
            if (expEnd) url += `&exp_end=${expEnd}`;
            if (startStart) url += `&start_start=${startStart}`;
            if (startEnd) url += `&start_end=${startEnd}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch companies');
        }
    },
    updateCompany: async (id, data)=>{
        try {
            const response = await api.patch(`/admin/companies/${id}`, data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update company');
        }
    },
    getUsers: async (page = 1, limit = 10, search, tag, role, status, userType)=>{
        try {
            let url = `/admin/users?page=${page}&limit=${limit}`;
            if (search) url += `&search=${search}`;
            if (tag && tag !== 'all') url += `&tag=${tag}`;
            if (role && role !== 'all') url += `&role=${role}`;
            if (status && status !== 'all') url += `&status=${status}`;
            if (userType && userType !== 'all') url += `&user_type=${userType}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch users');
        }
    },
    updateUser: async (id, data)=>{
        try {
            const response = await api.patch(`/admin/users/${id}`, data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update user');
        }
    },
    getTesterRequests: async (page = 1, limit = 10, search)=>{
        try {
            let url = `/admin/tester-requests?page=${page}&limit=${limit}`;
            if (search) url += `&search=${search}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch tester requests');
        }
    },
    updateTesterRequestStatus: async (id, status)=>{
        try {
            const response = await api.patch(`/admin/tester-requests/${id}/status`, {
                status
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update status');
        }
    },
    deleteUser: async (id)=>{
        try {
            const response = await api.delete(`/admin/users/${id}`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to delete user');
        }
    },
    getEmailStats: async (search, page = 1, limit = 10, filterStatus = 'all')=>{
        try {
            const response = await api.get('/admin/email-stats', {
                params: {
                    search,
                    page,
                    limit,
                    filterStatus
                }
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch email stats');
        }
    },
    toggleUserNotification: async (userId, type = 'new_lead')=>{
        try {
            const response = await api.post(`/admin/users/${userId}/toggle-notification`, {
                type
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to toggle notification');
        }
    },
    toggleCompanyEmail: async (id)=>{
        try {
            const response = await api.post(`/admin/companies/${id}/toggle-email`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to toggle company email');
        }
    },
    deleteCompany: async (id)=>{
        try {
            const response = await api.delete(`/admin/companies/${id}`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to delete company');
        }
    },
    renewCompany: async (id, days, notes)=>{
        try {
            const response = await api.post(`/admin/companies/${id}/renew`, {
                days,
                notes
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to renew company');
        }
    },
    getCompanyHistory: async (id)=>{
        try {
            const response = await api.get(`/admin/companies/${id}/history`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch subscription history');
        }
    },
    loginAsAnyUser: async (id)=>{
        try {
            const response = await api.post(`/admin/users/${id}/login`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to impersonate user');
        }
    },
    getBilling: async (page = 1, limit = 10, search)=>{
        try {
            const url = `/admin/billing?page=${page}&limit=${limit}${search ? `&search=${search}` : ''}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch billing data');
        }
    },
    getPendingPayments: async (page = 1, limit = 10)=>{
        try {
            const url = `/admin/payments/pending?page=${page}&limit=${limit}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch pending payments');
        }
    },
    approvePayment: async (id)=>{
        try {
            const response = await api.post(`/admin/payments/${id}/approve`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to approve payment');
        }
    },
    getPlans: async ()=>{
        try {
            const response = await api.get('/admin/plans');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch plans');
        }
    },
    createPlan: async (data)=>{
        try {
            const response = await api.post('/admin/plans', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to create plan');
        }
    },
    updatePlan: async (id, data)=>{
        try {
            const response = await api.patch(`/admin/plans/${id}`, data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update plan');
        }
    },
    getTags: async ()=>{
        try {
            const response = await api.get('/admin/tags');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch tags');
        }
    },
    sendBroadcast: async (data)=>{
        try {
            const response = await api.post('/admin/broadcast', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to send broadcast');
        }
    },
    getBroadcastHistory: async ()=>{
        try {
            const response = await api.get('/admin/broadcast/history');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch broadcast history');
        }
    },
    // Coupons
    getCoupons: async ()=>{
        try {
            const response = await api.get('/admin/payments/coupons');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch coupons');
        }
    },
    createCoupon: async (data)=>{
        try {
            const response = await api.post('/admin/payments/coupons', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to create coupon');
        }
    },
    updateCoupon: async (id, data)=>{
        try {
            const response = await api.patch(`/admin/payments/coupons/${id}`, data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update coupon');
        }
    },
    deleteCoupon: async (id)=>{
        try {
            const response = await api.delete(`/admin/payments/coupons/${id}`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to delete coupon');
        }
    },
    // Settings
    getSettings: async ()=>{
        try {
            const response = await api.get('/admin/payments/settings');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch settings');
        }
    },
    updateSettings: async (data)=>{
        try {
            const response = await api.post('/admin/payments/settings', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update settings');
        }
    }
};
const agencyApi = {
    getClients: async ()=>{
        try {
            const response = await api.get('/agency/clients');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch clients');
        }
    },
    onboardClient: async (data)=>{
        try {
            const response = await api.post('/agency/onboard', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to onboard client');
        }
    },
    getStats: async ()=>{
        try {
            const response = await api.get('/agency/stats');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch agency stats');
        }
    },
    loginAsClient: async (id)=>{
        try {
            const response = await api.post(`/agency/clients/${id}/login`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to impersonate client');
        }
    },
    deleteClient: async (id)=>{
        try {
            const response = await api.delete(`/agency/clients/${id}`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to delete client');
        }
    },
    renewClient: async (id)=>{
        try {
            const response = await api.post(`/agency/clients/${id}/renew`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to renew client');
        }
    },
    getClientHistory: async (id)=>{
        try {
            const response = await api.get(`/agency/clients/${id}/history`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch history');
        }
    }
};
const __TURBOPACK__default__export__ = api;
const getDashboardStats = async ()=>{
    const response = await api.get('/dashboard/stats');
    return response.data;
};
const getAnalyticsData = async ()=>{
    const response = await api.get('/analytics');
    return response.data;
};
const financeApi = {
    // ── Dashboard ─────────────────────────────────────────────────────────────
    getDashboard: (month, year)=>api.get('/super-admin/finance/dashboard', {
            params: {
                month,
                year
            }
        }).then((r)=>r.data),
    // ── Expense Categories ────────────────────────────────────────────────────
    getCategories: ()=>api.get('/super-admin/finance/categories').then((r)=>r.data),
    createCategory: (data)=>api.post('/super-admin/finance/categories', data).then((r)=>r.data),
    updateCategory: (id, data)=>api.put(`/super-admin/finance/categories/${id}`, data).then((r)=>r.data),
    deleteCategory: (id)=>api.delete(`/super-admin/finance/categories/${id}`).then((r)=>r.data),
    // ── Expenses ──────────────────────────────────────────────────────────────
    getExpenses: (params)=>api.get('/super-admin/finance/expenses', {
            params
        }).then((r)=>r.data),
    createExpense: (data)=>api.post('/super-admin/finance/expenses', data).then((r)=>r.data),
    updateExpense: (id, data)=>api.put(`/super-admin/finance/expenses/${id}`, data).then((r)=>r.data),
    deleteExpense: (id)=>api.delete(`/super-admin/finance/expenses/${id}`).then((r)=>r.data),
    uploadReceipt: (id, file)=>{
        const fd = new FormData();
        fd.append('receipt', file);
        return api.post(`/super-admin/finance/expenses/${id}/upload-receipt`, fd, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        }).then((r)=>r.data);
    },
    getDailyExpenses: (date)=>api.get(`/super-admin/finance/expenses/daily/${date}`).then((r)=>r.data),
    getMonthlyExpenses: (month, year)=>api.get(`/super-admin/finance/expenses/monthly/${month}/${year}`).then((r)=>r.data),
    getRecurringExpenses: ()=>api.get('/super-admin/finance/expenses/recurring').then((r)=>r.data),
    // ── Employees ─────────────────────────────────────────────────────────────
    getEmployees: (params)=>api.get('/super-admin/finance/employees', {
            params
        }).then((r)=>r.data),
    createEmployee: (data)=>api.post('/super-admin/finance/employees', data).then((r)=>r.data),
    updateEmployee: (id, data)=>api.put(`/super-admin/finance/employees/${id}`, data).then((r)=>r.data),
    deleteEmployee: (id)=>api.delete(`/super-admin/finance/employees/${id}`).then((r)=>r.data),
    getEmployeeSalaryHistory: (id)=>api.get(`/super-admin/finance/employees/${id}/salary-history`).then((r)=>r.data),
    toggleEmployeeActive: (id)=>api.post(`/super-admin/finance/employees/${id}/toggle-active`).then((r)=>r.data),
    getEmployeeRevisions: (id)=>api.get(`/super-admin/finance/employees/${id}/revisions`).then((r)=>r.data),
    addEmployeeRevision: (id, data)=>api.post(`/super-admin/finance/employees/${id}/revisions`, data).then((r)=>r.data),
    // ── Payroll ───────────────────────────────────────────────────────────────
    getPayrollCycle: (month, year)=>api.get(`/super-admin/finance/payroll/cycle/${month}/${year}`).then((r)=>r.data),
    generatePayroll: (month, year)=>api.post(`/super-admin/finance/payroll/generate/${month}/${year}`).then((r)=>r.data),
    markPayoutPaid: (payoutId, data)=>api.put(`/super-admin/finance/payroll/${payoutId}/mark-paid`, data).then((r)=>r.data),
    updatePayoutStatus: (payoutId, status)=>api.put(`/super-admin/finance/payroll/${payoutId}/status`, {
            status
        }).then((r)=>r.data),
    uploadPayoutProof: (payoutId, file)=>{
        const fd = new FormData();
        fd.append('proof', file);
        return api.post(`/super-admin/finance/payroll/${payoutId}/upload-proof`, fd, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        }).then((r)=>r.data);
    },
    getPayrollAnnualSummary: (year)=>api.get(`/super-admin/finance/payroll/summary/${year}`).then((r)=>r.data),
    // ── Revenue & MRR (Phase 2) ────────────────────────────────────────────────
    getRevenueCompanies: ()=>api.get('/super-admin/finance/revenue/companies').then((r)=>r.data),
    getMrrBreakdown: ()=>api.get('/super-admin/finance/revenue/mrr').then((r)=>r.data),
    getMrrHistory: ()=>api.get('/super-admin/finance/revenue/mrr/history').then((r)=>r.data),
    getSubscriptions: (params)=>api.get('/super-admin/finance/revenue/subscriptions', {
            params
        }).then((r)=>r.data),
    manualRenewal: (data)=>api.post('/super-admin/finance/revenue/renewals', data).then((r)=>r.data),
    getRevenueAdjustments: (params)=>api.get('/super-admin/finance/revenue/adjustments', {
            params
        }).then((r)=>r.data),
    createRevenueAdjustment: (data)=>api.post('/super-admin/finance/revenue/adjustments', data).then((r)=>r.data),
    getRevenueTarget: (month, year)=>api.get(`/super-admin/finance/revenue/targets/${month}/${year}`).then((r)=>r.data),
    setRevenueTarget: (data)=>api.post('/super-admin/finance/revenue/targets', data).then((r)=>r.data),
    getUpgradeLog: (month, year)=>api.get('/super-admin/finance/revenue/upgrade-log', {
            params: {
                month,
                year
            }
        }).then((r)=>r.data),
    // ── Churn Tracking (Phase 2) ──────────────────────────────────────────────
    getChurnLog: (params)=>api.get('/super-admin/finance/churn', {
            params
        }).then((r)=>r.data),
    tagChurnReason: (id, data)=>api.post(`/super-admin/finance/churn/${id}/reason`, data).then((r)=>r.data),
    detectChurn: ()=>api.post('/super-admin/finance/churn/detect').then((r)=>r.data),
    // ── Plans & Pricing (Phase 2) ─────────────────────────────────────────────
    getPlans: ()=>api.get('/super-admin/finance/plans').then((r)=>r.data),
    updatePlanPricing: (data)=>api.put('/super-admin/finance/plans/pricing', data).then((r)=>r.data),
    getPlanPricingHistory: (params)=>api.get('/super-admin/finance/plans/pricing/history', {
            params
        }).then((r)=>r.data),
    // ── Reports (Phase 2) ─────────────────────────────────────────────────────
    getMonthlyPlReport: (month, year)=>api.get(`/super-admin/finance/reports/pl/${month}/${year}`).then((r)=>r.data),
    getAnnualReport: (year)=>api.get(`/super-admin/finance/reports/annual/${year}`).then((r)=>r.data),
    getPayrollReport: (year)=>api.get(`/super-admin/finance/reports/payroll/${year}`).then((r)=>r.data),
    getGstReport: (month, year)=>api.get(`/super-admin/finance/reports/gst/${month}/${year}`).then((r)=>r.data)
};
const googleIntegrationApi = {
    getStatus: async ()=>{
        try {
            const response = await api.get('/google/status');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch Google status';
            throw new Error(message);
        }
    },
    disconnect: async ()=>{
        try {
            const response = await api.delete('/google/disconnect');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to disconnect Google account';
            throw new Error(message);
        }
    },
    getConnectUrl: async (scope)=>{
        try {
            const response = await api.get('/google/connect', {
                params: {
                    scope
                }
            });
            return response.data.url;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to get connection URL';
            throw new Error(message);
        }
    }
};
const subscriptionApi = {
    getSettings: async ()=>{
        try {
            const response = await api.get('/subscription/settings');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch subscription settings');
        }
    },
    validateCoupon: async (couponCode)=>{
        try {
            const response = await api.post('/subscription/validate-coupon', {
                coupon_code: couponCode
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to validate coupon');
        }
    }
};
const evolutionApi = {
    getAccounts: async ()=>{
        const response = await api.get('/evolution/accounts');
        return response.data;
    },
    createAccount: async (phoneNumber)=>{
        const response = await api.post('/evolution/accounts', {
            phone_number: phoneNumber
        });
        return response.data;
    },
    connectInstance: async (instanceName)=>{
        const response = await api.post(`/evolution/accounts/${instanceName}/connect`);
        return response.data;
    },
    getQrCode: async (instanceName)=>{
        const response = await api.get(`/evolution/accounts/${instanceName}/qrcode`);
        return response.data;
    },
    getStatus: async (instanceName)=>{
        const response = await api.get(`/evolution/accounts/${instanceName}/status`);
        return response.data;
    },
    disconnectInstance: async (instanceName)=>{
        const response = await api.post(`/evolution/accounts/${instanceName}/disconnect`);
        return response.data;
    },
    deleteAccount: async (instanceName)=>{
        const response = await api.delete(`/evolution/accounts/${instanceName}`);
        return response.data;
    },
    getConversations: async ()=>{
        const response = await api.get('/evolution/inbox/conversations');
        return response.data;
    },
    getMessages: async (conversationId)=>{
        const response = await api.get(`/evolution/inbox/conversations/${conversationId}/messages`);
        return response.data;
    },
    sendMessage: async (conversationId, message)=>{
        const response = await api.post('/evolution/inbox/messages/send', {
            conversation_id: conversationId,
            message
        });
        return response.data;
    },
    deleteConversation: async (conversationId)=>{
        const response = await api.delete(`/evolution/inbox/conversations/${conversationId}`);
        return response.data;
    },
    clearSession: async (conversationId)=>{
        const response = await api.post('/evolution/inbox/session/clear', {
            conversation_id: conversationId
        });
        return response.data;
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/[username]/[eventSlug]/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>BookingPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$custom$2d$calendar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/custom-calendar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/avatar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$radio$2d$group$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/radio-group.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/checkbox.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/select.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$validations$2f$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/validations/questions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/date-fns/format.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Globe$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/globe.js [app-client] (ecmascript) <export default as Globe>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/addDays.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/circle-check.js [app-client] (ecmascript) <export default as CheckCircle2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Zap$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/zap.js [app-client] (ecmascript) <export default as Zap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/circle-alert.js [app-client] (ecmascript) <export default as AlertCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$startOfDay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/startOfDay.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$isBefore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/isBefore.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$isAfter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/isAfter.js [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const isDateAvailable = (date, eventType)=>{
    const today = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$startOfDay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startOfDay"])(new Date());
    const maxDate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addDays"])(today, eventType.scheduling.dateRange);
    // Check if date is within allowed range
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$isBefore$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isBefore"])(date, today) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$isAfter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAfter"])(date, maxDate)) {
        return false;
    }
    // Derive available days from timeSlots[].daysOfWeek (0=Sun, 1=Mon … 6=Sat)
    // This is the real source of truth — the legacy 'availableDays' string array
    // does not reflect Saturday/Sunday changes made in TimeSlotManager.
    const timeSlots = eventType.scheduling.timeSlots ?? [];
    if (timeSlots.length > 0) {
        // Collect all day numbers configured across all time slots
        const availableDayNumbers = new Set(timeSlots.flatMap((slot)=>slot.daysOfWeek));
        // date-fns getDay(): 0=Sun, 1=Mon … 6=Sat — same convention as the backend
        return availableDayNumbers.has(date.getDay());
    }
    // Fallback: use the legacy string-name array if no timeSlots configured
    const dayName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(date, 'EEEE'); // 'Monday', 'Saturday', etc.
    return (eventType.scheduling.availableDays ?? []).includes(dayName);
};
function CalendarSkeleton() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center px-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-5 w-32 bg-muted rounded animate-pulse"
                    }, void 0, false, {
                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-8 w-8 bg-muted rounded-full animate-pulse"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                lineNumber: 88,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-8 w-8 bg-muted rounded-full animate-pulse"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                lineNumber: 89,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                        lineNumber: 87,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                lineNumber: 85,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-7 gap-y-2 gap-x-1",
                children: [
                    [
                        ...Array(7)
                    ].map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 w-full max-w-6 mx-auto bg-muted/50 rounded animate-pulse mb-2"
                        }, i, false, {
                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                            lineNumber: 97,
                            columnNumber: 11
                        }, this)),
                    [
                        ...Array(35)
                    ].map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "aspect-square w-full max-w-10 rounded-full bg-muted/30 animate-pulse mx-auto"
                        }, i, false, {
                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                            lineNumber: 101,
                            columnNumber: 11
                        }, this))
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                lineNumber: 94,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
        lineNumber: 83,
        columnNumber: 5
    }, this);
}
_c = CalendarSkeleton;
function BookingPage() {
    _s();
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const isEmbed = searchParams.get('embed') === 'true';
    const username = params.username;
    const eventSlug = params.eventSlug;
    const [step, setStep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [answers, setAnswers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [errors, setErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [eventType, setEventType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedDate, setSelectedDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    const [selectedTime, setSelectedTime] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [availableSlots, setAvailableSlots] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [bookingError, setBookingError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentQuestionIndex, setCurrentQuestionIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isSubmitting, setIsSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLoadingSlots, setIsLoadingSlots] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showSuccess, setShowSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [bookingDetails, setBookingDetails] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const slotsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const nextButtonRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BookingPage.useEffect": ()=>{
            const fetchEventType = {
                "BookingPage.useEffect.fetchEventType": async ()=>{
                    try {
                        const response = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE_URL"]}/event-types/${eventSlug}`, {
                            headers: {
                                'Content-Type': 'application/json',
                                'Accept': 'application/json'
                            }
                        });
                        if (!response.ok) {
                            throw new Error('Failed to fetch event type');
                        }
                        const data = await response.json();
                        // Map API response to frontend model with proper scheduling data
                        const mappedEventType = {
                            id: data.id,
                            title: data.title,
                            description: data.description,
                            duration: data.duration,
                            location: data.location,
                            questions: data.questions || [],
                            scheduling: {
                                bufferBefore: data.scheduling?.bufferBefore || data.buffer_before || 0,
                                bufferAfter: data.scheduling?.bufferAfter || data.buffer_after || 0,
                                minimumNotice: data.scheduling?.minimumNotice || data.minimum_notice_time || 24,
                                dailyLimit: data.scheduling?.dailyLimit || data.daily_meeting_limit || 0,
                                weeklyLimit: data.scheduling?.weeklyLimit || data.weekly_meeting_limit || 0,
                                availableDays: data.scheduling?.availableDays || [
                                    'Monday',
                                    'Tuesday',
                                    'Wednesday',
                                    'Thursday',
                                    'Friday'
                                ],
                                dateRange: data.scheduling?.dateRange || data.date_range_booking || 60,
                                timezone: data.scheduling?.timezone || data.timezone || 'UTC',
                                timeSlots: data.scheduling?.timeSlots || [],
                                startTime: data.scheduling?.startTime || '09:00',
                                endTime: data.scheduling?.endTime || '17:00',
                                recurring: data.scheduling?.recurring || null
                            },
                            teamMembers: data.team_members ? Array.isArray(data.team_members) ? data.team_members : [
                                data.team_members
                            ] : [],
                            owner: data.owner ? {
                                name: data.owner.name,
                                avatar_url: data.owner.avatar_url
                            } : undefined,
                            redirect_url: data.redirect_url
                        };
                        setEventType(mappedEventType);
                    } catch (error) {
                        setError(error instanceof Error ? error.message : 'Failed to fetch event type');
                    }
                }
            }["BookingPage.useEffect.fetchEventType"];
            if (username && eventSlug) {
                fetchEventType();
            }
        }
    }["BookingPage.useEffect"], [
        username,
        eventSlug
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BookingPage.useEffect": ()=>{
            // Fetch available time slots when date is selected
            if (selectedDate && eventType) {
                fetchAvailableSlots(selectedDate);
            }
        }
    }["BookingPage.useEffect"], [
        selectedDate,
        eventType
    ]);
    // Smoothly scroll to the slots section when a date is selected
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BookingPage.useEffect": ()=>{
            if (selectedDate && slotsRef.current) {
                slotsRef.current.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }
    }["BookingPage.useEffect"], [
        selectedDate
    ]);
    // Smoothly scroll to the Next button when a time slot is selected
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BookingPage.useEffect": ()=>{
            if (selectedTime && nextButtonRef.current) {
                nextButtonRef.current.scrollIntoView({
                    behavior: 'smooth',
                    block: 'end'
                });
            }
        }
    }["BookingPage.useEffect"], [
        selectedTime
    ]);
    const fetchAvailableSlots = async (date)=>{
        setIsLoadingSlots(true);
        try {
            console.log('Fetching slots for date:', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(date, 'yyyy-MM-dd'));
            const queryParams = new URLSearchParams({
                date: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(date, 'yyyy-MM-dd'),
                timezone: eventType?.scheduling.timezone || 'UTC',
                duration: eventType?.duration.toString() || '30',
                buffer_before: eventType?.scheduling.bufferBefore.toString() || '0',
                buffer_after: eventType?.scheduling.bufferAfter.toString() || '0'
            });
            const response = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE_URL"]}/event-types/${eventType?.id}/availability?${queryParams.toString()}&_t=${Date.now()}`, {
                cache: 'no-store',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Cache-Control': 'no-cache, no-store, must-revalidate',
                    'Pragma': 'no-cache'
                }
            });
            if (!response.ok) {
                const errorData = await response.json();
                console.error('API Error Response:', errorData);
                throw new Error('Failed to fetch availability');
            }
            const data = await response.json();
            console.log('Available Slots:', data);
            // Ensure slots are in the correct format and filtered for availability
            const formattedSlots = (data.slots || []).map((slot)=>({
                    startTime: slot.startTime,
                    endTime: slot.endTime,
                    available: slot.available !== false,
                    spotsRemaining: slot.spotsRemaining,
                    maxInvitees: slot.maxInvitees
                }));
            setAvailableSlots(formattedSlots);
        } catch (error) {
            console.error('Error fetching availability:', error);
            setAvailableSlots([]);
        } finally{
            setIsLoadingSlots(false);
        }
    };
    const formatTimeSlot = (slot)=>{
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(slot.startTime), 'h:mm a');
    };
    const isCurrentQuestionValid = ()=>{
        const currentQuestion = eventType?.questions[currentQuestionIndex];
        if (!currentQuestion) return false;
        const value = answers[currentQuestion.id];
        // Required check
        if (currentQuestion.required && (!value || Array.isArray(value) && value.length === 0)) {
            return false;
        }
        // Type-specific validation check
        if (value) {
            const validation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$validations$2f$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateQuestionResponse"])(currentQuestion.type, value, currentQuestion.question);
            if (!validation.isValid) return false;
        }
        return true;
    };
    const handleAnswerChange = (questionId, value, type)=>{
        const question = eventType?.questions.find((q)=>q.id === questionId);
        const validation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$validations$2f$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateQuestionResponse"])(type, value, question?.question);
        setAnswers((prev)=>({
                ...prev,
                [questionId]: value
            }));
        setErrors((prev)=>({
                ...prev,
                [questionId]: validation.error || ''
            }));
    };
    const renderQuestion = (question)=>{
        switch(question.type){
            case 'text':
            case 'email':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                    type: question.type,
                    value: answers[question.id] || '',
                    onChange: (e)=>handleAnswerChange(question.id, e.target.value, question.type),
                    placeholder: `Enter your ${question.question.toLowerCase()}`,
                    className: "h-11 sm:h-10 text-[16px] sm:text-[13px] focus-visible:border-[var(--lb-navy)] focus-visible:ring-[var(--lb-navy-border)]",
                    autoFocus: true
                }, void 0, false, {
                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                    lineNumber: 312,
                    columnNumber: 11
                }, this);
            case 'phone':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                    type: "tel",
                    value: answers[question.id] || '',
                    onChange: (e)=>handleAnswerChange(question.id, e.target.value, 'phone'),
                    placeholder: "Enter your phone number",
                    className: "h-11 sm:h-10 text-[16px] sm:text-[13px] focus-visible:border-[var(--lb-navy)] focus-visible:ring-[var(--lb-navy-border)]",
                    autoFocus: true
                }, void 0, false, {
                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                    lineNumber: 324,
                    columnNumber: 11
                }, this);
            case 'textarea':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Textarea"], {
                    value: answers[question.id] || '',
                    onChange: (e)=>handleAnswerChange(question.id, e.target.value, 'text'),
                    placeholder: `Enter your response`,
                    className: "min-h-[100px] text-[16px] sm:text-[13px] focus-visible:border-[var(--lb-navy)] focus-visible:ring-[var(--lb-navy-border)]",
                    autoFocus: true
                }, void 0, false, {
                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                    lineNumber: 336,
                    columnNumber: 11
                }, this);
            case 'select':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                    value: answers[question.id] || '',
                    onValueChange: (value)=>handleAnswerChange(question.id, value, 'select'),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                            className: "h-11 sm:h-10 text-[16px] sm:text-[13px] focus:border-[var(--lb-navy)]",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                placeholder: "Select an option"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                lineNumber: 352,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                            lineNumber: 351,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                            children: question.options.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                    value: option,
                                    children: option
                                }, option, false, {
                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                    lineNumber: 356,
                                    columnNumber: 17
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                            lineNumber: 354,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                    lineNumber: 347,
                    columnNumber: 11
                }, this);
            case 'multiselect':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-2",
                    children: question.options.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center space-x-2 py-1.5 sm:py-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                                    id: `${question.id}-${option}`,
                                    checked: (answers[question.id] || []).includes(option),
                                    onCheckedChange: (checked)=>{
                                        const currentAnswers = answers[question.id] || [];
                                        const newAnswers = checked ? [
                                            ...currentAnswers,
                                            option
                                        ] : currentAnswers.filter((a)=>a !== option);
                                        handleAnswerChange(question.id, newAnswers, 'multiselect');
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                    lineNumber: 369,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: `${question.id}-${option}`,
                                    children: option
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                    lineNumber: 380,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, option, true, {
                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                            lineNumber: 368,
                            columnNumber: 15
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                    lineNumber: 366,
                    columnNumber: 11
                }, this);
            case 'radio':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$radio$2d$group$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RadioGroup"], {
                    value: answers[question.id] || '',
                    onValueChange: (value)=>handleAnswerChange(question.id, value, 'radio'),
                    children: question.options.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center space-x-2 py-1.5 sm:py-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$radio$2d$group$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RadioGroupItem"], {
                                    value: option,
                                    id: `${question.id}-${option}`
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                    lineNumber: 394,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: `${question.id}-${option}`,
                                    children: option
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                    lineNumber: 395,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, option, true, {
                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                            lineNumber: 393,
                            columnNumber: 15
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                    lineNumber: 388,
                    columnNumber: 11
                }, this);
            case 'checkbox':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-2",
                    children: question.options.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center space-x-2 py-1.5 sm:py-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                                    id: `${question.id}-${option}`,
                                    checked: (answers[question.id] || []).includes(option),
                                    onCheckedChange: (checked)=>{
                                        const currentAnswers = answers[question.id] || [];
                                        const newAnswers = checked ? [
                                            ...currentAnswers,
                                            option
                                        ] : currentAnswers.filter((a)=>a !== option);
                                        handleAnswerChange(question.id, newAnswers, 'checkbox');
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                    lineNumber: 406,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                    htmlFor: `${question.id}-${option}`,
                                    children: option
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                    lineNumber: 417,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, option, true, {
                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                            lineNumber: 405,
                            columnNumber: 15
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                    lineNumber: 403,
                    columnNumber: 11
                }, this);
            default:
                return null;
        }
    };
    const handleSubmit = async ()=>{
        // Validate all answers before submitting
        const currentErrors = {};
        let hasErrors = false;
        eventType?.questions?.forEach((question)=>{
            const value = answers[question.id];
            const validation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$validations$2f$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateQuestionResponse"])(question.type, value, question.question);
            if (!validation.isValid) {
                currentErrors[question.id] = validation.error || 'Invalid answer';
                hasErrors = true;
            }
        });
        if (hasErrors) {
            setErrors(currentErrors);
            setIsSubmitting(false);
            return;
        }
        setIsSubmitting(true);
        try {
            const bookingData = {
                eventTypeId: eventType?.id,
                date: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(selectedDate, 'yyyy-MM-dd'),
                time: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(selectedTime), 'HH:mm:ss'),
                duration: eventType?.duration,
                timezone: eventType?.scheduling.timezone || 'UTC',
                answers
            };
            console.log('Submitting booking with data:', bookingData);
            const response = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE_URL"]}/bookings`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(bookingData)
            });
            const data = await response.json();
            if (!response.ok) {
                if (data.message === "This time slot is no longer available" || data.message === "This group slot is already full") {
                    setBookingError(data.message);
                    setStep(1);
                    // Eagerly remove the slot from the UI so it hides instantly
                    setAvailableSlots((prev)=>prev.filter((slot)=>slot.startTime !== selectedTime));
                    setSelectedTime(null);
                    if (selectedDate) {
                        fetchAvailableSlots(selectedDate);
                    }
                    return;
                } else if (response.status === 422) {
                    // Booking limit error or other validation error
                    setBookingError(data.message || "The data provided is invalid.");
                    setStep(1);
                    setSelectedTime(null);
                    return;
                }
                throw new Error(data.message || 'Failed to create booking');
            }
            console.log('Booking Response:', data);
            if (!data.booking) {
                throw new Error('Invalid booking response');
            }
            setBookingDetails(data.booking);
            setShowSuccess(true);
            // Handle Redirection if configured
            if (eventType?.redirect_url && eventType.redirect_url.trim() !== '') {
                setTimeout(()=>{
                    // Double check the value just before redirecting
                    if (eventType.redirect_url) {
                        window.location.href = eventType.redirect_url;
                    }
                }, 2500);
            }
        } catch (err) {
            console.error('Submission error:', err);
            setIsSubmitting(false);
            setBookingError(err instanceof Error ? err.message : 'Failed to create booking');
        } finally{
            setIsSubmitting(false);
        }
    };
    const handleNextQuestion = ()=>{
        if (!eventType?.questions || eventType.questions.length === 0) {
            handleSubmit();
            return;
        }
        const currentQuestion = eventType.questions[currentQuestionIndex];
        // Validate current question
        if (currentQuestion.required && !answers[currentQuestion.id]) {
            setErrors({
                ...errors,
                [currentQuestion.id]: 'This field is required'
            });
            return;
        }
        if (answers[currentQuestion.id]) {
            const validation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$validations$2f$questions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateQuestionResponse"])(currentQuestion.type, answers[currentQuestion.id], currentQuestion.question);
            if (!validation.isValid) {
                setErrors({
                    ...errors,
                    [currentQuestion.id]: validation.error || 'Invalid input'
                });
                return;
            }
        }
        // Clear error if validation passes
        setErrors({
            ...errors,
            [currentQuestion.id]: ''
        });
        // Move to next question or submit if last question
        if (eventType && currentQuestionIndex < eventType.questions.length - 1) {
            setCurrentQuestionIndex(currentQuestionIndex + 1);
        } else {
            handleSubmit();
        }
    };
    const handlePreviousQuestion = ()=>{
        if (currentQuestionIndex > 0) {
            setCurrentQuestionIndex(currentQuestionIndex - 1);
        } else {
            setStep(1) // Go back to calendar view
            ;
        }
    };
    if (error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(isEmbed ? "p-0 bg-transparent w-full" : "min-h-screen flex flex-col items-center justify-center bg-[var(--lb-bg)] py-6 px-4"),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full max-w-md mx-auto text-center space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mx-auto w-16 h-16 bg-red-50 rounded-full flex items-center justify-center text-red-500",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                            className: "w-8 h-8"
                        }, void 0, false, {
                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                            lineNumber: 583,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                        lineNumber: 582,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-bold text-[var(--crm-text-primary)]",
                        children: "Event Not Found"
                    }, void 0, false, {
                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                        lineNumber: 585,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-[var(--crm-text-secondary)]",
                        children: "The event type you are looking for does not exist or has been removed."
                    }, void 0, false, {
                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                        lineNumber: 586,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                lineNumber: 581,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
            lineNumber: 580,
            columnNumber: 7
        }, this);
    }
    if (!eventType) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(isEmbed ? "p-0 bg-transparent w-full" : "min-h-screen flex flex-col items-center justify-center bg-[var(--lb-bg)] py-6 px-4"),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-[820px] mx-auto",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                className: "border-[0.5px] border-[var(--lb-border)] bg-white shadow-sm rounded-[16px] overflow-hidden w-full",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                    className: "p-0 relative overflow-hidden",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid sm:grid-cols-[220px,1fr]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-6 border-r",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col items-center text-center space-y-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-16 h-16 rounded-full bg-muted animate-pulse"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                            lineNumber: 601,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-6 w-32 bg-muted rounded animate-pulse"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                            lineNumber: 602,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-4 w-24 bg-muted rounded animate-pulse"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                            lineNumber: 603,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-20 w-full bg-muted rounded animate-pulse"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                            lineNumber: 604,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                    lineNumber: 600,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                lineNumber: 599,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-6",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CalendarSkeleton, {}, void 0, false, {
                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                    lineNumber: 610,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                lineNumber: 609,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                        lineNumber: 597,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                    lineNumber: 596,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                lineNumber: 595,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
            lineNumber: 594,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
        lineNumber: 593,
        columnNumber: 5
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(isEmbed ? "p-0 bg-transparent w-full" : "min-h-[100dvh] flex flex-col items-center sm:justify-center bg-[var(--lb-s1)] sm:bg-[var(--lb-bg)] sm:py-6 sm:px-4"),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full h-full sm:h-auto max-w-[700px] mx-auto flex flex-col flex-1 sm:flex-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                        className: "border-0 sm:border-[0.5px] border-[var(--lb-border)] bg-[var(--lb-s1)] shadow-none sm:shadow-sm rounded-none sm:rounded-[16px] overflow-hidden w-full flex-1 flex flex-col",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                            className: "p-0 relative flex-1 flex flex-col",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-rows-[auto,1fr] sm:grid-rows-none sm:grid-cols-[220px,1fr] flex-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-4 sm:p-[24px_20px] border-b sm:border-b-0 sm:border-r border-[var(--lb-border)] bg-[var(--lb-s1)] flex flex-row sm:flex-col items-center sm:items-center text-left sm:text-center gap-4 sm:gap-0"),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mb-0 sm:mb-[16px] shrink-0",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Avatar"], {
                                                    className: "w-[48px] h-[48px] sm:w-[64px] sm:h-[64px] rounded-full border-[0.5px] border-[var(--lb-border)] shadow-sm",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AvatarImage"], {
                                                            src: eventType?.owner?.avatar_url || eventType?.teamMembers?.[0]?.avatar,
                                                            className: "object-cover"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 628,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AvatarFallback"], {
                                                            className: "bg-[var(--lb-navy)] text-white font-bold text-lg sm:text-xl rounded-full",
                                                            children: eventType?.owner?.name?.[0]?.toUpperCase() || 'LB'
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 629,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                    lineNumber: 627,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                lineNumber: 626,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col flex-1",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-[15px] font-medium text-[var(--lb-t1)] mb-0.5 sm:mb-1",
                                                        children: eventType?.owner?.name || eventType?.teamMembers?.[0]?.name || 'LeadBajaar'
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                        lineNumber: 635,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "inline-flex items-center gap-1.5 text-[12px] font-medium text-[var(--lb-navy)] bg-[var(--lb-navy-soft)] border-[0.5px] border-[var(--lb-navy-border)] rounded-full px-2.5 py-0.5 mb-1 sm:mb-2 self-start sm:self-center",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                                                                className: "w-3.5 h-3.5"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                lineNumber: 639,
                                                                columnNumber: 19
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: [
                                                                    eventType?.duration,
                                                                    " min"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                lineNumber: 640,
                                                                columnNumber: 19
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                        lineNumber: 638,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-[12px] text-[var(--lb-t3)] leading-relaxed line-clamp-2 sm:line-clamp-none mt-1 sm:mt-0",
                                                        children: eventType?.description || eventType?.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                        lineNumber: 642,
                                                        columnNumber: 17
                                                    }, this),
                                                    selectedDate && selectedTime && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "sm:hidden inline-flex items-center gap-1.5 mt-2 text-[12px] font-medium text-[var(--lb-navy)] bg-[var(--lb-navy-soft)] border-[0.5px] border-[var(--lb-navy-border)] rounded-full px-2.5 py-1 self-start",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                                                className: "w-3 h-3 shrink-0"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                lineNumber: 647,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: [
                                                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(selectedDate, 'EEE, MMM d'),
                                                                    " · ",
                                                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(selectedTime), 'h:mm a')
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                lineNumber: 648,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                        lineNumber: 646,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                lineNumber: 634,
                                                columnNumber: 15
                                            }, this),
                                            selectedDate && selectedTime && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "hidden sm:block mt-4 p-[12px_14px] bg-[var(--lb-s2)] border-[0.5px] border-[var(--lb-border)] rounded-xl w-full",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-[10px] font-semibold tracking-[0.08em] uppercase text-[var(--lb-navy)] mb-2",
                                                        children: "Meeting summary"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                        lineNumber: 656,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "space-y-0",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex justify-between items-center py-1.5 border-b-[0.5px] border-[var(--lb-border)]",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-[11px] text-[var(--lb-t3)]",
                                                                        children: "Date"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 661,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-[11px] font-medium text-[var(--lb-t1)]",
                                                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(selectedDate, 'MMM d, yyyy')
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 662,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                lineNumber: 660,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex justify-between items-center py-1.5 border-b-[0.5px] border-[var(--lb-border)]",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-[11px] text-[var(--lb-t3)]",
                                                                        children: "Time"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 665,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-[11px] font-medium text-[var(--lb-t1)]",
                                                                        children: selectedTime ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(selectedTime), 'h:mm a') : ''
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 666,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                lineNumber: 664,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex justify-between items-center py-1.5 border-b-[0.5px] border-[var(--lb-border)]",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-[11px] text-[var(--lb-t3)]",
                                                                        children: "Duration"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 669,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-[11px] font-medium text-[var(--lb-t1)]",
                                                                        children: [
                                                                            eventType?.duration,
                                                                            " minutes"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 670,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                lineNumber: 668,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                        lineNumber: 659,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                lineNumber: 655,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                        lineNumber: 625,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "p-4 sm:p-6 min-h-0 sm:min-h-[500px] relative flex flex-col w-full max-w-[100vw] sm:max-w-none overflow-x-hidden sm:overflow-x-visible",
                                        children: showSuccess && bookingDetails ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-col py-2 animate-in fade-in slide-in-from-bottom-4 duration-300 w-full",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "w-14 h-14 rounded-full bg-[var(--lb-green-soft)] border-[0.5px] border-[var(--lb-green-border)] flex items-center justify-center mx-auto mb-3.5",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__["CheckCircle2"], {
                                                        className: "w-[26px] h-[26px] text-[var(--lb-green)]"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                        lineNumber: 682,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                    lineNumber: 681,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                    className: "text-[20px] font-medium text-center mb-1.5 text-[var(--lb-t1)]",
                                                    children: "Booking confirmed!"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                    lineNumber: 684,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-[13px] text-[var(--lb-t2)] text-center mb-5",
                                                    children: "Your meeting has been scheduled and confirmed."
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                    lineNumber: 687,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "bg-[var(--lb-s2)] border-[0.5px] border-[var(--lb-border)] rounded-xl overflow-hidden mb-3 w-full max-w-md mx-auto",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-[10px] font-semibold tracking-[0.10em] uppercase text-[var(--lb-navy)] px-3.5 py-2.5 border-b-[0.5px] border-[var(--lb-border)]",
                                                            children: "Meeting Details"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 692,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex justify-between items-center px-3.5 py-[9px] border-b-[0.5px] border-[var(--lb-border)]",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-[12px] text-[var(--lb-t3)]",
                                                                    children: "Date"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                    lineNumber: 696,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-[12px] font-medium text-[var(--lb-t1)]",
                                                                    children: selectedDate ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(selectedDate, 'EEEE, MMMM d, yyyy') : bookingDetails?.start_time ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(bookingDetails.start_time), 'EEEE, MMMM d, yyyy') : ''
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                    lineNumber: 697,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 695,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex justify-between items-center px-3.5 py-[9px] border-b-[0.5px] border-[var(--lb-border)]",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-[12px] text-[var(--lb-t3)]",
                                                                    children: "Time"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                    lineNumber: 706,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-[12px] font-medium text-[var(--lb-t1)]",
                                                                    children: selectedTime ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(selectedTime), 'h:mm a') : bookingDetails?.start_time ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(bookingDetails.start_time), 'h:mm a') : ''
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                    lineNumber: 707,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 705,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex justify-between items-center px-3.5 py-[9px]",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-[12px] text-[var(--lb-t3)]",
                                                                    children: "Duration"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                    lineNumber: 713,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-[12px] font-medium text-[var(--lb-t1)]",
                                                                    children: [
                                                                        eventType?.duration,
                                                                        " minutes"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                    lineNumber: 714,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 712,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                    lineNumber: 691,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2 bg-[var(--lb-green-soft)] border-[0.5px] border-[var(--lb-green-border)] rounded-xl px-3.5 py-2.5 text-[12px] text-[var(--lb-green)] mb-3.5 w-full max-w-md mx-auto",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                                            className: "w-[15px] h-[15px] flex-shrink-0"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 719,
                                                            columnNumber: 21
                                                        }, this),
                                                        "A calendar invite has been sent to your email"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                    lineNumber: 718,
                                                    columnNumber: 19
                                                }, this),
                                                eventType?.redirect_url && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-muted-foreground animate-pulse mt-2",
                                                    children: "Redirecting you in a few seconds..."
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                    lineNumber: 724,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>{
                                                        setShowSuccess(false);
                                                        setBookingDetails(null);
                                                        // Handle Redirection if configured
                                                        if (eventType?.redirect_url) {
                                                            window.location.href = eventType.redirect_url;
                                                        } else {
                                                            // Reset everything back to step 1
                                                            setAnswers({});
                                                            setSelectedDate(undefined);
                                                            setSelectedTime(null);
                                                            setStep(1);
                                                            setCurrentQuestionIndex(0);
                                                        }
                                                    },
                                                    className: "w-full max-w-md mx-auto bg-[var(--lb-navy)] text-white border-none rounded-full p-[13px] text-[14px] font-medium cursor-pointer tracking-[0.04em] uppercase hover:opacity-90 transition-opacity shadow-sm",
                                                    children: "Done"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                    lineNumber: 729,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                            lineNumber: 680,
                                            columnNumber: 17
                                        }, this) : step === 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-start sm:items-center justify-between gap-2 mb-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "text-[16px] font-medium text-[var(--lb-t1)]",
                                                            children: selectedDate ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                children: [
                                                                    "Available times",
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "block sm:inline text-[13px] font-medium text-[var(--lb-navy)] ml-0 sm:ml-1.5 mt-0.5 sm:mt-0",
                                                                        children: [
                                                                            "— ",
                                                                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(selectedDate, 'EEEE, MMMM d')
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 757,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true) : 'Select date & time'
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 753,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-[5px] text-[11px] text-[var(--lb-t2)] bg-[var(--lb-s2)] border-[0.5px] border-[var(--lb-border)] rounded-full px-2.5 py-1 whitespace-nowrap shrink-0",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Globe$3e$__["Globe"], {
                                                                    className: "h-[13px] w-[13px]"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                    lineNumber: 766,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: eventType.scheduling.timezone
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                    lineNumber: 767,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 765,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                    lineNumber: 752,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex flex-col flex-1",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "p-0 rounded-lg flex-grow flex flex-col",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("transition-all duration-300", selectedDate ? "opacity-0 -translate-y-2 pointer-events-none h-0 overflow-hidden" : "opacity-100 translate-y-0 flex-1 sm:flex-none flex flex-col justify-center sm:justify-start"),
                                                                "aria-hidden": !!selectedDate,
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$custom$2d$calendar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CustomCalendar"], {
                                                                        selectedDate: selectedDate,
                                                                        onDateSelect: setSelectedDate,
                                                                        minDate: new Date(),
                                                                        maxDate: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$addDays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addDays"])(new Date(), eventType.scheduling.dateRange),
                                                                        className: "w-full",
                                                                        isDateAvailable: (date)=>isDateAvailable(date, eventType)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 782,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    !selectedDate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "pt-6 text-center text-sm text-[var(--crm-text-secondary)]",
                                                                        children: "Select a date to view available times"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 791,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                lineNumber: 775,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                ref: slotsRef,
                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("transition-all duration-300", selectedDate ? "opacity-100 translate-y-0 flex-1 flex flex-col sm:flex-none sm:block" : "opacity-0 translate-y-2 pointer-events-none h-0 overflow-hidden"),
                                                                "aria-hidden": !selectedDate,
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex items-center justify-between mb-3.5 mt-[-8px]",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                onClick: ()=>{
                                                                                    setSelectedTime(null);
                                                                                    setSelectedDate(undefined);
                                                                                },
                                                                                className: "inline-flex items-center gap-[6px] bg-[var(--lb-s2)] border-[0.5px] border-[var(--lb-border)] rounded-full px-3.5 py-[7px] text-[12px] text-[var(--lb-t2)] hover:bg-[var(--lb-s3)] transition-colors cursor-pointer",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                                                                        className: "h-[13px] w-[13px]"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                                        lineNumber: 814,
                                                                                        columnNumber: 29
                                                                                    }, this),
                                                                                    " Change date"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                                lineNumber: 807,
                                                                                columnNumber: 27
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "flex items-center gap-2",
                                                                                children: availableSlots.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: "text-[11px] font-medium text-[var(--lb-navy)] bg-[var(--lb-navy-soft)] rounded-full px-2.5 py-0.5",
                                                                                    children: [
                                                                                        availableSlots.length,
                                                                                        " slots available"
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                                    lineNumber: 818,
                                                                                    columnNumber: 31
                                                                                }, this)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                                lineNumber: 816,
                                                                                columnNumber: 27
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 806,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    isLoadingSlots ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "grid grid-cols-3 gap-2",
                                                                        children: [
                                                                            ...Array(6)
                                                                        ].map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "h-10 bg-muted/50 rounded animate-pulse"
                                                                            }, i, false, {
                                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                                lineNumber: 828,
                                                                                columnNumber: 31
                                                                            }, this))
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 826,
                                                                        columnNumber: 27
                                                                    }, this) : availableSlots.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "grid grid-cols-3 gap-2",
                                                                        children: availableSlots.map((slot)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("w-full min-h-[44px] transition-all duration-200 border-[0.5px] rounded-full font-medium text-[14px] sm:text-[13px] p-[12px] sm:p-[10px] flex flex-col items-center justify-center gap-0.5", !slot.available && "opacity-50 cursor-not-allowed bg-[var(--lb-s2)] border-[var(--lb-border)] text-[var(--lb-t3)]", selectedTime !== slot.startTime && slot.available && "bg-[var(--lb-s2)] border-[var(--lb-border)] text-[var(--lb-t1)] hover:border-[var(--lb-navy)]", selectedTime === slot.startTime && "bg-[var(--lb-navy)] text-white border-[var(--lb-navy)]"),
                                                                                onClick: ()=>slot.available && setSelectedTime(slot.startTime),
                                                                                disabled: !slot.available,
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(slot.startTime), 'h:mm a')
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                                        lineNumber: 845,
                                                                                        columnNumber: 33
                                                                                    }, this),
                                                                                    slot.maxInvitees && slot.maxInvitees > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-[9px] font-bold uppercase tracking-widest", selectedTime === slot.startTime ? "text-white/80" : "text-emerald-600 dark:text-emerald-400"),
                                                                                        children: [
                                                                                            slot.spotsRemaining,
                                                                                            " spot",
                                                                                            slot.spotsRemaining !== 1 ? 's' : '',
                                                                                            " left"
                                                                                        ]
                                                                                    }, void 0, true, {
                                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                                        lineNumber: 847,
                                                                                        columnNumber: 35
                                                                                    }, this)
                                                                                ]
                                                                            }, slot.startTime, true, {
                                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                                lineNumber: 834,
                                                                                columnNumber: 31
                                                                            }, this))
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 832,
                                                                        columnNumber: 27
                                                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "py-8 text-center",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                            className: "text-[var(--lb-t2)] text-[13px]",
                                                                            children: "No available slots for this date"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                            lineNumber: 856,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 855,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    selectedDate && selectedTime && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "mt-auto pt-4 -mx-4 px-4 pb-3 sticky bottom-0 bg-gradient-to-t from-[var(--lb-s1)] via-[var(--lb-s1)] to-transparent sm:static sm:mt-4 sm:pt-0 sm:mx-0 sm:px-0 sm:pb-0 sm:bg-none",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            ref: nextButtonRef,
                                                                            className: "w-full bg-[var(--lb-navy)] text-white border-none rounded-full p-[13px] text-[14px] font-medium cursor-pointer hover:opacity-90 transition-opacity shadow-sm",
                                                                            onClick: ()=>setStep(2),
                                                                            children: "Next →"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                            lineNumber: 863,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 862,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                lineNumber: 798,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                        lineNumber: 773,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                    lineNumber: 771,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center justify-between pb-3.5 border-b-[0.5px] border-[var(--lb-border)] mb-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: handlePreviousQuestion,
                                                            className: "flex items-center gap-[5px] bg-transparent border-none text-[13px] text-[var(--lb-t2)] cursor-pointer hover:text-[var(--lb-t1)] transition-colors",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                                                    className: "w-[14px] h-[14px]"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                    lineNumber: 880,
                                                                    columnNumber: 23
                                                                }, this),
                                                                " Back"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 879,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-[15px] font-medium text-[var(--lb-t1)]",
                                                            children: "Enter your details"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 882,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-10"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 883,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                    lineNumber: 878,
                                                    columnNumber: 19
                                                }, this),
                                                eventType?.questions && eventType.questions.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "mb-6 flex flex-col items-center w-full",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center justify-center mb-2 w-full px-1 py-1",
                                                                    children: eventType.questions.map((_, index)=>{
                                                                        const isCompleted = index < currentQuestionIndex;
                                                                        const isCurrent = index === currentQuestionIndex;
                                                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center justify-center w-6 h-6 sm:w-7 sm:h-7 rounded-full text-[10px] sm:text-[12px] font-medium transition-all duration-300 shrink-0", isCompleted ? "bg-[var(--lb-green)] text-white border border-[var(--lb-green)]" : isCurrent ? "bg-[var(--lb-navy)] text-white border border-[var(--lb-navy)] shadow-sm" : "bg-[var(--lb-s2)] text-[var(--lb-t3)] border border-[var(--lb-border)]"),
                                                                                    children: isCompleted ? "✓" : index + 1
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                                    lineNumber: 896,
                                                                                    columnNumber: 33
                                                                                }, this),
                                                                                index < eventType.questions.length - 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex-1 h-[2px] mx-0.5 sm:mx-1.5 rounded-full transition-colors duration-300 min-w-[2px] max-w-[24px] sm:max-w-[32px]", isCompleted ? "bg-[var(--lb-green)]" : "bg-[var(--lb-s3)]")
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                                    lineNumber: 909,
                                                                                    columnNumber: 35
                                                                                }, this)
                                                                            ]
                                                                        }, index, true, {
                                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                            lineNumber: 895,
                                                                            columnNumber: 31
                                                                        }, this);
                                                                    })
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                    lineNumber: 890,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "text-[11px] text-[var(--lb-t3)]",
                                                                    children: [
                                                                        "Question ",
                                                                        currentQuestionIndex + 1,
                                                                        " of ",
                                                                        eventType.questions.length
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                    lineNumber: 920,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 889,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "space-y-6",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "space-y-1.5 min-h-[120px] sm:min-h-[200px]",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "text-[11px] font-semibold tracking-[0.08em] uppercase text-[var(--lb-navy)] flex items-center gap-1",
                                                                        children: [
                                                                            eventType.questions[currentQuestionIndex].question,
                                                                            eventType.questions[currentQuestionIndex].required && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-[var(--lb-red)] text-[12px]",
                                                                                children: "*"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                                lineNumber: 934,
                                                                                columnNumber: 27
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 931,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    eventType.questions[currentQuestionIndex].description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "text-[11px] text-[var(--lb-t3)]",
                                                                        children: eventType.questions[currentQuestionIndex].description
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 938,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    renderQuestion(eventType.questions[currentQuestionIndex]),
                                                                    errors[eventType.questions[currentQuestionIndex].id] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "text-sm text-destructive",
                                                                        children: errors[eventType.questions[currentQuestionIndex].id]
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 946,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                ]
                                                            }, eventType.questions[currentQuestionIndex].id, true, {
                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                lineNumber: 927,
                                                                columnNumber: 21
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 926,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "py-12 text-center border rounded-xl bg-[var(--lb-s2)] border-[var(--lb-border)]",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-[var(--lb-t2)] text-[13px] font-medium",
                                                            children: "No additional details required."
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 955,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-[12px] text-[var(--lb-t3)] mt-2",
                                                            children: "Click Schedule below to confirm your booking."
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 956,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                    lineNumber: 954,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex flex-col-reverse sm:flex-row justify-between gap-3 mt-auto pt-6 sm:mt-6 sm:pt-0",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: handlePreviousQuestion,
                                                            className: "w-full sm:w-auto bg-[var(--lb-s2)] text-[var(--lb-t1)] border-[0.5px] border-[var(--lb-border)] rounded-full px-5 py-3 sm:py-2.5 text-[13px] font-medium cursor-pointer hover:bg-[var(--lb-s3)] transition-colors",
                                                            children: "Previous"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 961,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: currentQuestionIndex === eventType.questions.length - 1 ? handleSubmit : handleNextQuestion,
                                                            className: "w-full sm:w-auto bg-[var(--lb-navy)] text-white border-none rounded-full px-7 py-3 sm:py-2.5 text-[14px] sm:text-[13px] font-medium cursor-pointer hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center shadow-sm",
                                                            disabled: isSubmitting || !isCurrentQuestionValid(),
                                                            children: isSubmitting ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "animate-spin mr-2",
                                                                        children: "⏳"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                        lineNumber: 974,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    "Scheduling..."
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                                lineNumber: 973,
                                                                columnNumber: 27
                                                            }, this) : !eventType?.questions?.length || currentQuestionIndex === eventType.questions.length - 1 ? 'Schedule' : 'Next →'
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                            lineNumber: 967,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                                    lineNumber: 960,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                        lineNumber: 678,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                lineNumber: 624,
                                columnNumber: 11
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                            lineNumber: 623,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                        lineNumber: 622,
                        columnNumber: 9
                    }, this),
                    !isEmbed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "py-3 sm:py-0 sm:mt-4 text-center flex items-center justify-center text-[var(--lb-t3)] text-[11px] font-medium space-x-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Zap$3e$__["Zap"], {
                                className: "h-3 w-3"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                lineNumber: 991,
                                columnNumber: 12
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Powered by LeadBajaar"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                lineNumber: 992,
                                columnNumber: 12
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                        lineNumber: 990,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                lineNumber: 621,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
                open: !!bookingError,
                onOpenChange: (open)=>!open && setBookingError(null),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogContent"], {
                    className: "sm:max-w-md rounded-2xl p-6 bg-white dark:bg-slate-900 shadow-2xl border-none",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col items-center justify-center text-center space-y-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-12 w-12 bg-red-100 dark:bg-red-900/40 rounded-full flex items-center justify-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                                    className: "h-6 w-6 text-red-600 dark:text-red-400"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                    lineNumber: 1000,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                lineNumber: 999,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTitle"], {
                                        className: "text-lg font-bold text-slate-900 dark:text-white mb-2",
                                        children: "Booking Issue"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                        lineNumber: 1003,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogDescription"], {
                                        className: "text-sm font-medium text-slate-500 dark:text-slate-400",
                                        children: bookingError
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                        lineNumber: 1006,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                lineNumber: 1002,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>setBookingError(null),
                                className: "w-full bg-[var(--lb-navy)] hover:opacity-90 text-white rounded-xl h-11 font-medium mt-2",
                                children: "Understood"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                                lineNumber: 1010,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                        lineNumber: 998,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                    lineNumber: 997,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
                lineNumber: 996,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[username]/[eventSlug]/page.tsx",
        lineNumber: 620,
        columnNumber: 5
    }, this);
}
_s(BookingPage, "UbM+Hg+9mIfR9PtycthalC09JdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c1 = BookingPage;
var _c, _c1;
__turbopack_refresh__.register(_c, "CalendarSkeleton");
__turbopack_refresh__.register(_c1, "BookingPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/[username]/[eventSlug]/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),
}]);

//# sourceMappingURL=src_44431c._.js.map