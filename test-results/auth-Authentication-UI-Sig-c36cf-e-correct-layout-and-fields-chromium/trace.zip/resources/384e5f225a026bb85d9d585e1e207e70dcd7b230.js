(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_ad4d3c._.js", {

"[project]/src/components/ui/input.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Input": (()=>Input)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Input = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, type, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        type: type,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex h-10 w-full rounded-[var(--r-md)] border border-[var(--crm-border)] bg-[var(--crm-surface-2)] px-3 py-2 text-[13px] text-[var(--crm-text-primary)] shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-[var(--crm-text-primary)] placeholder:text-[var(--crm-text-tertiary)] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-indigo-500/50 focus-visible:border-primary/50 disabled:cursor-not-allowed disabled:opacity-50", className),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/input.tsx",
        lineNumber: 8,
        columnNumber: 7
    }, this);
});
_c1 = Input;
Input.displayName = "Input";
;
var _c, _c1;
__turbopack_refresh__.register(_c, "Input$React.forwardRef");
__turbopack_refresh__.register(_c1, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/label.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Label": (()=>Label)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@radix-ui/react-label/dist/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const labelVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
const Label = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(labelVariants(), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/label.tsx",
        lineNumber: 18,
        columnNumber: 3
    }, this));
_c1 = Label;
Label.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root.displayName;
;
var _c, _c1;
__turbopack_refresh__.register(_c, "Label$React.forwardRef");
__turbopack_refresh__.register(_c1, "Label");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/card.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Card": (()=>Card),
    "CardContent": (()=>CardContent),
    "CardDescription": (()=>CardDescription),
    "CardFooter": (()=>CardFooter),
    "CardHeader": (()=>CardHeader),
    "CardTitle": (()=>CardTitle)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Card = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded-[var(--r-lg)] border border-[var(--crm-border)] bg-[var(--crm-surface-1)] text-[var(--crm-text-primary)] overflow-hidden", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 9,
        columnNumber: 3
    }, this));
_c1 = Card;
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c2 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col space-y-1.5 p-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 24,
        columnNumber: 3
    }, this));
_c3 = CardHeader;
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c4 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("font-semibold leading-none tracking-tight", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 36,
        columnNumber: 3
    }, this));
_c5 = CardTitle;
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c6 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-sm text-[var(--crm-text-secondary)]", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 48,
        columnNumber: 3
    }, this));
_c7 = CardDescription;
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c8 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 60,
        columnNumber: 3
    }, this));
_c9 = CardContent;
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c10 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 68,
        columnNumber: 3
    }, this));
_c11 = CardFooter;
CardFooter.displayName = "CardFooter";
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_refresh__.register(_c, "Card$React.forwardRef");
__turbopack_refresh__.register(_c1, "Card");
__turbopack_refresh__.register(_c2, "CardHeader$React.forwardRef");
__turbopack_refresh__.register(_c3, "CardHeader");
__turbopack_refresh__.register(_c4, "CardTitle$React.forwardRef");
__turbopack_refresh__.register(_c5, "CardTitle");
__turbopack_refresh__.register(_c6, "CardDescription$React.forwardRef");
__turbopack_refresh__.register(_c7, "CardDescription");
__turbopack_refresh__.register(_c8, "CardContent$React.forwardRef");
__turbopack_refresh__.register(_c9, "CardContent");
__turbopack_refresh__.register(_c10, "CardFooter$React.forwardRef");
__turbopack_refresh__.register(_c11, "CardFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/lib/auth.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "authOptions": (()=>authOptions),
    "clearSession": (()=>clearSession),
    "default": (()=>__TURBOPACK__default__export__),
    "getSession": (()=>getSession),
    "setSession": (()=>setSession)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next-auth/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$google$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next-auth/providers/google.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
;
;
const getSession = async ()=>{
    if ("TURBOPACK compile-time falsy", 0) {
        "TURBOPACK unreachable";
    }
    const token = localStorage.getItem('token');
    return token ? {
        token
    } : null;
};
const setSession = (token)=>{
    localStorage.setItem('token', token);
};
const clearSession = ()=>{
    localStorage.removeItem('token');
    localStorage.removeItem('rememberedCredentials'); // Also clear remembered credentials
};
const authOptions = {
    providers: [
        // Only add Google provider if credentials are available
        ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.GOOGLE_CLIENT_ID && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.GOOGLE_CLIENT_SECRET ? [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$google$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                clientId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.GOOGLE_CLIENT_ID,
                clientSecret: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.GOOGLE_CLIENT_SECRET
            })
        ] : []
    ],
    callbacks: {
        async jwt ({ token, account }) {
            if (account) {
                token.accessToken = account.access_token;
            }
            return token;
        },
        async session ({ session, token }) {
            if (token.accessToken) {
                session.accessToken = token.accessToken;
            }
            return session;
        }
    },
    pages: {
        signIn: '/signin',
        error: '/signin'
    },
    secret: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXTAUTH_SECRET
};
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(authOptions);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/errorParser.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "parseError": (()=>parseError)
});
function sanitizeMessage(msg) {
    if (!msg) return msg;
    if (msg.includes('SQLSTATE') || msg.includes('SQL:') || msg.includes('Connection: mysql')) {
        return "A database error occurred while processing your request. Please try again later.";
    }
    return msg;
}
function parseError(error) {
    if (error?.response) {
        const data = error.response.data;
        // Handle Laravel validation errors (422)
        if (error.response.status === 422 && data.errors) {
            const messages = Object.entries(data.errors).map(([field, errors])=>`${field}: ${errors.join(', ')}`).join('\n');
            return {
                message: messages || data.message || 'Validation failed',
                status: 422,
                errors: data.errors,
                raw: error
            };
        }
        const rawMessage = data?.message || mapStatus(error.response.status);
        return {
            message: sanitizeMessage(rawMessage),
            status: error.response.status,
            raw: error
        };
    }
    // Handle Axios Network Errors
    if (error?.message === 'Network Error') {
        return {
            message: "Cannot connect to server. Please check your internet connection.",
            raw: error
        };
    }
    if (error?.message) {
        const rawMsg = error.message === 'API Error' ? 'Something went wrong' : error.message;
        return {
            message: sanitizeMessage(rawMsg),
            raw: error
        };
    }
    return {
        message: "Something went wrong. Please try again.",
        raw: error
    };
}
function mapStatus(status) {
    switch(status){
        case 400:
            return "Invalid request";
        case 401:
            return "Session expired. Login again";
        case 403:
            return "Permission denied";
        case 404:
            return "Not found";
        case 500:
            return "Server error. Try later";
        default:
            return "Unexpected error";
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/logger.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "logger": (()=>logger)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/errorParser.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
;
;
;
const isDev = ("TURBOPACK compile-time value", "development") === "development";
const logger = {
    error: (message, error, options)=>{
        // Only log to console in dev if it's NOT a handled validation error or a network error
        const isHandled = error?.status === 422 || error?.status === 401;
        const isNetworkError = error?.message === 'Network Error' || error && !error.status && error.message?.includes('connect');
        if (isDev && !isHandled && !isNetworkError && !options?.hideConsole) {
            console.error(`[LEADBAJAAR ERR] ${message}`, error);
        }
        // Dispatch global error event for the UI to catch (if not handled and not silenced)
        if (!isHandled && !options?.silent && "object" !== 'undefined') {
            const parsed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseError"])(error);
            const errorDetail = parsed.message;
            // If it's a network error or a 500 server error, show the high-visibility Modal
            if (errorDetail.includes('connect to server') || parsed.status && parsed.status >= 500) {
                const event = new CustomEvent('app-global-error', {
                    detail: {
                        title: message,
                        message: errorDetail
                    }
                });
                window.dispatchEvent(event);
            } else {
                // For other unhandled errors, show a Toast
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(message, {
                    description: errorDetail
                });
            }
        }
        // Attempt to send to server ONLY if it's not a network error 
        // (no point trying to log to a server that is unreachable)
        if (!isNetworkError) {
            sendToServer(message, error);
        }
    },
    info: (message, data)=>{
        if ("TURBOPACK compile-time truthy", 1) {
            console.log(`[LEADBAJAAR INFO] ${message}`, data);
        }
    },
    warn: (message, data)=>{
        if ("TURBOPACK compile-time truthy", 1) {
            console.warn(`[LEADBAJAAR WARN] ${message}`, data);
        }
    }
};
async function sendToServer(message, error) {
    try {
        // Only attempt if we have an error to log
        const payload = {
            message,
            error: serialize(error),
            url: ("TURBOPACK compile-time truthy", 1) ? window.location.href : ("TURBOPACK unreachable", undefined),
            userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown',
            time: new Date().toISOString()
        };
        // Use our global API base URL for logging
        await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE_URL"]}/errors/log`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        });
    } catch (err) {
    // Fail silently in production
    }
}
function serialize(error) {
    if (!error) return null;
    return {
        message: error.message,
        stack: error.stack,
        status: error.response?.status || error.status,
        data: error.response?.data || error.data
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/lib/api.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "API_BASE_URL": (()=>API_BASE_URL),
    "WHATSAPP_BASE_URL": (()=>WHATSAPP_BASE_URL),
    "adminApi": (()=>adminApi),
    "agencyApi": (()=>agencyApi),
    "api": (()=>api),
    "authorize": (()=>authorize),
    "bulkDeleteLeads": (()=>bulkDeleteLeads),
    "bulkUpdateLeadStage": (()=>bulkUpdateLeadStage),
    "bulkUpdateLeadStatus": (()=>bulkUpdateLeadStatus),
    "companyApi": (()=>companyApi),
    "createLead": (()=>createLead),
    "createPayment": (()=>createPayment),
    "createStage": (()=>createStage),
    "default": (()=>__TURBOPACK__default__export__),
    "deleteBooking": (()=>deleteBooking),
    "deleteLead": (()=>deleteLead),
    "deleteStage": (()=>deleteStage),
    "evolutionApi": (()=>evolutionApi),
    "exportLeads": (()=>exportLeads),
    "financeApi": (()=>financeApi),
    "forgotPassword": (()=>forgotPassword),
    "getAnalyticsData": (()=>getAnalyticsData),
    "getBookings": (()=>getBookings),
    "getConversationMessages": (()=>getConversationMessages),
    "getDashboardStats": (()=>getDashboardStats),
    "getLead": (()=>getLead),
    "getLeads": (()=>getLeads),
    "getLeadsWithLatestMessages": (()=>getLeadsWithLatestMessages),
    "getMessages": (()=>getMessages),
    "getStages": (()=>getStages),
    "getUser": (()=>getUser),
    "googleIntegrationApi": (()=>googleIntegrationApi),
    "httpClient": (()=>httpClient),
    "importLeads": (()=>importLeads),
    "initializeChat": (()=>initializeChat),
    "integrationApi": (()=>integrationApi),
    "login": (()=>login),
    "loginWithGoogle": (()=>loginWithGoogle),
    "logout": (()=>logout),
    "me": (()=>me),
    "register": (()=>register),
    "reorderStages": (()=>reorderStages),
    "rescheduleBooking": (()=>rescheduleBooking),
    "resetPassword": (()=>resetPassword),
    "sendMessage": (()=>sendMessage),
    "submitTesterRequest": (()=>submitTesterRequest),
    "subscriptionApi": (()=>subscriptionApi),
    "syncDefaultStages": (()=>syncDefaultStages),
    "teamApi": (()=>teamApi),
    "updateBooking": (()=>updateBooking),
    "updateLead": (()=>updateLead),
    "updateLeadDetails": (()=>updateLeadDetails),
    "updateLeadStage": (()=>updateLeadStage),
    "updateStage": (()=>updateStage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/auth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/errorParser.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/utils/logger.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
;
;
;
const API_BASE_URL = 'http://localhost:8000/api';
const WHATSAPP_BASE_URL = 'https://wp.leadbajaar.com/api';
const httpClient = {
    async get (url) {
        const response = await fetch(`${API_BASE_URL}${url}`);
        if (!response.ok) throw new Error('API Error');
        return response.json();
    },
    async post (url, data) {
        const response = await fetch(`${API_BASE_URL}${url}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        if (!response.ok) throw new Error('API Error');
        return response.json();
    },
    async put (url, data) {
        const response = await fetch(`${API_BASE_URL}${url}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        if (!response.ok) throw new Error('API Error');
        return response.json();
    },
    async delete (url) {
        const response = await fetch(`${API_BASE_URL}${url}`, {
            method: 'DELETE'
        });
        if (!response.ok) throw new Error('API Error');
        return response.json();
    }
};
const api = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
    withCredentials: true
});
// Add request interceptor to include token in headers
api.interceptors.request.use(async (config)=>{
    const token = localStorage.getItem('token') // or get from your auth system
    ;
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});
// Add response interceptor to handle errors globally
api.interceptors.response.use((response)=>response, (error)=>{
    const parsedError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorParser$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseError"])(error);
    // Only log to console/logger if it's a server error or unexpected crash
    // 422 (Validation), 401 (Auth), and 402 (Payment) are handled by the UI
    if (!parsedError.status || parsedError.status >= 500) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error("API Error", error, {
            hideConsole: true
        });
    }
    // Global session handling (401)
    if (parsedError.status === 401) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSession"])();
        if ("TURBOPACK compile-time truthy", 1) {
            const currentPath = window.location.pathname;
            if (currentPath !== '/signin' && currentPath !== '/signup') {
                window.location.href = '/signin';
            }
        }
    }
    // Subscription Expired (402)
    if (parsedError.status === 402) {
        // The SubscriptionGuard will handle the UI overlay, 
        // but we can also trigger a toast or log here
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].warn("Subscription Expired", parsedError);
    }
    return Promise.reject(parsedError);
});
const login = async (email, password)=>{
    try {
        const response = await api.post('/login', {
            email,
            password
        });
        // Store the actual token from the response
        const token = response.data.token || response.data.access_token;
        if (!token) {
            throw new Error('No token received from server');
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setSession"])(token);
        return response.data;
    } catch (error) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isAxiosError(error)) {
            const axiosError = error;
            // Don't log the error to console for expected errors like invalid credentials
            if (axiosError.response?.status === 422) {
                throw new Error(axiosError.response.data.message || 'Invalid credentials');
            }
            if (axiosError.response?.data?.message) {
                throw new Error(axiosError.response.data.message);
            }
        }
        // Only log unexpected errors
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Login Failed', error);
        throw error;
    }
};
const register = async (name, email, password, password_confirmation, phone)=>{
    try {
        const response = await api.post('/register', {
            name,
            email,
            password,
            password_confirmation,
            phone
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setSession"])('your_auth_token');
        return response.data;
    } catch (error) {
        throw error;
    }
};
const forgotPassword = async (email)=>{
    try {
        const response = await api.post('/forgot-password', {
            email
        });
        return response.data;
    } catch (error) {
        const message = error.response?.data?.message || error.message || 'Failed to send reset link';
        throw new Error(message);
    }
};
const resetPassword = async (token, email, password, password_confirmation)=>{
    try {
        const response = await api.post('/reset-password', {
            token,
            email,
            password,
            password_confirmation
        });
        return response.data;
    } catch (error) {
        const message = error.response?.data?.message || error.message || 'Failed to reset password';
        throw new Error(message);
    }
};
const logout = async ()=>{
    try {
        const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSession"])();
        if (!session?.token) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSession"])();
            return true;
        }
        await api.post('/logout', {}, {
            headers: {
                Authorization: `Bearer ${session.token}`
            }
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSession"])();
        return true;
    } catch (error) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clearSession"])(); // Clear session even if logout fails
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isAxiosError(error)) {
            const axiosError = error;
            if (axiosError.response?.data?.message) {
                throw new Error(axiosError.response.data.message);
            }
        }
        throw new Error('Logout failed');
    }
};
const getUser = async ()=>{
    const response = await api.get('/user');
    return response.data;
};
const submitTesterRequest = async (data)=>{
    const response = await api.post('/tester-requests', data);
    return response.data;
};
const loginWithGoogle = async (token)=>{
    const response = await api.post('/login/google', {
        token
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setSession"])(token);
    return response.data;
};
const createLead = async (data)=>{
    const response = await api.post('/leads', {
        ...data,
        stage: data.stage || 'New'
    });
    return response.data;
};
const importLeads = async (data)=>{
    const response = await api.post('/leads/import', data);
    return response.data;
};
const getLeads = async (params)=>{
    try {
        const response = await api.get('/leads', {
            params
        });
        // If the response is already in the correct format, return it
        if (response.data?.data && Array.isArray(response.data.data)) {
            return response.data;
        }
        // If we get an array directly, wrap it in the expected format
        if (Array.isArray(response.data)) {
            return {
                data: response.data,
                meta: {
                    current_page: params.page || 1,
                    from: 1,
                    last_page: 1,
                    per_page: response.data.length,
                    to: response.data.length,
                    total: response.data.length
                }
            };
        }
        // Return the response data as is
        return response.data;
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Error fetching leads', error);
        throw error;
    }
};
const getLead = async (id)=>{
    const response = await api.get(`/leads/${id}`);
    return response.data;
};
const deleteLead = async (id)=>{
    await api.delete(`/leads/${id}`);
};
const bulkDeleteLeads = async (ids)=>{
    await api.post('/leads/bulk-destroy', {
        ids
    });
};
const bulkUpdateLeadStatus = async (ids, status)=>{
    await api.post('/leads/bulk-update-status', {
        ids,
        status
    });
};
const bulkUpdateLeadStage = async (ids, stage)=>{
    await api.post('/leads/bulk-update-stage', {
        ids,
        stage
    });
};
const updateLead = async (id, data)=>{
    const response = await api.put(`/leads/${id}`, data);
    return response.data;
};
const updateLeadStage = async (id, stage, deal_value)=>{
    const response = await api.patch(`/leads/${id}/stage`, {
        stage,
        deal_value
    });
    return response.data;
};
const getStages = async ()=>{
    const response = await api.get('/stages');
    return response.data;
};
const createStage = async (data)=>{
    const response = await api.post('/stages', data);
    return response.data;
};
const updateStage = async (id, data)=>{
    const response = await api.put(`/stages/${id}`, data);
    return response.data;
};
const deleteStage = async (id)=>{
    await api.delete(`/stages/${id}`);
};
const reorderStages = async (stages)=>{
    await api.post('/stages/reorder', {
        stages
    });
};
const syncDefaultStages = async ()=>{
    await api.post('/stages/initialize-default');
};
const createPayment = async (data)=>{
    const response = await api.post('/payments', data);
    return response.data;
};
const updateLeadDetails = async (id, data)=>{
    const response = await api.put(`/leads/${id}`, data);
    return response.data;
};
const formatMetaErrorMessage = (error, defaultMessage)=>{
    try {
        const errorData = error.response?.data?.error || error.response?.data;
        if (errorData) {
            if (typeof errorData === 'object') {
                // Meta errors usually have message, code, or error_subcode
                // We stringify the whole object so the frontend formatMetaError can parse it
                return JSON.stringify(errorData);
            }
            return String(errorData);
        }
        return error.message || defaultMessage;
    } catch (e) {
        return error?.message || defaultMessage;
    }
};
const integrationApi = {
    // Get all integrations
    getIntegrations: async ()=>{
        try {
            const response = await api.get('/integrations');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch integrations';
            throw new Error(message);
        }
    },
    // Save integration configuration
    saveIntegration: async (config)=>{
        try {
            const response = await api.post('/integrations', config);
            return response.data;
        } catch (error) {
            // Enhanced error handling for validation errors
            if (error.response?.status === 422) {
                const validationErrors = error.response.data.errors;
                if (validationErrors && typeof validationErrors === 'object') {
                    // Format validation errors into a readable message
                    const errorMessages = Object.entries(validationErrors).map(([field, messages])=>{
                        const messageArray = Array.isArray(messages) ? messages : [
                            messages
                        ];
                        return `${field}: ${messageArray.join(', ')}`;
                    }).join('; ');
                    throw new Error(`Validation failed: ${errorMessages}`);
                }
                // If errors object is not in expected format, try to get message
                const message = error.response.data.message || 'Validation failed';
                throw new Error(message);
            }
            throw error;
        }
    },
    // Update integration configuration
    updateIntegration: async (id, config)=>{
        try {
            const response = await api.put(`/integrations/${id}`, config);
            return response.data;
        } catch (error) {
            if (error.response?.status === 422) {
                const validationErrors = error.response.data.errors;
                const message = validationErrors && typeof validationErrors === 'object' ? Object.entries(validationErrors).map(([f, m])=>`${f}: ${Array.isArray(m) ? m.join(', ') : m}`).join('; ') : error.response.data.message || 'Validation failed';
                throw new Error(message);
            }
            throw error;
        }
    },
    // Update integration status
    updateIntegrationStatus: async (id, isActive)=>{
        try {
            const response = await api.patch(`/integrations/${id}/status`, {
                isActive
            });
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to update integration status';
            throw new Error(message);
        }
    },
    // Get integration logs
    getIntegrationLogs: async (id)=>{
        try {
            const response = await api.get(`/integrations/${id}/logs`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch integration logs';
            throw new Error(message);
        }
    },
    // Get the most recent log for an integration (used for testing webhooks)
    getLatestLog: async (id)=>{
        try {
            const response = await api.get(`/integrations/${id}/latest-log`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch latest log';
            throw new Error(message);
        }
    },
    // Delete integration
    deleteIntegration: async (id)=>{
        try {
            const response = await api.delete(`/integrations/${id}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to delete integration';
            throw new Error(message);
        }
    },
    getWhatsAppProfiles: async ()=>{
        try {
            const response = await api.get('/integrations/whatsapp/profiles');
            return response.data.profiles;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch WhatsApp profiles';
            throw new Error(message);
        }
    },
    getWhatsAppAccounts: async ()=>{
        try {
            const response = await api.get('/integrations/whatsapp/accounts');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch WhatsApp accounts';
            throw new Error(message);
        }
    },
    getWhatsAppTemplates: async (accountId)=>{
        try {
            const response = await api.get(`/integrations/whatsapp/${accountId}/templates`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch templates';
            throw new Error(message);
        }
    },
    syncWhatsAppTemplates: async (accountId)=>{
        try {
            const response = await api.post(`/integrations/whatsapp/${accountId}/templates/sync`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to sync templates';
            throw new Error(message);
        }
    },
    createWhatsAppTemplate: async (accountId, templateData)=>{
        try {
            const response = await api.post(`/integrations/whatsapp/${accountId}/templates`, templateData);
            return response.data;
        } catch (error) {
            // Enhanced error handling for validation errors
            if (error.response?.status === 422 && error.response?.data?.errors) {
                // Format validation errors
                const validationErrors = error.response.data.errors;
                const errorMessages = Object.entries(validationErrors).map(([field, messages])=>`${field}: ${Array.isArray(messages) ? messages.join(', ') : messages}`).join('; ');
                throw new Error(`Validation failed: ${errorMessages}`);
            } else if (error.response?.status === 401 && error.response?.data?.error_type === 'token_expired') {
                throw new Error('Your WhatsApp access token has expired. Please update your access token.');
            } else if (error.response?.data?.message) {
                throw new Error(error.response.data.message);
            } else {
                throw new Error('Failed to create template');
            }
        }
    },
    checkIntegrationStatus: async (accountId)=>{
        try {
            const response = await api.get(`/integrations/whatsapp/${accountId}/status`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to check integration status';
            throw new Error(message);
        }
    },
    markReauthenticated: async (accountId)=>{
        try {
            const response = await api.post(`/integrations/whatsapp/${accountId}/reauth`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to mark integration as re-authenticated';
            throw new Error(message);
        }
    },
    updateAccessToken: async (accountId, accessToken)=>{
        try {
            const response = await api.post(`/integrations/whatsapp/${accountId}/update-token`, {
                access_token: accessToken
            });
            return response.data;
        } catch (error) {
            if (error.response?.status === 400 && error.response?.data?.error_type === 'invalid_token') {
                throw new Error('Invalid access token. Please check your token and try again.');
            }
            const message = error.response?.data?.message || 'Failed to update access token';
            throw new Error(message);
        }
    },
    updateWhatsAppTemplate: async (accountId, templateId, templateData)=>{
        try {
            const response = await api.put(`/integrations/whatsapp/${accountId}/templates/${templateId}`, templateData);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to update template';
            throw new Error(message);
        }
    },
    deleteWhatsAppTemplate: async (accountId, templateId)=>{
        try {
            const response = await api.delete(`/integrations/whatsapp/${accountId}/templates/${templateId}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to delete template';
            throw new Error(message);
        }
    },
    getWhatsAppTemplateDetails: async (accountId, templateId)=>{
        try {
            const response = await api.get(`/integrations/whatsapp/${accountId}/templates/${templateId}/details`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to get template details';
            throw new Error(message);
        }
    },
    getConnectedIntegrations: async ()=>{
        try {
            const response = await api.get('/integrations/connected');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch connected integrations';
            throw new Error(message);
        }
    },
    // Add the sendBroadcast method
    sendBroadcast: async (data)=>{
        const response = await api.post('/leads/send-template', data);
        return response.data;
    },
    // Facebook Lead Retrieval Methods
    getFacebookLeadForms: async ()=>{
        try {
            const response = await api.get('/facebook-lead-forms');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch Facebook lead forms';
            throw new Error(message);
        }
    },
    debugIntegrations: async ()=>{
        try {
            const response = await api.get('/debug-integrations');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to debug integrations';
            throw new Error(message);
        }
    },
    // New Meta API Methods (v25.0)
    getMetaPages: async ()=>{
        try {
            const response = await api.get('/meta/pages');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta pages';
            throw new Error(message);
        }
    },
    getMetaPageForms: async (pageId)=>{
        try {
            const response = await api.get(`/meta/pages/${pageId}/forms`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta lead forms';
            throw new Error(message);
        }
    },
    // Meta Ads API Methods
    getMetaAdAccounts: async ()=>{
        try {
            const response = await api.get('/meta/ads/adaccounts');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta ad accounts';
            throw new Error(message);
        }
    },
    getMetaBusinessAdAccounts: async (businessId)=>{
        try {
            const response = await api.get(`/meta/ads/businesses/${businessId}/adaccounts`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch business ad accounts';
            throw new Error(message);
        }
    },
    getMetaCampaigns: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/campaigns`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta campaigns';
            throw new Error(message);
        }
    },
    getMetaAdSets: async (campaignId)=>{
        try {
            const response = await api.get(`/meta/ads/campaigns/${campaignId}/adsets`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta ad sets';
            throw new Error(message);
        }
    },
    getMetaAds: async (adSetId)=>{
        try {
            const response = await api.get(`/meta/ads/adsets/${adSetId}/ads`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta ads';
            throw new Error(message);
        }
    },
    getMetaAdAccountInsights: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/insights`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta ad insights';
            throw new Error(message);
        }
    },
    updateMetaStatus: async (objectId, status)=>{
        try {
            const response = await api.post(`/meta/ads/${objectId}/status`, {
                status
            });
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to update Meta status';
            throw new Error(message);
        }
    },
    retrieveFacebookLeads: async (data)=>{
        try {
            const response = await api.post('/facebook-lead-retrieval', data);
            return response.data;
        } catch (error) {
            // Enhanced error handling to preserve error details from backend
            if (error.response?.data) {
                // Create a new error with the backend's error details
                const backendError = new Error(error.response.data.error || 'Failed to retrieve Facebook leads');
                // Attach the response data to the error for the frontend to use
                backendError.response = error.response;
                throw backendError;
            }
            throw new Error('Failed to retrieve Facebook leads');
        }
    },
    connectMeta: async ()=>{
        try {
            const response = await api.get('/meta/connect');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to get Meta connection URL');
        }
    },
    getMetaStatus: async ()=>{
        try {
            const response = await api.get('/meta/status');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to fetch Meta status');
        }
    },
    disconnectMeta: async ()=>{
        try {
            const response = await api.post('/meta/deauthorize'); // Now hits the authenticated route
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to disconnect Meta');
        }
    },
    dataDeletionRequest: async ()=>{
        try {
            const response = await api.post('/meta/data-deletion'); // Now hits the authenticated route
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to request data deletion');
        }
    },
    getDeletionRequests: async ()=>{
        try {
            const response = await api.get('/meta/deletion-requests');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to fetch deletion requests');
        }
    },
    getMetaBusinessAssets: async (businessId)=>{
        try {
            const response = await api.get(`/meta/business/${businessId}/assets`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.error || 'Failed to fetch business assets');
        }
    },
    // Facebook Conversion API Methods
    sendConversionEvent: async (data)=>{
        try {
            const response = await api.post('/facebook/conversion-api/send-event', data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to send conversion event';
            throw new Error(message);
        }
    },
    sendBatchConversionEvents: async (data)=>{
        try {
            const response = await api.post('/facebook/conversion-api/send-batch-events', data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to send batch conversion events';
            throw new Error(message);
        }
    },
    sendTestConversionEvent: async (data)=>{
        try {
            const response = await api.post('/facebook/conversion-api/send-test-event', data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to send test conversion event';
            throw new Error(message);
        }
    },
    getConversionApiEventTypes: async ()=>{
        try {
            const response = await api.get('/facebook/conversion-api/event-types');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch event types';
            throw new Error(message);
        }
    },
    getConversionApiConfiguration: async ()=>{
        try {
            const response = await api.get('/facebook/conversion-api/configuration');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Conversion API configuration';
            throw new Error(message);
        }
    },
    getMetaWebhookChecklist: async (pageId)=>{
        try {
            const response = await api.get(`/meta/pages/${pageId}/webhook-checklist`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch webhook checklist';
            throw new Error(message);
        }
    },
    testMetaLeadRetrieval: async (leadId)=>{
        try {
            const response = await api.get(`/meta/debug/lead/${leadId}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch lead details';
            throw new Error(message);
        }
    },
    updateConversionApiConfiguration: async (data)=>{
        try {
            const response = await api.post('/facebook/conversion-api/configuration', data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to update Conversion API configuration';
            throw new Error(message);
        }
    },
    syncMetaLeads: async (formId, days = 7)=>{
        try {
            const response = await api.post(`/meta/forms/${formId}/sync-leads`, {
                days
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to sync leads'));
        }
    },
    createMetaCampaign: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/campaigns`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta campaign'));
        }
    },
    createMetaAdSet: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adsets`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta ad set'));
        }
    },
    updateMetaAdSet: async (adSetId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adsets/${adSetId}`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to update Meta ad set'));
        }
    },
    createMetaAd: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/ads`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta ad'));
        }
    },
    getMetaAdCreatives: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/adcreatives`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch Meta ad creatives'));
        }
    },
    createMetaAdCreativeStandalone: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adcreatives`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta ad creative'));
        }
    },
    createMetaPageForm: async (pageId, formData)=>{
        try {
            const response = await api.post(`/meta/pages/${pageId}/forms`, formData);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta Lead Form'));
        }
    },
    syncMetaAssets: async ()=>{
        try {
            const response = await api.post('/meta/ads/sync');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to sync Meta assets';
            throw new Error(message);
        }
    },
    syncMetaAdAccountDetails: async (adAccountId)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/sync`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to sync ad account details';
            throw new Error(message);
        }
    },
    subscribeMetaPage: async (pageId)=>{
        try {
            const response = await api.post(`/meta/pages/${pageId}/subscribe`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to subscribe page to webhook';
            throw new Error(message);
        }
    },
    getMetaTemplates: async ()=>{
        try {
            const response = await api.get('/meta/ads/templates');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to fetch Meta templates';
            throw new Error(message);
        }
    },
    launchMetaTemplate: async (adAccountId, templateId, customName)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/launch-template`, {
                template_id: templateId,
                custom_name: customName
            });
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to launch Meta template';
            throw new Error(message);
        }
    },
    deleteMetaObject: async (objectId)=>{
        try {
            const response = await api.delete(`/meta/ads/${objectId}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to delete Meta object';
            throw new Error(message);
        }
    },
    updateMetaCampaign: async (campaignId, data)=>{
        try {
            const response = await api.post(`/meta/ads/campaigns/${campaignId}`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to update Meta campaign'));
        }
    },
    createMetaCustomAudience: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/customaudiences`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta custom audience'));
        }
    },
    createMetaLookalikeAudience: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/lookalike-audiences`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create Meta lookalike audience'));
        }
    },
    uploadMetaAdImage: async (adAccountId, image)=>{
        try {
            let response;
            if (typeof image === 'string') {
                response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adimages`, {
                    image_url: image
                });
            } else {
                const formData = new FormData();
                formData.append('image', image);
                response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adimages`, formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                });
            }
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to upload Meta ad image'));
        }
    },
    uploadMetaAdVideo: async (adAccountId, video, title)=>{
        try {
            let response;
            if (typeof video === 'string') {
                response = await api.post(`/meta/ads/adaccounts/${adAccountId}/advideos`, {
                    video_url: video,
                    title
                });
            } else {
                const formData = new FormData();
                formData.append('video', video);
                if (title) formData.append('title', title);
                response = await api.post(`/meta/ads/adaccounts/${adAccountId}/advideos`, formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                });
            }
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to upload Meta ad video'));
        }
    },
    getMetaAdPreview: async (objectId, adFormat = 'DESKTOP_FEED_STANDARD')=>{
        try {
            const response = await api.get(`/meta/ads/previews/${objectId}`, {
                params: {
                    ad_format: adFormat
                }
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch Meta ad preview'));
        }
    },
    duplicateMetaCampaign: async (campaignId, options)=>{
        try {
            const response = await api.post(`/meta/ads/campaigns/${campaignId}/duplicate`, options);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to duplicate Meta campaign'));
        }
    },
    duplicateMetaObject: async (objectId)=>{
        try {
            const response = await api.post(`/meta/ads/${objectId}/duplicate`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to duplicate Meta object'));
        }
    },
    getMetaOfflineEventSets: async (objectId)=>{
        try {
            const response = await api.get(`/meta/ads/offline-event-sets/${objectId}`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch offline event sets'));
        }
    },
    createMetaOfflineEventSet: async (businessId, data)=>{
        try {
            const response = await api.post(`/meta/ads/offline-event-sets/${businessId}`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create offline event set'));
        }
    },
    getMetaAutomatedRules: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/adrules`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch automated rules'));
        }
    },
    createMetaAutomatedRule: async (adAccountId, data)=>{
        try {
            const response = await api.post(`/meta/ads/adaccounts/${adAccountId}/adrules`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create automated rule'));
        }
    },
    deleteMetaAutomatedRule: async (ruleId)=>{
        try {
            const response = await api.delete(`/meta/ads/adrules/${ruleId}`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to delete automated rule'));
        }
    },
    getMetaFormDetails: async (formId)=>{
        try {
            const response = await api.get(`/meta/forms/${formId}`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch Meta form details'));
        }
    },
    updateMetaFormStatus: async (formId, status)=>{
        try {
            const response = await api.post(`/meta/forms/${formId}/status`, {
                status
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to update Meta form status'));
        }
    },
    // Fix 14: Track form endpoints
    trackMetaForm: async (pageId, formId, formName, pageName)=>{
        try {
            const response = await api.post(`/meta/pages/${pageId}/forms/track`, {
                form_id: formId,
                form_name: formName,
                page_name: pageName
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to track form'));
        }
    },
    getMetaTrackedForms: async (pageId)=>{
        try {
            const response = await api.get(`/meta/pages/${pageId}/forms/tracked`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to load tracked forms'));
        }
    },
    getMetaDeliveryEstimate: async (adAccountId, targetingSpec)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/delivery-estimate`, {
                params: {
                    targeting_spec: targetingSpec
                }
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch delivery estimate'));
        }
    },
    getMetaAccountAds: async (adAccountId)=>{
        try {
            const response = await api.get(`/meta/ads/adaccounts/${adAccountId}/ads`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch account ads'));
        }
    },
    getMetaCampaignAds: async (campaignId)=>{
        try {
            const response = await api.get(`/meta/ads/campaigns/${campaignId}/ads`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch campaign ads'));
        }
    },
    updateMetaAd: async (adId, data)=>{
        try {
            const response = await api.post(`/meta/ads/ads/${adId}`, data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to update Meta ad'));
        }
    },
    // Meta Pixel Methods
    getMetaPixels: async ()=>{
        try {
            const response = await api.get('/meta/pixels');
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch Meta pixels'));
        }
    },
    sendMetaCapiEvent: async (data)=>{
        try {
            // Use the test endpoint if a code is provided, otherwise standard send
            const endpoint = data.test_event_code ? '/meta/pixels/test-event' : '/meta/pixels/send-event';
            const response = await api.post(endpoint, data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to send Meta CAPI event';
            throw new Error(message);
        }
    },
    getMetaPixelDiagnostics: async (pixelId)=>{
        try {
            const response = await api.get(`/meta/pixels/${pixelId}/diagnostics`);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch pixel diagnostics'));
        }
    },
    syncMetaPixels: async ()=>{
        try {
            const response = await api.post('/meta/pixels/sync');
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to sync Meta pixels'));
        }
    },
    updateMetaPixel: async (id, data)=>{
        try {
            const response = await api.patch(`/meta/pixels/${id}`, data);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to update Meta pixel';
            throw new Error(message);
        }
    },
    deleteMetaPixel: async (id)=>{
        try {
            const response = await api.delete(`/meta/pixels/${id}`);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.error || 'Failed to delete Meta pixel';
            throw new Error(message);
        }
    },
    getMetaPixelRoiSummary: async (days = 30)=>{
        try {
            const response = await api.get('/meta/pixels/roi-summary', {
                params: {
                    days
                }
            });
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to fetch ROI summary'));
        }
    },
    createMetaPixel: async (data)=>{
        try {
            const response = await api.post('/meta/pixels/create', data);
            return response.data;
        } catch (error) {
            throw new Error(formatMetaErrorMessage(error, 'Failed to create pixel'));
        }
    }
};
const companyApi = {
    getSettings: async ()=>{
        try {
            const response = await api.get('/company/settings');
            return response.data.settings;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch company settings';
            throw new Error(message);
        }
    },
    updateSettings: async (settings)=>{
        try {
            const response = await api.patch('/company/settings', settings);
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to update company settings';
            throw new Error(message);
        }
    }
};
const exportLeads = async (ids)=>{
    try {
        const response = await api.post('/leads/export', {
            ids
        }, {
            responseType: 'blob',
            headers: {
                'Accept': 'text/csv',
                'Content-Type': 'application/json'
            }
        });
        // Get filename from response headers or use default
        const filename = response.headers['content-disposition']?.split('filename=')[1] || `leads-${new Date().toISOString().split('T')[0]}.csv`;
        // Create download link
        const blob = new Blob([
            response.data
        ], {
            type: 'text/csv'
        });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', filename);
        // Trigger download
        document.body.appendChild(link);
        link.click();
        // Cleanup
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
        return true;
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Export error:', error);
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isAxiosError(error)) {
            // Handle different error types
            if (error.response?.status === 404) {
                throw new Error('No leads found to export.');
            }
            throw new Error('Failed to export leads. Please try again.');
        }
        throw new Error('An unexpected error occurred during export.');
    }
};
const me = async ()=>{
    const response = await api.get('/user', {
        headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`
        }
    });
    return response.data;
};
const sendMessage = async (data)=>{
    const response = await api.post('/send-message', data);
    return response.data;
};
const authorize = async (data)=>{
    const response = await api.post('/broadcasting/auth', data);
    return response.data;
};
const getMessages = async (data)=>{
    const response = await api.post('/messages', data);
    return response.data;
};
const initializeChat = async (data)=>{
    const response = await api.post('/initialize-chat', data);
    return response.data;
};
const getLeadsWithLatestMessages = async ()=>{
    try {
        const response = await api.get('/conversations', {
            headers: {
                Authorization: `Bearer ${localStorage.getItem('token')}`
            }
        });
        return response.data;
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Error fetching conversations:', error);
        throw error;
    }
};
const getConversationMessages = async (conversationId, lastTimestamp)=>{
    try {
        const response = await api.get(`/conversations/${conversationId}/messages`, {
            headers: {
                Authorization: `Bearer ${localStorage.getItem('token')}`
            },
            params: {
                after: lastTimestamp
            }
        });
        return response.data;
    } catch (error) {
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logger$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logger"].error('Error fetching messages:', error);
        throw error;
    }
};
const getBookings = async (params)=>{
    return api.get('/bookings', {
        params
    });
};
const deleteBooking = async (id)=>{
    return api.delete(`/bookings/${id}`);
};
const updateBooking = async (id, data)=>{
    return api.put(`/bookings/${id}`, data);
};
const rescheduleBooking = async (id, data)=>{
    return api.patch(`/bookings/${id}/reschedule`, data);
};
const teamApi = {
    getMembers: async ()=>{
        const response = await api.get('/team');
        return response.data.members;
    },
    inviteMember: async (data)=>{
        const response = await api.post('/team/invite', data);
        return response.data;
    },
    resendInvite: async (id)=>{
        const response = await api.post(`/team/${id}/resend-invite`);
        return response.data;
    },
    updateRole: async (id, role)=>{
        const response = await api.patch(`/team/${id}/role`, {
            role
        });
        return response.data;
    },
    removeMember: async (id)=>{
        const response = await api.delete(`/team/${id}`);
        return response.data;
    },
    setupAccount: async (data)=>{
        try {
            const response = await api.post('/setup-account', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to setup account');
        }
    }
};
const adminApi = {
    getStats: async ()=>{
        try {
            const response = await api.get('/admin/stats');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch admin stats');
        }
    },
    getCompanies: async (page = 1, limit = 10, search, plan, status, tag, expiration, started, expStart, expEnd, startStart, startEnd)=>{
        try {
            let url = `/admin/companies?page=${page}&limit=${limit}`;
            if (search) url += `&search=${search}`;
            if (plan && plan !== 'all') url += `&plan=${plan}`;
            if (status && status !== 'all') url += `&status=${status}`;
            if (tag && tag !== 'all') url += `&tag=${tag}`;
            if (expiration && expiration !== 'all') url += `&expiration=${expiration}`;
            if (started && started !== 'all') url += `&started=${started}`;
            if (expStart) url += `&exp_start=${expStart}`;
            if (expEnd) url += `&exp_end=${expEnd}`;
            if (startStart) url += `&start_start=${startStart}`;
            if (startEnd) url += `&start_end=${startEnd}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch companies');
        }
    },
    updateCompany: async (id, data)=>{
        try {
            const response = await api.patch(`/admin/companies/${id}`, data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update company');
        }
    },
    getUsers: async (page = 1, limit = 10, search, tag, role, status, userType)=>{
        try {
            let url = `/admin/users?page=${page}&limit=${limit}`;
            if (search) url += `&search=${search}`;
            if (tag && tag !== 'all') url += `&tag=${tag}`;
            if (role && role !== 'all') url += `&role=${role}`;
            if (status && status !== 'all') url += `&status=${status}`;
            if (userType && userType !== 'all') url += `&user_type=${userType}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch users');
        }
    },
    updateUser: async (id, data)=>{
        try {
            const response = await api.patch(`/admin/users/${id}`, data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update user');
        }
    },
    getTesterRequests: async (page = 1, limit = 10, search)=>{
        try {
            let url = `/admin/tester-requests?page=${page}&limit=${limit}`;
            if (search) url += `&search=${search}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch tester requests');
        }
    },
    updateTesterRequestStatus: async (id, status)=>{
        try {
            const response = await api.patch(`/admin/tester-requests/${id}/status`, {
                status
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update status');
        }
    },
    deleteUser: async (id)=>{
        try {
            const response = await api.delete(`/admin/users/${id}`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to delete user');
        }
    },
    getEmailStats: async (search, page = 1, limit = 10, filterStatus = 'all')=>{
        try {
            const response = await api.get('/admin/email-stats', {
                params: {
                    search,
                    page,
                    limit,
                    filterStatus
                }
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch email stats');
        }
    },
    toggleUserNotification: async (userId, type = 'new_lead')=>{
        try {
            const response = await api.post(`/admin/users/${userId}/toggle-notification`, {
                type
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to toggle notification');
        }
    },
    toggleCompanyEmail: async (id)=>{
        try {
            const response = await api.post(`/admin/companies/${id}/toggle-email`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to toggle company email');
        }
    },
    deleteCompany: async (id)=>{
        try {
            const response = await api.delete(`/admin/companies/${id}`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to delete company');
        }
    },
    renewCompany: async (id, days, notes)=>{
        try {
            const response = await api.post(`/admin/companies/${id}/renew`, {
                days,
                notes
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to renew company');
        }
    },
    getCompanyHistory: async (id)=>{
        try {
            const response = await api.get(`/admin/companies/${id}/history`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch subscription history');
        }
    },
    loginAsAnyUser: async (id)=>{
        try {
            const response = await api.post(`/admin/users/${id}/login`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to impersonate user');
        }
    },
    getBilling: async (page = 1, limit = 10, search)=>{
        try {
            const url = `/admin/billing?page=${page}&limit=${limit}${search ? `&search=${search}` : ''}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch billing data');
        }
    },
    getPendingPayments: async (page = 1, limit = 10)=>{
        try {
            const url = `/admin/payments/pending?page=${page}&limit=${limit}`;
            const response = await api.get(url);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch pending payments');
        }
    },
    approvePayment: async (id)=>{
        try {
            const response = await api.post(`/admin/payments/${id}/approve`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to approve payment');
        }
    },
    getPlans: async ()=>{
        try {
            const response = await api.get('/admin/plans');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch plans');
        }
    },
    createPlan: async (data)=>{
        try {
            const response = await api.post('/admin/plans', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to create plan');
        }
    },
    updatePlan: async (id, data)=>{
        try {
            const response = await api.patch(`/admin/plans/${id}`, data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update plan');
        }
    },
    getTags: async ()=>{
        try {
            const response = await api.get('/admin/tags');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch tags');
        }
    },
    sendBroadcast: async (data)=>{
        try {
            const response = await api.post('/admin/broadcast', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to send broadcast');
        }
    },
    getBroadcastHistory: async ()=>{
        try {
            const response = await api.get('/admin/broadcast/history');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch broadcast history');
        }
    },
    // Coupons
    getCoupons: async ()=>{
        try {
            const response = await api.get('/admin/payments/coupons');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch coupons');
        }
    },
    createCoupon: async (data)=>{
        try {
            const response = await api.post('/admin/payments/coupons', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to create coupon');
        }
    },
    updateCoupon: async (id, data)=>{
        try {
            const response = await api.patch(`/admin/payments/coupons/${id}`, data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update coupon');
        }
    },
    deleteCoupon: async (id)=>{
        try {
            const response = await api.delete(`/admin/payments/coupons/${id}`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to delete coupon');
        }
    },
    // Settings
    getSettings: async ()=>{
        try {
            const response = await api.get('/admin/payments/settings');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch settings');
        }
    },
    updateSettings: async (data)=>{
        try {
            const response = await api.post('/admin/payments/settings', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to update settings');
        }
    }
};
const agencyApi = {
    getClients: async ()=>{
        try {
            const response = await api.get('/agency/clients');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch clients');
        }
    },
    onboardClient: async (data)=>{
        try {
            const response = await api.post('/agency/onboard', data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to onboard client');
        }
    },
    getStats: async ()=>{
        try {
            const response = await api.get('/agency/stats');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch agency stats');
        }
    },
    loginAsClient: async (id)=>{
        try {
            const response = await api.post(`/agency/clients/${id}/login`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to impersonate client');
        }
    },
    deleteClient: async (id)=>{
        try {
            const response = await api.delete(`/agency/clients/${id}`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to delete client');
        }
    },
    renewClient: async (id)=>{
        try {
            const response = await api.post(`/agency/clients/${id}/renew`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to renew client');
        }
    },
    getClientHistory: async (id)=>{
        try {
            const response = await api.get(`/agency/clients/${id}/history`);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch history');
        }
    }
};
const __TURBOPACK__default__export__ = api;
const getDashboardStats = async ()=>{
    const response = await api.get('/dashboard/stats');
    return response.data;
};
const getAnalyticsData = async ()=>{
    const response = await api.get('/analytics');
    return response.data;
};
const financeApi = {
    // ── Dashboard ─────────────────────────────────────────────────────────────
    getDashboard: (month, year)=>api.get('/super-admin/finance/dashboard', {
            params: {
                month,
                year
            }
        }).then((r)=>r.data),
    // ── Expense Categories ────────────────────────────────────────────────────
    getCategories: ()=>api.get('/super-admin/finance/categories').then((r)=>r.data),
    createCategory: (data)=>api.post('/super-admin/finance/categories', data).then((r)=>r.data),
    updateCategory: (id, data)=>api.put(`/super-admin/finance/categories/${id}`, data).then((r)=>r.data),
    deleteCategory: (id)=>api.delete(`/super-admin/finance/categories/${id}`).then((r)=>r.data),
    // ── Expenses ──────────────────────────────────────────────────────────────
    getExpenses: (params)=>api.get('/super-admin/finance/expenses', {
            params
        }).then((r)=>r.data),
    createExpense: (data)=>api.post('/super-admin/finance/expenses', data).then((r)=>r.data),
    updateExpense: (id, data)=>api.put(`/super-admin/finance/expenses/${id}`, data).then((r)=>r.data),
    deleteExpense: (id)=>api.delete(`/super-admin/finance/expenses/${id}`).then((r)=>r.data),
    uploadReceipt: (id, file)=>{
        const fd = new FormData();
        fd.append('receipt', file);
        return api.post(`/super-admin/finance/expenses/${id}/upload-receipt`, fd, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        }).then((r)=>r.data);
    },
    getDailyExpenses: (date)=>api.get(`/super-admin/finance/expenses/daily/${date}`).then((r)=>r.data),
    getMonthlyExpenses: (month, year)=>api.get(`/super-admin/finance/expenses/monthly/${month}/${year}`).then((r)=>r.data),
    getRecurringExpenses: ()=>api.get('/super-admin/finance/expenses/recurring').then((r)=>r.data),
    // ── Employees ─────────────────────────────────────────────────────────────
    getEmployees: (params)=>api.get('/super-admin/finance/employees', {
            params
        }).then((r)=>r.data),
    createEmployee: (data)=>api.post('/super-admin/finance/employees', data).then((r)=>r.data),
    updateEmployee: (id, data)=>api.put(`/super-admin/finance/employees/${id}`, data).then((r)=>r.data),
    deleteEmployee: (id)=>api.delete(`/super-admin/finance/employees/${id}`).then((r)=>r.data),
    getEmployeeSalaryHistory: (id)=>api.get(`/super-admin/finance/employees/${id}/salary-history`).then((r)=>r.data),
    toggleEmployeeActive: (id)=>api.post(`/super-admin/finance/employees/${id}/toggle-active`).then((r)=>r.data),
    getEmployeeRevisions: (id)=>api.get(`/super-admin/finance/employees/${id}/revisions`).then((r)=>r.data),
    addEmployeeRevision: (id, data)=>api.post(`/super-admin/finance/employees/${id}/revisions`, data).then((r)=>r.data),
    // ── Payroll ───────────────────────────────────────────────────────────────
    getPayrollCycle: (month, year)=>api.get(`/super-admin/finance/payroll/cycle/${month}/${year}`).then((r)=>r.data),
    generatePayroll: (month, year)=>api.post(`/super-admin/finance/payroll/generate/${month}/${year}`).then((r)=>r.data),
    markPayoutPaid: (payoutId, data)=>api.put(`/super-admin/finance/payroll/${payoutId}/mark-paid`, data).then((r)=>r.data),
    updatePayoutStatus: (payoutId, status)=>api.put(`/super-admin/finance/payroll/${payoutId}/status`, {
            status
        }).then((r)=>r.data),
    uploadPayoutProof: (payoutId, file)=>{
        const fd = new FormData();
        fd.append('proof', file);
        return api.post(`/super-admin/finance/payroll/${payoutId}/upload-proof`, fd, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        }).then((r)=>r.data);
    },
    getPayrollAnnualSummary: (year)=>api.get(`/super-admin/finance/payroll/summary/${year}`).then((r)=>r.data),
    // ── Revenue & MRR (Phase 2) ────────────────────────────────────────────────
    getRevenueCompanies: ()=>api.get('/super-admin/finance/revenue/companies').then((r)=>r.data),
    getMrrBreakdown: ()=>api.get('/super-admin/finance/revenue/mrr').then((r)=>r.data),
    getMrrHistory: ()=>api.get('/super-admin/finance/revenue/mrr/history').then((r)=>r.data),
    getSubscriptions: (params)=>api.get('/super-admin/finance/revenue/subscriptions', {
            params
        }).then((r)=>r.data),
    manualRenewal: (data)=>api.post('/super-admin/finance/revenue/renewals', data).then((r)=>r.data),
    getRevenueAdjustments: (params)=>api.get('/super-admin/finance/revenue/adjustments', {
            params
        }).then((r)=>r.data),
    createRevenueAdjustment: (data)=>api.post('/super-admin/finance/revenue/adjustments', data).then((r)=>r.data),
    getRevenueTarget: (month, year)=>api.get(`/super-admin/finance/revenue/targets/${month}/${year}`).then((r)=>r.data),
    setRevenueTarget: (data)=>api.post('/super-admin/finance/revenue/targets', data).then((r)=>r.data),
    getUpgradeLog: (month, year)=>api.get('/super-admin/finance/revenue/upgrade-log', {
            params: {
                month,
                year
            }
        }).then((r)=>r.data),
    // ── Churn Tracking (Phase 2) ──────────────────────────────────────────────
    getChurnLog: (params)=>api.get('/super-admin/finance/churn', {
            params
        }).then((r)=>r.data),
    tagChurnReason: (id, data)=>api.post(`/super-admin/finance/churn/${id}/reason`, data).then((r)=>r.data),
    detectChurn: ()=>api.post('/super-admin/finance/churn/detect').then((r)=>r.data),
    // ── Plans & Pricing (Phase 2) ─────────────────────────────────────────────
    getPlans: ()=>api.get('/super-admin/finance/plans').then((r)=>r.data),
    updatePlanPricing: (data)=>api.put('/super-admin/finance/plans/pricing', data).then((r)=>r.data),
    getPlanPricingHistory: (params)=>api.get('/super-admin/finance/plans/pricing/history', {
            params
        }).then((r)=>r.data),
    // ── Reports (Phase 2) ─────────────────────────────────────────────────────
    getMonthlyPlReport: (month, year)=>api.get(`/super-admin/finance/reports/pl/${month}/${year}`).then((r)=>r.data),
    getAnnualReport: (year)=>api.get(`/super-admin/finance/reports/annual/${year}`).then((r)=>r.data),
    getPayrollReport: (year)=>api.get(`/super-admin/finance/reports/payroll/${year}`).then((r)=>r.data),
    getGstReport: (month, year)=>api.get(`/super-admin/finance/reports/gst/${month}/${year}`).then((r)=>r.data)
};
const googleIntegrationApi = {
    getStatus: async ()=>{
        try {
            const response = await api.get('/google/status');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to fetch Google status';
            throw new Error(message);
        }
    },
    disconnect: async ()=>{
        try {
            const response = await api.delete('/google/disconnect');
            return response.data;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to disconnect Google account';
            throw new Error(message);
        }
    },
    getConnectUrl: async (scope)=>{
        try {
            const response = await api.get('/google/connect', {
                params: {
                    scope
                }
            });
            return response.data.url;
        } catch (error) {
            const message = error.response?.data?.message || 'Failed to get connection URL';
            throw new Error(message);
        }
    }
};
const subscriptionApi = {
    getSettings: async ()=>{
        try {
            const response = await api.get('/subscription/settings');
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to fetch subscription settings');
        }
    },
    validateCoupon: async (couponCode)=>{
        try {
            const response = await api.post('/subscription/validate-coupon', {
                coupon_code: couponCode
            });
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Failed to validate coupon');
        }
    }
};
const evolutionApi = {
    getAccounts: async ()=>{
        const response = await api.get('/evolution/accounts');
        return response.data;
    },
    createAccount: async (phoneNumber)=>{
        const response = await api.post('/evolution/accounts', {
            phone_number: phoneNumber
        });
        return response.data;
    },
    connectInstance: async (instanceName)=>{
        const response = await api.post(`/evolution/accounts/${instanceName}/connect`);
        return response.data;
    },
    getQrCode: async (instanceName)=>{
        const response = await api.get(`/evolution/accounts/${instanceName}/qrcode`);
        return response.data;
    },
    getStatus: async (instanceName)=>{
        const response = await api.get(`/evolution/accounts/${instanceName}/status`);
        return response.data;
    },
    disconnectInstance: async (instanceName)=>{
        const response = await api.post(`/evolution/accounts/${instanceName}/disconnect`);
        return response.data;
    },
    deleteAccount: async (instanceName)=>{
        const response = await api.delete(`/evolution/accounts/${instanceName}`);
        return response.data;
    },
    getConversations: async ()=>{
        const response = await api.get('/evolution/inbox/conversations');
        return response.data;
    },
    getMessages: async (conversationId)=>{
        const response = await api.get(`/evolution/inbox/conversations/${conversationId}/messages`);
        return response.data;
    },
    sendMessage: async (conversationId, message)=>{
        const response = await api.post('/evolution/inbox/messages/send', {
            conversation_id: conversationId,
            message
        });
        return response.data;
    },
    deleteConversation: async (conversationId)=>{
        const response = await api.delete(`/evolution/inbox/conversations/${conversationId}`);
        return response.data;
    },
    clearSession: async (conversationId)=>{
        const response = await api.post('/evolution/inbox/session/clear', {
            conversation_id: conversationId
        });
        return response.data;
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/register/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>RegisterPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-hook-form/dist/index.esm.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Zap$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/zap.js [app-client] (ecmascript) <export default as Zap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/user.js [app-client] (ecmascript) <export default as User>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/mail.js [app-client] (ecmascript) <export default as Mail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/phone.js [app-client] (ecmascript) <export default as Phone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Lock$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/lock.js [app-client] (ecmascript) <export default as Lock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/eye.js [app-client] (ecmascript) <export default as Eye>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOff$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/eye-off.js [app-client] (ecmascript) <export default as EyeOff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-client] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
;
var _s = __turbopack_refresh__.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
function RegisterPage() {
    _s();
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showPassword, setShowPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showConfirmPassword, setShowConfirmPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { register, handleSubmit, formState: { errors }, watch } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForm"])();
    const onSubmit = async (data)=>{
        setIsLoading(true);
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["register"])(data.name, data.email, data.password, data.password_confirmation, data.phone);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Account created successfully!");
            router.push('/dashboard');
        } catch (error) {
            console.error('Registration failed:', error);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Registration failed", {
                description: "An error occurred during registration. Please try again."
            });
        } finally{
            setIsLoading(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen flex flex-col items-center justify-center bg-slate-50 dark:bg-[#020617] p-6 antialiased",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 z-0 overflow-hidden pointer-events-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-[-15%] left-[-10%] w-[50%] h-[50%] bg-primary/5 blur-[120px] rounded-full"
                    }, void 0, false, {
                        fileName: "[project]/src/app/register/page.tsx",
                        lineNumber: 60,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-[-15%] right-[-10%] w-[50%] h-[50%] bg-violet-500/5 blur-[120px] rounded-full"
                    }, void 0, false, {
                        fileName: "[project]/src/app/register/page.tsx",
                        lineNumber: 61,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/register/page.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full max-w-[420px] relative z-10 flex flex-col gap-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col items-center text-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-12 w-12 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl flex items-center justify-center shadow-sm",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Zap$3e$__["Zap"], {
                                    className: "h-6 w-6 text-primary dark:text-indigo-400 fill-indigo-600/10"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/register/page.tsx",
                                    lineNumber: 68,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/register/page.tsx",
                                lineNumber: 67,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-2xl font-bold tracking-tight text-slate-900 dark:text-white",
                                        children: "Create an account"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/register/page.tsx",
                                        lineNumber: 71,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-slate-500 dark:text-slate-400 text-sm",
                                        children: [
                                            "Start your journey with ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-primary dark:text-indigo-400 font-semibold tracking-tight uppercase italic text-xs",
                                                children: "LeadBajaar"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/register/page.tsx",
                                                lineNumber: 73,
                                                columnNumber: 39
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/register/page.tsx",
                                        lineNumber: 72,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/register/page.tsx",
                                lineNumber: 70,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/register/page.tsx",
                        lineNumber: 66,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                        className: "border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none bg-white dark:bg-slate-900/50 backdrop-blur-sm rounded-[24px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                                className: "space-y-1 pb-6 pt-8 px-8",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                        className: "text-lg font-semibold tracking-tight",
                                        children: "Join workspace"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/register/page.tsx",
                                        lineNumber: 80,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                        className: "text-xs text-slate-500",
                                        children: "Fill in your details to get started"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/register/page.tsx",
                                        lineNumber: 81,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/register/page.tsx",
                                lineNumber: 79,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                                className: "px-8 pb-8",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                    onSubmit: handleSubmit(onSubmit),
                                    className: "space-y-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-1.5",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                    htmlFor: "name",
                                                    className: "text-xs font-semibold text-slate-700 dark:text-slate-300 ml-0.5",
                                                    children: "Full Name"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 86,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative group transition-all",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                                                            className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 group-focus-within:text-primary transition-colors"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/register/page.tsx",
                                                            lineNumber: 88,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                            id: "name",
                                                            placeholder: "John Doe",
                                                            className: "h-11 pl-10 bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 rounded-xl focus:ring-indigo-500/20 focus:border-primary transition-all text-sm",
                                                            ...register('name', {
                                                                required: 'Name is required'
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/register/page.tsx",
                                                            lineNumber: 89,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 87,
                                                    columnNumber: 17
                                                }, this),
                                                errors.name && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-[10px] text-red-500 font-medium ml-1",
                                                    children: errors.name.message
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 96,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/register/page.tsx",
                                            lineNumber: 85,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-1.5",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                    htmlFor: "email",
                                                    className: "text-xs font-semibold text-slate-700 dark:text-slate-300 ml-0.5",
                                                    children: "Work Email"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 100,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative group transition-all",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                                            className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 group-focus-within:text-primary transition-colors"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/register/page.tsx",
                                                            lineNumber: 102,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                            id: "email",
                                                            type: "email",
                                                            placeholder: "name@company.com",
                                                            className: "h-11 pl-10 bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 rounded-xl focus:ring-indigo-500/20 focus:border-primary transition-all text-sm",
                                                            ...register('email', {
                                                                required: 'Email is required',
                                                                pattern: {
                                                                    value: /\S+@\S+\.\S+/,
                                                                    message: "Invalid email format"
                                                                }
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/register/page.tsx",
                                                            lineNumber: 103,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 101,
                                                    columnNumber: 17
                                                }, this),
                                                errors.email && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-[10px] text-red-500 font-medium ml-1",
                                                    children: errors.email.message
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 117,
                                                    columnNumber: 34
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/register/page.tsx",
                                            lineNumber: 99,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-1.5",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                    htmlFor: "phone",
                                                    className: "text-xs font-semibold text-slate-700 dark:text-slate-300 ml-0.5",
                                                    children: "Phone Number"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 121,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative group transition-all",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                                            className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 group-focus-within:text-primary transition-colors"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/register/page.tsx",
                                                            lineNumber: 123,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                            id: "phone",
                                                            type: "tel",
                                                            placeholder: "+1 234 567 8900",
                                                            className: "h-11 pl-10 bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 rounded-xl focus:ring-indigo-500/20 focus:border-primary transition-all text-sm",
                                                            ...register('phone', {
                                                                required: 'Phone number is required'
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/register/page.tsx",
                                                            lineNumber: 124,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 122,
                                                    columnNumber: 17
                                                }, this),
                                                errors.phone && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-[10px] text-red-500 font-medium ml-1",
                                                    children: errors.phone.message
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 134,
                                                    columnNumber: 34
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/register/page.tsx",
                                            lineNumber: 120,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-1.5",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                    htmlFor: "password",
                                                    className: "text-xs font-semibold text-slate-700 dark:text-slate-300 ml-0.5",
                                                    children: "Password"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 138,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative group transition-all",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Lock$3e$__["Lock"], {
                                                            className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 group-focus-within:text-primary transition-colors"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/register/page.tsx",
                                                            lineNumber: 140,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                            id: "password",
                                                            type: showPassword ? "text" : "password",
                                                            placeholder: "••••••••",
                                                            className: "h-11 pl-10 pr-10 bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 rounded-xl focus:ring-indigo-500/20 focus:border-primary transition-all text-sm",
                                                            ...register('password', {
                                                                required: 'Password is required',
                                                                minLength: {
                                                                    value: 8,
                                                                    message: 'Minimum 8 characters'
                                                                }
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/register/page.tsx",
                                                            lineNumber: 141,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            type: "button",
                                                            onClick: ()=>setShowPassword(!showPassword),
                                                            className: "absolute right-3 top-1/2 -translate-y-1/2 h-8 w-8 flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors rounded-lg",
                                                            children: showPassword ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOff$3e$__["EyeOff"], {
                                                                className: "h-4 w-4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/register/page.tsx",
                                                                lineNumber: 157,
                                                                columnNumber: 23
                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"], {
                                                                className: "h-4 w-4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/register/page.tsx",
                                                                lineNumber: 159,
                                                                columnNumber: 23
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/register/page.tsx",
                                                            lineNumber: 151,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 139,
                                                    columnNumber: 17
                                                }, this),
                                                errors.password && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-[10px] text-red-500 font-medium ml-1",
                                                    children: errors.password.message
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 163,
                                                    columnNumber: 37
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/register/page.tsx",
                                            lineNumber: 137,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-1.5",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                                    htmlFor: "password_confirmation",
                                                    className: "text-xs font-semibold text-slate-700 dark:text-slate-300 ml-0.5",
                                                    children: "Confirm Password"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 167,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative group transition-all",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Lock$3e$__["Lock"], {
                                                            className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 group-focus-within:text-primary transition-colors"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/register/page.tsx",
                                                            lineNumber: 169,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                            id: "password_confirmation",
                                                            type: showConfirmPassword ? "text" : "password",
                                                            placeholder: "••••••••",
                                                            className: "h-11 pl-10 pr-10 bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 rounded-xl focus:ring-indigo-500/20 focus:border-primary transition-all text-sm",
                                                            ...register('password_confirmation', {
                                                                validate: (val)=>{
                                                                    if (watch('password') != val) {
                                                                        return "Passwords do not match";
                                                                    }
                                                                }
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/register/page.tsx",
                                                            lineNumber: 170,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            type: "button",
                                                            onClick: ()=>setShowConfirmPassword(!showConfirmPassword),
                                                            className: "absolute right-3 top-1/2 -translate-y-1/2 h-8 w-8 flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors rounded-lg",
                                                            children: showConfirmPassword ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOff$3e$__["EyeOff"], {
                                                                className: "h-4 w-4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/register/page.tsx",
                                                                lineNumber: 189,
                                                                columnNumber: 23
                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eye$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Eye$3e$__["Eye"], {
                                                                className: "h-4 w-4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/register/page.tsx",
                                                                lineNumber: 191,
                                                                columnNumber: 23
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/register/page.tsx",
                                                            lineNumber: 183,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 168,
                                                    columnNumber: 17
                                                }, this),
                                                errors.password_confirmation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-[10px] text-red-500 font-medium ml-1",
                                                    children: errors.password_confirmation.message
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/register/page.tsx",
                                                    lineNumber: 195,
                                                    columnNumber: 50
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/register/page.tsx",
                                            lineNumber: 166,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            type: "submit",
                                            className: "w-full h-11 rounded-xl bg-slate-900 dark:bg-primary hover:bg-slate-800 dark:hover:bg-primary/90 text-white font-semibold text-sm transition-all active:scale-[0.98] mt-4 flex items-center justify-center gap-2 group",
                                            disabled: isLoading,
                                            children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                                className: "h-4 w-4 animate-spin"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/register/page.tsx",
                                                lineNumber: 204,
                                                columnNumber: 19
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                children: [
                                                    "Sign up",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                        className: "h-4 w-4 group-hover:translate-x-0.5 transition-transform"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/register/page.tsx",
                                                        lineNumber: 208,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/register/page.tsx",
                                            lineNumber: 198,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/register/page.tsx",
                                    lineNumber: 84,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/register/page.tsx",
                                lineNumber: 83,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/register/page.tsx",
                        lineNumber: 78,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-center text-xs text-slate-500 font-medium",
                        children: [
                            "Already have an account?",
                            ' ',
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/signin",
                                className: "text-primary dark:text-indigo-400 font-bold hover:underline",
                                children: "Sign in instead"
                            }, void 0, false, {
                                fileName: "[project]/src/app/register/page.tsx",
                                lineNumber: 218,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/register/page.tsx",
                        lineNumber: 216,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-center gap-6 mt-2 opacity-50 transition-opacity hover:opacity-100",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] text-slate-400 font-medium uppercase tracking-widest",
                                children: "Privacy Protected"
                            }, void 0, false, {
                                fileName: "[project]/src/app/register/page.tsx",
                                lineNumber: 225,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-1 w-1 bg-slate-300 dark:bg-slate-800 rounded-full"
                            }, void 0, false, {
                                fileName: "[project]/src/app/register/page.tsx",
                                lineNumber: 226,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] text-slate-400 font-medium uppercase tracking-widest",
                                children: "Global Access"
                            }, void 0, false, {
                                fileName: "[project]/src/app/register/page.tsx",
                                lineNumber: 227,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/register/page.tsx",
                        lineNumber: 224,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/register/page.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/register/page.tsx",
        lineNumber: 57,
        columnNumber: 5
    }, this);
}
_s(RegisterPage, "heLVPIjNNnyw+7ep+E/3N/4UmWQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForm"]
    ];
});
_c = RegisterPage;
var _c;
__turbopack_refresh__.register(_c, "RegisterPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/register/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),
}]);

//# sourceMappingURL=src_ad4d3c._.js.map